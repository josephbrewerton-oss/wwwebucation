/**
 * static/player/ast-gestures.js
 *
 * St Joseph's Educational Media Suite - Zero-Bloat Flash-Caliber Direct Manipulation Subsystem
 * Copyright (c) 2026 Joseph Brewerton.
 * SPDX-License-Identifier: AGPL-3.0-or-later OR Commercial-License
 *
 * Pure Declarative Virtual Machine for Cartridge-Driven Direct Interactivity:
 * 1. Declarative Pointer & Keyboard VM (:clickable, :holdable, :trackball, :rotatable, 1D/2D :draggable)
 * 2. Bidirectional Slider-to-Variable Direct Stage Binding (data-bind-input)
 * 3. Stage-Embedded Glassmorphism Floating HUD & Live Parameter Dock
 * 4. Smartboard & Stylus Pen Vector Annotation Whiteboard Layer (120Hz-240Hz coalesced)
 * 5. Interactive Pedagogical X-Ray Hotspot Inspector
 * 6. Multi-sensory Procedural WebAudio Sonification
 */

(function (global) {
  'use strict';

  class ASTDirectGestureSubsystem {
    constructor(engine, options = {}) {
      this.engine = engine;
      this.options = options;
      this.stageSvg = null;
      this.sceneRoot = null;
      this.inkRoot = null;
      this.hudRoot = null;
      this.xrayTooltip = null;

      // Pointer Drag State
      this.isDragging = false;
      this.dragTarget = null;
      this.dragMode = null; // 'generic', 'rotate', 'trackball', 'bind-input'
      this.dragStart = { x: 0, y: 0 };
      this.targetInitial = { x: 0, y: 0 };
      this._wasPlayingBeforeDrag = false;

      // Pen Annotation Whiteboard State
      this.isPenActive = false;
      this.currentTool = 'pen'; // 'pen', 'marker', 'highlighter', 'eraser'
      this.currentInkColor = '#facc15'; // Neon Gold default
      this.currentInkWidth = 3.5;
      this.isDrawing = false;
      this.currentStroke = null;
      this.strokes = [];
      this._undoStack = [];
      this.stylusOnlyMode = false;

      // X-Ray Pedagogical Tooltip Mode
      this.isXRayActive = false;
      this.sonificationEnabled = true;

      // Audio Synthesizer Context
      this.audioCtx = null;

      // Generic Declarative Held Input VM State (Keyboard + Pointer)
      this._heldKeys = new Set();
      this._heldKeyCodeMap = new Map();
      this._heldPointerEntries = new Map();
      this._activeHoldVars = new Map();
      this._holdRafId = null;
      this._holdLastTs = 0;
      this._boundStageSvg = null;
      this._windowListenersBound = false;

      // Bind methods
      this.handlePointerDown = this.handlePointerDown.bind(this);
      this.handlePointerMove = this.handlePointerMove.bind(this);
      this.handlePointerUp = this.handlePointerUp.bind(this);
      this.handlePointerCancel = this.handlePointerCancel.bind(this);
      this.handlePointerLeave = this.handlePointerLeave.bind(this);
      this.handleKeyDown = this.handleKeyDown.bind(this);
      this.handleKeyUp = this.handleKeyUp.bind(this);
      this.handleWindowBlur = this.handleWindowBlur.bind(this);
      this._runHoldLoop = this._runHoldLoop.bind(this);
    }

    /**
     * Initializes and mounts gesture subsystem onto the SVG stage
     */
    init(stageSvg, sceneRoot) {
      this.stageSvg = stageSvg || document.getElementById('stage-svg');
      this.sceneRoot = sceneRoot || document.getElementById('scene-root');
      if (!this.stageSvg) return;

      this.setupDomLayers();
      this.setupEventListeners();
      this.setupGlassHud();
      this.setupXRayTooltip();
      this.enhanceSceneInteractivity();

      // Listen for scene load changes (guard duplicate registration)
      if (!this._presetListenerBound && this.engine && typeof this.engine.on === 'function') {
        this._presetListenerBound = true;
        this.engine.on('presetchange', () => {
          this._releaseAllHeldInputs(false);
          this.isDragging = false;
          this.dragTarget = null;
          this.dragMode = null;
          this._wasPlayingBeforeDrag = false;
          this.hideXRayPopup();
          setTimeout(() => this.enhanceSceneInteractivity(), 50);
        });
      }
    }

    /**
     * Creates dedicated SVG layers for annotations and HUD feedback
     */
    setupDomLayers() {
      // 1. Whiteboard Ink Layer
      let inkGroup = this.stageSvg.querySelector('#annotation-ink-root');
      if (!inkGroup) {
        inkGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        inkGroup.id = 'annotation-ink-root';
        inkGroup.style.pointerEvents = 'none';
        this.stageSvg.appendChild(inkGroup);
      }
      this.inkRoot = inkGroup;

      // 2. Stage Drag Feedback Layer
      let hudGroup = this.stageSvg.querySelector('#stage-hud-root');
      if (!hudGroup) {
        hudGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        hudGroup.id = 'stage-hud-root';
        this.stageSvg.appendChild(hudGroup);
      }
      hudGroup.style.pointerEvents = 'none';
      this.hudRoot = hudGroup;
    }

    /**
     * Attaches Pointer Events & Generic Declarative Keyboard/Hold Listeners
     */
    setupEventListeners() {
      if (!this.stageSvg) return;

      // Make stage SVG focusable so clicks/taps immediately enable keyboard events
      if (!this.stageSvg.hasAttribute('tabindex')) {
        this.stageSvg.setAttribute('tabindex', '0');
      }
      this.stageSvg.style.outline = 'none';
      this.stageSvg.style.touchAction = 'none';

      if (this._boundStageSvg !== this.stageSvg) {
        if (this._boundStageSvg) {
          this._boundStageSvg.removeEventListener('pointerdown', this.handlePointerDown);
          this._boundStageSvg.removeEventListener('pointerleave', this.handlePointerLeave);
        }
        this.stageSvg.addEventListener('pointerdown', this.handlePointerDown, { passive: false });
        this.stageSvg.addEventListener('pointerleave', this.handlePointerLeave);
        this._boundStageSvg = this.stageSvg;
      }

      if (!this._windowListenersBound && typeof window !== 'undefined') {
        this._windowListenersBound = true;
        this._declarativeKeyBound = true;
        window.addEventListener('pointermove', this.handlePointerMove, { passive: false });
        window.addEventListener('pointerup', this.handlePointerUp);
        window.addEventListener('pointercancel', this.handlePointerCancel);
        window.addEventListener('keydown', this.handleKeyDown);
        window.addEventListener('keyup', this.handleKeyUp);
        window.addEventListener('blur', this.handleWindowBlur);

        // Whiteboard Ink message listener from parent window / WebRTC classroom mesh
        window.addEventListener('message', (ev) => {
          if (!ev.data) return;
          if (ev.data.type === 'IMPORT_WHITEBOARD_INK' || ev.data.type === 'LOAD_WHITEBOARD_INK') {
            const raw = ev.data.data || ev.data.ast || ev.data.json;
            if (typeof raw === 'string') {
              if (raw.trim().startsWith('(')) {
                this.importInkFromAST(raw);
              } else {
                try {
                  this.importInkFromJSON(JSON.parse(raw));
                } catch {
                  this.importInkFromAST(raw);
                }
              }
            } else if (typeof raw === 'object') {
              this.importInkFromJSON(raw);
            }
            this.showFloatingNotice('📥 Whiteboard ink loaded!');
          } else if (ev.data.type === 'CLEAR_WHITEBOARD_INK') {
            this.clearWhiteboardInk();
          } else if (ev.data.type === 'UNDO_WHITEBOARD_INK') {
            this.undoLastStroke();
          } else if (ev.data.type === 'REDO_WHITEBOARD_INK') {
            this.redoLastStroke();
          } else if (ev.data.type === 'EXPORT_WHITEBOARD_INK') {
            this.broadcastInkSession();
          } else if (ev.data.type === 'TOGGLE_PEN') {
            this.togglePen(typeof ev.data.enabled === 'boolean' ? ev.data.enabled : undefined);
          }
        });
      }
    }

    _resolveVarBounds(scene, g, varName) {
      const vMeta = scene && scene.vars && scene.vars[varName];
      const min = typeof g.min === 'number' ? g.min : (vMeta && typeof vMeta.min === 'number' ? vMeta.min : -Infinity);
      const max = typeof g.max === 'number' ? g.max : (vMeta && typeof vMeta.max === 'number' ? vMeta.max : Infinity);
      return { min, max };
    }

    _resolveHoldReleaseValue(scene, g, holdVarName) {
      if (g && g.releaseVal !== undefined) return g.releaseVal;
      const vMeta = scene && scene.vars && scene.vars[holdVarName];
      if (vMeta && typeof vMeta === 'object' && vMeta.defaultValue !== undefined) {
        return vMeta.defaultValue;
      }
      const cur = this.engine && this.engine.vars ? this.engine.vars[holdVarName] : undefined;
      return typeof cur === 'boolean' ? false : 0;
    }

    _writeEngineVar(varName, value) {
      if (!this.engine || !varName) return;
      if (typeof this.engine.setVar === 'function') {
        this.engine.setVar(varName, value);
      } else if (this.engine.vars) {
        this.engine.vars[varName] = value;
      }
    }

    _speakGestureText(rawText) {
      if (!rawText || !this.engine) return;
      const text = String(rawText).trim();
      if (!text) return;
      if (typeof this.engine.speak === 'function') {
        this.engine.speak(text);
      } else if (typeof this.engine.speakText === 'function') {
        this.engine.speakText(text);
      }
    }

    _applyGesturePress(g, matchedEl, scene) {
      if (!this.engine || !this.engine.vars) return false;
      let changed = false;

      const toggleKey = g.toggleVar || g.toggle;
      const setKey = g.setVar || g.set || (g.var && g.val !== undefined ? g.var : null);
      const stepKey = g.stepVar || (typeof g.step === 'string' ? g.step : null) || (!setKey && g.var && g.delta !== undefined ? g.var : null);
      const holdKey = g.holdVar;

      if (toggleKey) {
        this._writeEngineVar(toggleKey, !this.engine.vars[toggleKey]);
        changed = true;
      }
      if (setKey) {
        let val = g.val;
        if (matchedEl && g.attr && matchedEl.hasAttribute(g.attr)) {
          const rawAttr = matchedEl.getAttribute(g.attr);
          val = !isNaN(Number(rawAttr)) ? Number(rawAttr) : rawAttr;
        }
        this._writeEngineVar(setKey, val);
        changed = true;
      }
      if (holdKey) {
        let entry = this._activeHoldVars.get(holdKey);
        if (!entry) {
          entry = {
            gestures: new Set(),
            releaseVal: this._resolveHoldReleaseValue(scene, g, holdKey)
          };
          this._activeHoldVars.set(holdKey, entry);
        }
        entry.gestures.add(g);
        this._writeEngineVar(holdKey, g.val !== undefined ? g.val : true);
        changed = true;
      }
      if (stepKey) {
        const cur = typeof this.engine.vars[stepKey] === 'number' ? this.engine.vars[stepKey] : 0;
        const delta = typeof g.delta === 'number' ? g.delta : 1;
        const { min, max } = this._resolveVarBounds(scene, g, stepKey);
        const next = Math.max(min, Math.min(max, cur + delta));
        this._writeEngineVar(stepKey, next);
        changed = true;
      }
      if (g.expr) {
        try {
          new Function('vars', 'el', 'engine', 'computed', g.expr)(
            this.engine.vars,
            matchedEl,
            this.engine,
            this.engine.computed || {}
          );
          if (typeof this.engine.updateComputedVars === 'function') {
            this.engine.updateComputedVars(this.engine.progress || 0);
          }
          changed = true;
        } catch (err) {
          console.warn('[ASTGestures] Gesture expr error:', g.expr, err);
        }
      }
      if (g.tone && typeof this.playAudioTone === 'function') {
        String(g.tone).split(',').forEach((freq, idx) => {
          const hz = parseFloat(freq.trim());
          if (!Number.isNaN(hz)) {
            setTimeout(() => this.playAudioTone(hz, 'sine', 0.12, 0.2), idx * 70);
          }
        });
      }
      if (g.speak) {
        this._speakGestureText(g.speak);
      }

      return changed;
    }

    _applyContinuousGestureStep(g, scene, dtSec, matchedEl = null) {
      if (!this.engine || !this.engine.vars) return false;
      let changed = false;

      if (g.holdVar) {
        const holdVal = g.val !== undefined ? g.val : true;
        if (this.engine.vars[g.holdVar] !== holdVal) {
          this._writeEngineVar(g.holdVar, holdVal);
          changed = true;
        }
      }

      const stepKey = g.stepVar || (typeof g.step === 'string' ? g.step : null) || (!g.setVar && g.var && g.delta !== undefined ? g.var : null);
      if (stepKey) {
        const cur = typeof this.engine.vars[stepKey] === 'number' ? this.engine.vars[stepKey] : 0;
        const delta = typeof g.delta === 'number' ? g.delta : 1;
        const stepIncrement = typeof g.rate === 'number' ? (g.rate * dtSec) : (delta * dtSec * 3.5);
        const { min, max } = this._resolveVarBounds(scene, g, stepKey);
        const next = Math.max(min, Math.min(max, cur + stepIncrement));
        if (next !== cur) {
          this._writeEngineVar(stepKey, next);
          changed = true;
        }
      }

      if (g.expr && (g.type === 'holdable' || g.hold === true)) {
        try {
          new Function('vars', 'el', 'engine', 'dt', 'computed', g.expr)(
            this.engine.vars,
            matchedEl,
            this.engine,
            dtSec,
            this.engine.computed || {}
          );
          if (typeof this.engine.updateComputedVars === 'function') {
            this.engine.updateComputedVars(this.engine.progress || 0);
          }
          changed = true;
        } catch (err) {
          console.warn('[ASTGestures] Hold expr error:', g.expr, err);
        }
      }

      return changed;
    }

    _releaseHoldForGesture(g) {
      if (!g || !g.holdVar) return false;
      const entry = this._activeHoldVars.get(g.holdVar);
      if (!entry) return false;
      entry.gestures.delete(g);
      if (entry.gestures.size === 0) {
        this._activeHoldVars.delete(g.holdVar);
        this._writeEngineVar(g.holdVar, entry.releaseVal);
        return true;
      }
      return false;
    }

    _releasePointerEntry(pointerId) {
      const entry = this._heldPointerEntries.get(pointerId);
      if (!entry) return false;
      this._heldPointerEntries.delete(pointerId);
      let resetOccurred = false;
      for (let i = 0; i < entry.gestures.length; i++) {
        if (this._releaseHoldForGesture(entry.gestures[i])) {
          resetOccurred = true;
        }
      }
      if (this._heldKeys.size === 0 && this._heldPointerEntries.size === 0) {
        this._stopHoldLoop();
      }
      return resetOccurred;
    }

    _releaseAllHeldInputs(resetHoldVars = true) {
      this._heldKeys.clear();
      this._heldKeyCodeMap.clear();
      this._heldPointerEntries.clear();

      let resetOccurred = false;
      if (resetHoldVars && this._activeHoldVars.size > 0) {
        for (const [varName, entry] of this._activeHoldVars.entries()) {
          this._writeEngineVar(varName, entry.releaseVal);
          resetOccurred = true;
        }
      }
      this._activeHoldVars.clear();
      this._stopHoldLoop();

      if (resetOccurred && this.engine && typeof this.engine.applyBindings === 'function') {
        this.engine.applyBindings(this.engine.progress || 0, 0, false);
      }
    }

    _ensureHoldLoop() {
      if (this._holdRafId !== null) return;
      if (this._heldKeys.size === 0 && this._heldPointerEntries.size === 0) return;
      if (typeof requestAnimationFrame === 'undefined') return;
      this._holdLastTs = typeof performance !== 'undefined' ? performance.now() : Date.now();
      this._holdRafId = requestAnimationFrame(this._runHoldLoop);
    }

    _stopHoldLoop() {
      if (this._holdRafId !== null && typeof cancelAnimationFrame !== 'undefined') {
        cancelAnimationFrame(this._holdRafId);
      }
      this._holdRafId = null;
      this._holdLastTs = 0;
    }

    _runHoldLoop(ts) {
      this._holdRafId = null;
      const now = ts || (typeof performance !== 'undefined' ? performance.now() : Date.now());
      const dtSec = this._holdLastTs ? Math.min(0.05, Math.max(0.001, (now - this._holdLastTs) / 1000)) : (1 / 60);
      this._holdLastTs = now;

      if (this._heldKeys.size === 0 && this._heldPointerEntries.size === 0) {
        return;
      }

      const scene = this.engine && this.engine.scene;
      if (!scene || !this.engine || !this.engine.vars) {
        this._stopHoldLoop();
        return;
      }

      let changed = false;
      const gestures = Array.isArray(scene.gestures) ? scene.gestures : [];

      if (this._heldKeys.size > 0) {
        for (let i = 0; i < gestures.length; i++) {
          const g = gestures[i];
          if (g.type !== 'key') continue;
          const keyMatched = this._heldKeys.has(g.code) ||
            this._heldKeys.has(g.key) ||
            (typeof g.key === 'string' && g.key.length === 1 && this._heldKeys.has(g.key.toLowerCase()));
          if (!keyMatched) continue;
          const isContinuous = Boolean(g.holdVar || ((g.stepVar || typeof g.step === 'string') && g.hold !== false));
          if (isContinuous && this._applyContinuousGestureStep(g, scene, dtSec, null)) {
            changed = true;
          }
        }
      }

      if (this._heldPointerEntries.size > 0) {
        for (const entry of this._heldPointerEntries.values()) {
          const heldDuration = now - entry.pressedAt;
          for (let i = 0; i < entry.gestures.length; i++) {
            const g = entry.gestures[i];
            const hasStep = Boolean(g.stepVar || typeof g.step === 'string');
            const wantsContinuous = Boolean(
              g.holdVar ||
              g.type === 'holdable' ||
              g.hold === true ||
              (hasStep && g.hold !== false && heldDuration >= 160)
            );
            const matchedEl = entry.matchedEls ? entry.matchedEls[i] : null;
            if (wantsContinuous && this._applyContinuousGestureStep(g, scene, dtSec, matchedEl)) {
              changed = true;
            }
          }
        }
      }

      if (changed && typeof this.engine.applyBindings === 'function') {
        this.engine.applyBindings(this.engine.progress || 0, 0, false);
      }

      if (this._heldKeys.size > 0 || this._heldPointerEntries.size > 0) {
        this._holdRafId = requestAnimationFrame(this._runHoldLoop);
      } else {
        this._stopHoldLoop();
      }
    }

    _gestureMatchesKey(g, e) {
      if (!g || g.type !== 'key') return false;
      if (g.code && e.code && g.code === e.code) return true;
      if (g.key && e.key) {
        if (g.key === e.key) return true;
        if (g.key.length === 1 && e.key.length === 1 && g.key.toLowerCase() === e.key.toLowerCase()) {
          return true;
        }
      }
      return false;
    }

    _ensureInteractiveSimPlaying() {
      if (
        this.engine &&
        !this.engine.isPlaying &&
        this.engine.isContinuousSim &&
        Array.isArray(this.engine.activeVarBindings) &&
        this.engine.activeVarBindings.length > 0 &&
        typeof this.engine.play === 'function'
      ) {
        this.engine.play();
      }
    }

    handleKeyDown(e) {
      if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT' || e.target.isContentEditable)) {
        return;
      }
      const scene = this.engine && this.engine.scene;
      if (!scene || !Array.isArray(scene.gestures) || !this.engine.vars) return;

      const matchingKeys = scene.gestures.filter(g => this._gestureMatchesKey(g, e));
      if (matchingKeys.length === 0) return;

      e.preventDefault();
      if (typeof e.stopImmediatePropagation === 'function') {
        e.stopImmediatePropagation();
      }

      if (e.code) {
        this._heldKeys.add(e.code);
        if (e.key) this._heldKeyCodeMap.set(e.code, e.key);
      }
      if (e.key) {
        this._heldKeys.add(e.key);
        if (e.key.length === 1) this._heldKeys.add(e.key.toLowerCase());
      }

      let needsHoldLoop = false;
      for (let i = 0; i < matchingKeys.length; i++) {
        const g = matchingKeys[i];
        if (g.holdVar || ((g.stepVar || typeof g.step === 'string') && g.hold !== false)) {
          needsHoldLoop = true;
        }
      }

      this._ensureInteractiveSimPlaying();

      if (!e.repeat) {
        let changed = false;
        for (let i = 0; i < matchingKeys.length; i++) {
          if (this._applyGesturePress(matchingKeys[i], null, scene)) {
            changed = true;
          }
        }
        if (changed && typeof this.engine.applyBindings === 'function') {
          this.engine.applyBindings(this.engine.progress || 0, 0, false);
        }
        if (!matchingKeys.some(g => Boolean(g.tone))) {
          this.playAudioTone(440, 'triangle', 0.04, 0.12);
        }
      }

      if (needsHoldLoop) {
        this._ensureHoldLoop();
      }
    }

    handleKeyUp(e) {
      if (e.code) {
        this._heldKeys.delete(e.code);
        const mappedKey = this._heldKeyCodeMap.get(e.code);
        if (mappedKey) {
          this._heldKeys.delete(mappedKey);
          this._heldKeys.delete(mappedKey.toLowerCase());
          this._heldKeys.delete(mappedKey.toUpperCase());
          this._heldKeyCodeMap.delete(e.code);
        }
      }
      if (e.key) {
        this._heldKeys.delete(e.key);
        this._heldKeys.delete(e.key.toLowerCase());
        this._heldKeys.delete(e.key.toUpperCase());
      }

      const scene = this.engine && this.engine.scene;
      if (scene && Array.isArray(scene.gestures)) {
        const matchingKeys = scene.gestures.filter(g => this._gestureMatchesKey(g, e));
        if (matchingKeys.length > 0 && typeof e.stopImmediatePropagation === 'function') {
          e.stopImmediatePropagation();
        }
        if (this._activeHoldVars.size > 0) {
          let resetOccurred = false;
          for (let i = 0; i < matchingKeys.length; i++) {
            if (this._releaseHoldForGesture(matchingKeys[i])) {
              resetOccurred = true;
            }
          }
          if (resetOccurred && typeof this.engine.applyBindings === 'function') {
            this.engine.applyBindings(this.engine.progress || 0, 0, false);
          }
        }
      }

      if (this._heldKeys.size === 0 && this._heldPointerEntries.size === 0) {
        this._stopHoldLoop();
      }
    }

    handleWindowBlur() {
      this._releaseAllHeldInputs(true);
    }

    handlePointerLeave(e) {
      if (this._heldPointerEntries.size === 0) return;
      const pointerId = e && e.pointerId !== undefined ? e.pointerId : 'mouse';
      if (this._heldPointerEntries.has(pointerId)) {
        const didReset = this._releasePointerEntry(pointerId);
        if (didReset && this.engine && typeof this.engine.applyBindings === 'function') {
          this.engine.applyBindings(this.engine.progress || 0, 0, false);
        }
      } else {
        this._releaseAllHeldInputs(true);
      }
    }

    /**
     * Converts client screen coordinates into precise SVG coordinate space (0..800, 0..480)
     */
    screenToSvg(clientX, clientY) {
      if (!this.stageSvg) return { x: 0, y: 0 };
      const pt = this.stageSvg.createSVGPoint();
      pt.x = clientX;
      pt.y = clientY;
      const ctm = this.stageSvg.getScreenCTM();
      if (!ctm) return { x: clientX, y: clientY };
      const svgPt = pt.matrixTransform(ctm.inverse());
      return { x: svgPt.x, y: svgPt.y };
    }

    /**
     * Compiles declarative scene gesture bindings onto SVG stage nodes (Cartridge as Driver, Engine as VM)
     */
    enhanceSceneInteractivity() {
      if (!this.stageSvg) return;

      // Restore any persisted annotations for this scene
      this.restoreInkFromSession();

      // Live Simulation Parameters HUD Dock (auto-populates when cartridge omits custom ui:controls)
      this.setupSimParametersHud();

      // Dynamic Declarative Scene Gestures
      const scene = this.engine && this.engine.scene;
      if (scene && scene.gestures && Array.isArray(scene.gestures)) {
        scene.gestures.forEach(g => {
          if (!g.target) return;
          const matchedList = [];
          if (this.stageSvg.matches && this.stageSvg.matches(g.target)) {
            matchedList.push(this.stageSvg);
          }
          this.stageSvg.querySelectorAll(g.target).forEach(node => matchedList.push(node));

          matchedList.forEach(el => {
            el.style.pointerEvents = 'auto';
            el.style.touchAction = 'none';
            if (el !== this.stageSvg && g.type !== 'trackball' && g.axis !== 'trackball') {
              el.querySelectorAll('*').forEach(child => {
                if (child && child.style) child.style.pointerEvents = 'auto';
              });
            }

            // A. Declarative Clickable / Holdable Actions (executed via unified VM pointer handler)
            if (g.type === 'clickable' || g.type === 'holdable') {
              el.style.cursor = 'pointer';
              el.setAttribute(g.type === 'holdable' ? 'data-declarative-holdable' : 'data-declarative-clickable', 'true');
            }
            // B. Declarative 3D Trackball Orbit (Yaw + Pitch)
            else if (g.type === 'trackball' || g.axis === 'trackball') {
              if (el !== this.stageSvg) el.style.cursor = 'grab';
              el.setAttribute('data-declarative-trackball', 'true');
              if (g.yawVar) el.setAttribute('data-yaw-var', g.yawVar);
              if (g.pitchVar) el.setAttribute('data-pitch-var', g.pitchVar);
              el.setAttribute('data-pitch-min', String(g.pitchMin !== undefined ? g.pitchMin : -65));
              el.setAttribute('data-pitch-max', String(g.pitchMax !== undefined ? g.pitchMax : 65));
            }
            // C. Declarative 2D Rotatable Disk
            else if (g.type === 'rotatable' || g.type === 'rotate' || g.action === 'rotate' || g.axis === 'rotate' || g.axis === 'angular') {
              el.style.cursor = 'grab';
              el.setAttribute('data-draggable', 'rotate');
              el.setAttribute('data-gesture-cx', String(g.cx !== undefined ? g.cx : 400));
              el.setAttribute('data-gesture-cy', String(g.cy !== undefined ? g.cy : 240));
              if (g.var) el.setAttribute('data-gesture-var', g.var);
            }
            // D. Declarative 1D/2D Slider or Draggable Node
            else {
              el.style.cursor = g.axis === 'y' ? 'ns-resize' : (g.axis === 'x' ? 'ew-resize' : 'grab');
              el.setAttribute('data-draggable', 'generic');
              el.setAttribute('data-gesture-axis', g.axis || 'xy');
              if (g.minX !== undefined) el.setAttribute('data-gesture-min-x', String(g.minX));
              if (g.maxX !== undefined) el.setAttribute('data-gesture-max-x', String(g.maxX));
              if (g.minY !== undefined) el.setAttribute('data-gesture-min-y', String(g.minY));
              if (g.maxY !== undefined) el.setAttribute('data-gesture-max-y', String(g.maxY));
              if (typeof g.step === 'number') el.setAttribute('data-gesture-step', String(g.step));
              if (g.invert === true) el.setAttribute('data-gesture-invert', 'true');
              if (g.relative === true) el.setAttribute('data-gesture-relative', 'true');
              if (g.seek === true) el.setAttribute('data-gesture-seek', 'true');
              if (g.tone) el.setAttribute('data-gesture-tone', String(g.tone));
              if (g.var) el.setAttribute('data-gesture-var', g.var);
              if (g.varX) el.setAttribute('data-gesture-var-x', g.varX);
              if (g.varY) el.setAttribute('data-gesture-var-y', g.varY);
            }
          });
        });
      }
    }

    /**
     * Primary PointerDown Handler
     */
    handlePointerDown(e) {
      if (this.engine && this.engine.isAiDemonstrating) {
        this.engine.preemptAiDemonstration('USER_CANVAS_TOUCH');
      }

      if (e.target.closest('#stage-glass-hud-ui') || e.target.closest('.interactive-card')) {
        return;
      }

      // Focus stage/window immediately on canvas interaction so declarative keyboard gestures work
      if (this.stageSvg && typeof this.stageSvg.focus === 'function') {
        try { this.stageSvg.focus({ preventScroll: true }); } catch (_) {
          try { this.stageSvg.focus(); } catch (_) {}
        }
      }
      if (typeof window !== 'undefined' && typeof window.focus === 'function') {
        try { window.focus(); } catch (_) {}
      }

      const svgPt = this.screenToSvg(e.clientX, e.clientY);

      // A. If Whiteboard Pen Mode is active, draw ink stroke or erase
      if (this.isPenActive) {
        if (this.currentTool === 'eraser') {
          e.preventDefault();
          this.eraseStrokeAt(svgPt);
          return;
        }
        if (this.stylusOnlyMode && e.pointerType !== 'pen') {
          // Touch in stylus-only mode falls through to direct apparatus drag
        } else {
          e.preventDefault();
          this.isDrawing = true;
          this.startInkStroke(svgPt);
          return;
        }
      }

      // B0. Generic Declarative S-Expression Gestures (:clickable, :holdable & :trackball)
      const scene = this.engine && this.engine.scene;
      const gestures = (scene && Array.isArray(scene.gestures)) ? scene.gestures : [];

      // 1. Declarative :clickable / :holdable tuples (process ALL matching tuples on target)
      const matchedPointerGestures = [];
      const matchedEls = [];
      for (let i = 0; i < gestures.length; i++) {
        const g = gestures[i];
        if ((g.type !== 'clickable' && g.type !== 'holdable') || !g.target) continue;
        const hitEl = e.target.closest(g.target);
        if (!hitEl) continue;
        matchedPointerGestures.push(g);
        matchedEls.push(hitEl);
      }

      if (matchedPointerGestures.length > 0) {
        e.preventDefault();
        this._ensureInteractiveSimPlaying();
        let needsHoldLoop = false;

        for (let i = 0; i < matchedPointerGestures.length; i++) {
          const g = matchedPointerGestures[i];
          this._applyGesturePress(g, matchedEls[i], scene);
          if (g.type === 'holdable' || g.hold === true || g.holdVar || g.stepVar || typeof g.step === 'string') {
            needsHoldLoop = true;
          }
        }

        if (needsHoldLoop) {
          const pointerId = e.pointerId !== undefined ? e.pointerId : 'mouse';
          const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
          this._heldPointerEntries.set(pointerId, {
            gestures: matchedPointerGestures,
            matchedEls,
            pressedAt: now
          });
          if (e.pointerId !== undefined && this.stageSvg && typeof this.stageSvg.setPointerCapture === 'function') {
            try { this.stageSvg.setPointerCapture(e.pointerId); } catch (_) {}
          }
          this._ensureHoldLoop();
        }

        if (this.engine) {
          if (typeof this.engine.applyBindings === 'function') {
            this.engine.applyBindings(this.engine.progress || 0);
          } else if (typeof this.engine.render === 'function') {
            this.engine.render();
          }
        }
        if (!matchedPointerGestures.some(g => Boolean(g.tone))) {
          this.playAudioTone(520, 'sine', 0.04, 0.1);
        }
        this.createTouchRipple(svgPt.x, svgPt.y);
        return;
      }

      // 2. Declarative :trackball tuples (purely driven by scene.gestures)
      const activeTrackball = gestures.find(g => {
        if (g.type !== 'trackball' || !g.target) return false;
        if (this.isXRayActive && e.target.closest('[data-pedagogical]')) return false;
        const tbEl = e.target.closest(g.target);
        if (!tbEl) return false;
        // Yield if user clicked a more specific interactive child control inside a broad stage trackball
        const childControl = e.target.closest('[data-declarative-clickable], [data-declarative-holdable], [data-draggable], [data-interactive], [data-bind-input], .ast-hotspot');
        if (childControl && childControl !== tbEl && tbEl.contains(childControl)) {
          return false;
        }
        return true;
      });
      if (activeTrackball) {
        e.preventDefault();
        this.isDragging = true;
        this.dragMode = 'trackball';
        this.dragTarget = e.target.closest(activeTrackball.target);
        this.dragStart = { x: e.clientX, y: e.clientY };
        const hasVars = Boolean(this.engine && this.engine.vars);
        this.trackballYawVar = activeTrackball.yawVar || activeTrackball['yaw-var'] || null;
        this.trackballPitchVar = activeTrackball.pitchVar || activeTrackball['pitch-var'] || null;
        this.trackballPitchMin = typeof activeTrackball.pitchMin === 'number' ? activeTrackball.pitchMin : -65;
        this.trackballPitchMax = typeof activeTrackball.pitchMax === 'number' ? activeTrackball.pitchMax : 65;
        this.trackballStartYaw = (this.trackballYawVar && hasVars && typeof this.engine.vars[this.trackballYawVar] === 'number')
          ? this.engine.vars[this.trackballYawVar] : 0;
        this.trackballStartPitch = (this.trackballPitchVar && hasVars && typeof this.engine.vars[this.trackballPitchVar] === 'number')
          ? this.engine.vars[this.trackballPitchVar] : 32;
        this.trackballStartCamYaw = (this.engine && this.engine.cameraOrbit) ? (Number(this.engine.cameraOrbit.yawOffset) || 0) : 0;
        this.trackballStartCamPitch = (this.engine && this.engine.cameraOrbit) ? (Number(this.engine.cameraOrbit.pitchOffset) || 0) : 0;
        if (hasVars && 'autoSpin' in this.engine.vars) {
          if (typeof this.engine.setVar === 'function') this.engine.setVar('autoSpin', false);
          else this.engine.vars.autoSpin = false;
        }
        if (e.pointerId !== undefined && this.stageSvg && typeof this.stageSvg.setPointerCapture === 'function') {
          try { this.stageSvg.setPointerCapture(e.pointerId); } catch (_) {}
        }
        if (this.dragTarget && this.dragTarget !== this.stageSvg) {
          this.dragTarget.style.cursor = 'grabbing';
        }
        this.createTouchRipple(svgPt.x, svgPt.y);
        return;
      }

      // B. Declarative Direct-Grab Targets (:draggable, :rotatable, data-bind-input)
      const target = e.target.closest('[data-draggable], [data-bind-input]');

      if (target) {
        e.preventDefault();
        try {
          this.stageSvg.setPointerCapture(e.pointerId);
        } catch {}

        this.isDragging = true;
        this.dragTarget = target;
        this.dragStart = { x: svgPt.x, y: svgPt.y };

        if (target.hasAttribute('data-bind-input') || (this.engine && this.engine.activeBindInputs && this.engine.activeBindInputs.some(b => b.node === target || b.target === '#' + target.id || (target.id && b.target === target.id)))) {
          this.dragMode = 'bind-input';
          target.style.cursor = 'grabbing';
          this.playAudioTone(380, 'sine', 0.05);
        } else if (target.getAttribute('data-draggable') === 'generic' || target.closest('[data-draggable="generic"]')) {
          const genTarget = target.getAttribute('data-draggable') === 'generic' ? target : target.closest('[data-draggable="generic"]');
          this.dragTarget = genTarget;
          this.dragMode = 'generic';
          genTarget.style.cursor = 'grabbing';
          const isContinuousScene = Boolean(this.engine && (this.engine.isContinuousSim || (this.engine.scene && (this.engine.scene.continuous || this.engine.scene.isContinuous || this.engine.scene.type === 'Sim'))));
          if (this.engine && !isContinuousScene && this.engine.isPlaying) {
            this._wasPlayingBeforeDrag = true;
            this.engine.pause();
          }
          let initX = 0;
          let initY = 0;
          const tr = genTarget.getAttribute('transform') || '';
          const trM = /translate\(\s*([\d\.\-]+)(?:[\s,]+([\d\.\-]+))?\s*\)/i.exec(tr);
          const initTx = trM ? parseFloat(trM[1]) : 0;
          const initTy = (trM && trM[2]) ? parseFloat(trM[2]) : 0;
          try {
            const bbox = genTarget.getBBox();
            initX = bbox.x;
            initY = bbox.y;
          } catch (_) {
            initX = parseFloat(genTarget.getAttribute('x') || genTarget.getAttribute('cx') || '0');
            initY = parseFloat(genTarget.getAttribute('y') || genTarget.getAttribute('cy') || '0');
          }
          const gVarName = genTarget.getAttribute('data-gesture-var');
          const initVarVal = (gVarName && this.engine && this.engine.vars && typeof this.engine.vars[gVarName] === 'number')
            ? this.engine.vars[gVarName]
            : undefined;
          this.targetInitial = {
            transform: tr,
            initTx,
            initTy,
            x: initX,
            y: initY,
            initVarVal
          };
          this.playAudioTone(380, 'triangle', 0.06);
        } else if (target.getAttribute('data-draggable') === 'rotate' || target.closest('[data-draggable="rotate"]')) {
          const rotTarget = target.getAttribute('data-draggable') === 'rotate' ? target : target.closest('[data-draggable="rotate"]');
          this.dragTarget = rotTarget;
          this.dragMode = 'rotate';
          rotTarget.style.cursor = 'grabbing';
          this.playAudioTone(380, 'triangle', 0.06);
        }

        this.createTouchRipple(svgPt.x, svgPt.y);
      } else if (this.isXRayActive) {
        const pedNode = e.target.closest('[data-pedagogical]');
        if (pedNode) {
          this.showXRayPopup(pedNode.getAttribute('data-pedagogical'), svgPt.x, svgPt.y, pedNode);
        }
      }
    }

    /**
     * Primary PointerMove Handler with Native Browser C++ Hardware Event Coalescing
     */
    handlePointerMove(e) {
      const rawEvents = (typeof e.getCoalescedEvents === 'function') ? e.getCoalescedEvents() : [e];
      const eventsToProcess = (rawEvents && rawEvents.length > 0) ? rawEvents : [e];

      // A. Whiteboard Pen Drawing: Process every hardware coordinate
      if (this.isDrawing && this.currentStroke) {
        e.preventDefault();
        for (let i = 0; i < eventsToProcess.length; i++) {
          const subEv = eventsToProcess[i];
          const svgPt = this.screenToSvg(subEv.clientX, subEv.clientY);
          this.continueInkStroke(svgPt);
        }
        return;
      }

      // Whiteboard Eraser continuous scrubbing while dragging
      if (this.isPenActive && this.currentTool === 'eraser' && (e.buttons > 0 || (e.pressure && e.pressure > 0))) {
        e.preventDefault();
        for (let i = 0; i < eventsToProcess.length; i++) {
          const subEv = eventsToProcess[i];
          const svgPt = this.screenToSvg(subEv.clientX, subEv.clientY);
          this.eraseStrokeAt(svgPt);
        }
        return;
      }

      const latestEv = eventsToProcess[eventsToProcess.length - 1];
      const svgPt = this.screenToSvg(latestEv.clientX, latestEv.clientY);

      // B. Direct Canvas Dragging
      if (this.isDragging && this.dragTarget) {
        e.preventDefault();

        if (this.dragMode === 'bind-input') {
          this.handleBindInputDrag(this.dragTarget, svgPt);
        } else if (this.dragMode === 'generic') {
          this.handleGenericDrag(this.dragTarget, svgPt);
        } else if (this.dragMode === 'rotate') {
          this.handleRotateDrag(this.dragTarget, svgPt);
        } else if (this.dragMode === 'trackball') {
          this.handleTrackballDrag(e);
        }
      } else if (this.isXRayActive) {
        const pedNode = e.target.closest('[data-pedagogical]');
        if (pedNode) {
          this.showXRayPopup(pedNode.getAttribute('data-pedagogical'), svgPt.x, svgPt.y, pedNode);
        } else {
          this.hideXRayPopup();
        }
      }

      // C. Direct Analytic Ray-Math: Update cursor ray hit for spatial proprioception
      if (this.engine && typeof this.engine.updateCursorRay === 'function' && !this.isDrawing && !this.isDragging) {
        const now = performance.now();
        if (!this._lastRayCastTime || (now - this._lastRayCastTime > 120)) {
          this._lastRayCastTime = now;
          this.engine.updateCursorRay(svgPt.x, svgPt.y);
        }
      }
    }

    /**
     * Primary PointerUp Handler
     */
    handlePointerUp(e) {
      const pointerId = e && e.pointerId !== undefined ? e.pointerId : 'mouse';
      const didResetHold = this._releasePointerEntry(pointerId);
      if (didResetHold && this.engine && typeof this.engine.applyBindings === 'function') {
        this.engine.applyBindings(this.engine.progress || 0, 0, false);
      }
      if (e && e.pointerId !== undefined && this.stageSvg && typeof this.stageSvg.releasePointerCapture === 'function') {
        try { this.stageSvg.releasePointerCapture(e.pointerId); } catch {}
      }

      if (this.isDrawing) {
        this.isDrawing = false;
        this.endInkStroke();
      }

      if (this.isDragging && this.dragTarget) {
        if (this.dragMode === 'bind-input') {
          this.dragTarget.style.cursor = 'grab';
          this.playAudioTone(520, 'sine', 0.04);
        } else if (this.dragMode === 'generic') {
          const axis = this.dragTarget.getAttribute('data-gesture-axis') || 'xy';
          this.dragTarget.style.cursor = axis === 'y' ? 'ns-resize' : (axis === 'x' ? 'ew-resize' : 'grab');
          this.playAudioTone(440, 'sine', 0.05);
          if (this.engine && !this.engine.isPlaying && this._wasPlayingBeforeDrag) {
            this.engine.play();
          }
        } else if (this.dragMode === 'rotate') {
          if (this.dragTarget) this.dragTarget.style.cursor = 'grab';
          this.playAudioTone(440, 'sine', 0.05);
        } else if (this.dragMode === 'trackball') {
          if (this.dragTarget && this.dragTarget !== this.stageSvg) this.dragTarget.style.cursor = 'grab';
          this.playAudioTone(440, 'triangle', 0.04, 0.1);
        }

        this.isDragging = false;
        this.dragTarget = null;
        this.dragMode = null;
        this._wasPlayingBeforeDrag = false;
      }
    }

    handlePointerCancel(e) {
      this._releaseAllHeldInputs(true);
      this.handlePointerUp(e);
    }

    handleTrackballDrag(e) {
      if (!this.engine) return;
      const dx = e.clientX - this.dragStart.x;
      const dy = e.clientY - this.dragStart.y;
      const yawKey = this.trackballYawVar;
      const pitchKey = this.trackballPitchVar;
      const pMin = typeof this.trackballPitchMin === 'number' ? this.trackballPitchMin : -65;
      const pMax = typeof this.trackballPitchMax === 'number' ? this.trackballPitchMax : 65;
      const scene = this.engine.scene;

      if (yawKey && this.engine.vars) {
        const bounds = this._resolveVarBounds(scene, {}, yawKey);
        const rawYaw = this.trackballStartYaw + dx * 0.8;
        let nextYaw;
        if (Number.isFinite(bounds.min) && Number.isFinite(bounds.max) && bounds.min < 0) {
          const span = bounds.max - bounds.min || 360;
          const wrapped = ((((rawYaw - bounds.min) % span) + span) % span) + bounds.min;
          nextYaw = Math.round(wrapped);
        } else {
          nextYaw = Math.round(((rawYaw % 360) + 360) % 360);
        }
        this._writeEngineVar(yawKey, nextYaw);
      }

      if (pitchKey && this.engine.vars) {
        const newPitch = Math.max(pMin, Math.min(pMax, this.trackballStartPitch - dy * 0.5));
        this._writeEngineVar(pitchKey, Math.round(newPitch));
      }

      if (scene && (scene.camera || scene.has3D)) {
        if (!this.engine.cameraOrbit) {
          this.engine.cameraOrbit = { yawOffset: 0, pitchOffset: 0, distanceScale: 1.0 };
        }
        if (!yawKey) {
          this.engine.cameraOrbit.yawOffset = (this.trackballStartCamYaw || 0) + dx * 0.7;
        }
        if (!pitchKey) {
          this.engine.cameraOrbit.pitchOffset = Math.max(
            pMin,
            Math.min(pMax, (this.trackballStartCamPitch || 0) - dy * 0.5)
          );
        }
      }

      if (typeof this.engine.applyBindings === 'function') {
        this.engine.applyBindings(this.engine.progress || 0);
      }
    }

    handleGenericDrag(target, svgPt) {
      if (!target) return;

      const axis = target.getAttribute('data-gesture-axis') || 'xy';
      const minX = parseFloat(target.getAttribute('data-gesture-min-x') || '0');
      const maxX = parseFloat(target.getAttribute('data-gesture-max-x') || '800');
      const minY = parseFloat(target.getAttribute('data-gesture-min-y') || '0');
      const maxY = parseFloat(target.getAttribute('data-gesture-max-y') || '480');
      const varName = target.getAttribute('data-gesture-var');
      const varX = target.getAttribute('data-gesture-var-x');
      const varY = target.getAttribute('data-gesture-var-y');
      const attrStepRaw = target.getAttribute('data-gesture-step');
      const attrStep = attrStepRaw !== null ? parseFloat(attrStepRaw) : NaN;
      const isInverted = target.getAttribute('data-gesture-invert') === 'true';
      const isRelative = target.getAttribute('data-gesture-relative') === 'true';
      const isSeek = target.getAttribute('data-gesture-seek') === 'true';
      const dragTone = target.getAttribute('data-gesture-tone');

      const initTx = (this.targetInitial && this.targetInitial.initTx) || 0;
      const initTy = (this.targetInitial && this.targetInitial.initTy) || 0;
      const initX = (this.targetInitial && this.targetInitial.x) || 0;
      const initY = (this.targetInitial && this.targetInitial.y) || 0;

      const dx = svgPt.x - this.dragStart.x;
      const dy = svgPt.y - this.dragStart.y;

      let targetTx = initTx + (axis !== 'y' ? dx : 0);
      let targetTy = initTy + (axis !== 'x' ? dy : 0);
      let effectiveX = targetTx;
      let effectiveY = targetTy;

      const hasBoundsX = !Number.isNaN(minX) && !Number.isNaN(maxX) && maxX > minX;
      const useAbsX = hasBoundsX && initTx === 0 && minX >= 0 && initX >= minX - 20;
      if (axis === 'x' || axis === 'xy') {
        if (hasBoundsX) {
          if (useAbsX) {
            const absX = Math.max(minX, Math.min(maxX, initX + dx));
            targetTx = absX - initX;
            effectiveX = absX;
          } else {
            targetTx = Math.max(minX, Math.min(maxX, targetTx));
            effectiveX = targetTx;
          }
        }
      }

      const hasBoundsY = !Number.isNaN(minY) && !Number.isNaN(maxY) && maxY > minY;
      const useAbsY = hasBoundsY && initTy === 0 && minY >= 0 && initY >= minY - 20;
      if (axis === 'y' || axis === 'xy') {
        if (hasBoundsY) {
          if (useAbsY) {
            const absY = Math.max(minY, Math.min(maxY, initY + dy));
            targetTy = absY - initY;
            effectiveY = absY;
          } else {
            targetTy = Math.max(minY, Math.min(maxY, targetTy));
            effectiveY = targetTy;
          }
        }
      }

      if (!isRelative) {
        target.setAttribute('transform', `translate(${targetTx.toFixed(1)}, ${targetTy.toFixed(1)})`);
      }

      if (varX && axis !== 'y') {
        let coordX;
        if (initTx !== 0 || (hasBoundsX && minX < 0) || useAbsX) {
          coordX = effectiveX;
        } else {
          coordX = hasBoundsX ? Math.max(minX, Math.min(maxX, svgPt.x)) : svgPt.x;
        }
        this._writeEngineVar(varX, Math.round(coordX));
      }

      if (varY && axis !== 'x') {
        let coordY;
        if (initTy !== 0 || (hasBoundsY && minY < 0) || useAbsY) {
          coordY = effectiveY;
        } else {
          coordY = hasBoundsY ? Math.max(minY, Math.min(maxY, svgPt.y)) : svgPt.y;
        }
        this._writeEngineVar(varY, Math.round(coordY));
      }

      let ratio;
      if (axis === 'xy' && isSeek && hasBoundsX && hasBoundsY) {
        const sx = minX;
        const ex = maxX;
        const sy = isInverted ? maxY : minY;
        const ey = isInverted ? minY : maxY;
        const segDx = ex - sx;
        const segDy = ey - sy;
        const segLenSq = (segDx * segDx + segDy * segDy) || 1;
        const px = (initTx !== 0 ? initTx + dx : svgPt.x) - sx;
        const py = (initTy !== 0 ? initTy + dy : svgPt.y) - sy;
        ratio = Math.max(0, Math.min(1, (px * segDx + py * segDy) / segLenSq));
      } else {
        ratio = axis === 'y'
          ? Math.max(0, Math.min(1, (effectiveY - minY) / ((maxY - minY) || 1)))
          : Math.max(0, Math.min(1, (effectiveX - minX) / ((maxX - minX) || 1)));
        if (isInverted) ratio = 1 - ratio;
      }

      if (varName) {
        let vMin = 0;
        let vMax = 100;
        let stepVal = (!Number.isNaN(attrStep) && attrStep > 0) ? attrStep : 1;
        let foundConfig = false;

        const sceneInputs = this.engine && this.engine.scene && this.engine.scene.inputs;
        if (Array.isArray(sceneInputs)) {
          const inp = sceneInputs.find(i => i && i.var === varName);
          if (inp) {
            if (typeof inp.min === 'number') vMin = inp.min;
            if (typeof inp.max === 'number') vMax = inp.max;
            if (typeof inp.step === 'number' && Number.isNaN(attrStep)) stepVal = inp.step;
            foundConfig = true;
          }
        }

        if (!foundConfig && this.engine && this.engine.scene && this.engine.scene.vars) {
          const rawVar = this.engine.scene.vars[varName];
          if (rawVar && typeof rawVar === 'object') {
            if (typeof rawVar.min === 'number') vMin = rawVar.min;
            if (typeof rawVar.max === 'number') vMax = rawVar.max;
            if (typeof rawVar.step === 'number' && Number.isNaN(attrStep)) stepVal = rawVar.step;
          }
        }

        let mapped;
        if (isRelative && this.targetInitial && typeof this.targetInitial.initVarVal === 'number') {
          const spanPx = axis === 'y' ? ((maxY - minY) || 1) : ((maxX - minX) || 1);
          const rawDelta = axis === 'y' ? (isInverted ? -dy : dy) : (isInverted ? -dx : dx);
          mapped = this.targetInitial.initVarVal + (rawDelta / spanPx) * (vMax - vMin);
        } else {
          mapped = vMin + ratio * (vMax - vMin);
        }
        const rawStepped = stepVal > 0
          ? (vMin + Math.round((mapped - vMin) / stepVal) * stepVal)
          : mapped;
        const clampedVal = Math.max(vMin, Math.min(vMax, rawStepped));
        const decimals = (String(stepVal).split('.')[1] || '').length;
        const finalVal = Number(clampedVal.toFixed(Math.min(6, decimals)));
        const prevVal = this.engine && this.engine.vars ? this.engine.vars[varName] : undefined;
        this._writeEngineVar(varName, finalVal);

        if (dragTone && finalVal !== prevVal && typeof this.playAudioTone === 'function') {
          const now = Date.now();
          if (!this._lastDragToneAt || now - this._lastDragToneAt > 45) {
            this._lastDragToneAt = now;
            const hz = parseFloat(dragTone);
            if (!Number.isNaN(hz)) this.playAudioTone(hz, 'triangle', 0.04, 0.1);
          }
        }
      }

      if (this.engine && Array.isArray(this.engine.activeBindings)) {
        for (let i = 0; i < this.engine.activeBindings.length; i++) {
          const b = this.engine.activeBindings[i];
          if (b && b.node === target) b.lastVal = undefined;
        }
      }

      if (isSeek && this.engine && typeof this.engine.seek === 'function') {
        this.engine.seek(ratio);
      } else if (this.engine && typeof this.engine.applyBindings === 'function') {
        this.engine.applyBindings(this.engine.progress || 0);
      }
    }

    handleRotateDrag(target, svgPt) {
      if (!target) return;
      const cx = parseFloat(target.getAttribute('data-gesture-cx') || '400');
      const cy = parseFloat(target.getAttribute('data-gesture-cy') || '240');
      const varName = target.getAttribute('data-gesture-var');
      const angleRad = Math.atan2(svgPt.y - cy, svgPt.x - cx);
      let angleDeg = angleRad * (180 / Math.PI);
      if (angleDeg < 0) angleDeg += 360;
      target.setAttribute('transform', `rotate(${angleDeg.toFixed(1)} ${cx} ${cy})`);
      if (varName) {
        this._writeEngineVar(varName, parseFloat(angleDeg.toFixed(1)));
      }
      if (this.engine && typeof this.engine.applyBindings === 'function') {
        this.engine.applyBindings(this.engine.progress || 0);
      }
    }

    // =========================================================================
    // Bidirectional Slider-to-Variable Stage Binding Drag
    // =========================================================================
    handleBindInputDrag(target, svgPt) {
      if (!this.engine || !this.engine.activeBindInputs) return;
      const binding = this.engine.activeBindInputs.find(b => b.node === target || b.target === '#' + target.id || (target.id && b.target === target.id));
      if (!binding) return;

      const axis = binding.axis || 'x';
      const tMin = binding.trackMin !== undefined ? binding.trackMin : (axis === 'y' ? 320 : 60);
      const tMax = binding.trackMax !== undefined ? binding.trackMax : (axis === 'y' ? 80 : 440);
      let ratio = 0;

      if (axis === 'y') {
        const minY = Math.min(tMin, tMax);
        const maxY = Math.max(tMin, tMax);
        const clampedY = Math.max(minY, Math.min(maxY, svgPt.y));
        ratio = (clampedY - tMin) / (tMax - tMin);
        target.setAttribute('transform', `translate(0, ${clampedY.toFixed(1)})`);
      } else if (axis === 'rotary') {
        const center = { x: binding.originX || 0, y: binding.originY || 0 };
        const angleRad = Math.atan2(svgPt.y - center.y, svgPt.x - center.x);
        let angleDeg = (angleRad * 180 / Math.PI) + 90;
        if (angleDeg < -135) angleDeg = -135;
        if (angleDeg > 135) angleDeg = 135;
        ratio = (angleDeg + 135) / 270;
        target.setAttribute('transform', `rotate(${angleDeg.toFixed(1)} ${center.x} ${center.y})`);
      } else {
        const minX = Math.min(tMin, tMax);
        const maxX = Math.max(tMin, tMax);
        const clampedX = Math.max(minX, Math.min(maxX, svgPt.x));
        ratio = (clampedX - tMin) / (tMax - tMin);
        target.setAttribute('transform', `translate(${clampedX.toFixed(1)}, 0)`);
      }

      ratio = Math.max(0, Math.min(1, ratio));
      const val = binding.min + ratio * (binding.max - binding.min);
      this.engine.setVar(binding.var, Number(val.toFixed(2)));
    }

    // =========================================================================
    // Whiteboard & Stylus Pen Ink Drawing Layer (Promethean / SMART / iPads)
    // =========================================================================
    startInkStroke(pt) {
      if (!this.inkRoot) return;
      const x = Number(pt.x.toFixed(1));
      const y = Number(pt.y.toFixed(1));
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('fill', 'none');
      path.setAttribute('stroke', this.currentInkColor);
      path.setAttribute('stroke-width', this.currentInkWidth.toString());

      if (this.currentTool === 'highlighter') {
        path.setAttribute('stroke-opacity', '0.45');
        path.setAttribute('stroke-linecap', 'square');
        path.setAttribute('stroke-linejoin', 'bevel');
        path.style.mixBlendMode = 'multiply';
      } else if (this.currentTool === 'marker') {
        path.setAttribute('stroke-linecap', 'round');
        path.setAttribute('stroke-linejoin', 'round');
        path.setAttribute('stroke-opacity', '0.92');
      } else {
        path.setAttribute('stroke-linecap', 'round');
        path.setAttribute('stroke-linejoin', 'round');
        path.setAttribute('stroke-opacity', '1.0');
      }

      path.setAttribute('d', `M ${x} ${y} `);

      this.inkRoot.appendChild(path);
      const strokeObj = {
        id: `stroke_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        element: path,
        tool: this.currentTool || 'pen',
        color: this.currentInkColor,
        width: this.currentInkWidth,
        d: `M ${x} ${y} `,
        points: [{ x, y }],
        lastX: pt.x,
        lastY: pt.y
      };
      this.currentStroke = strokeObj;
      this.strokes.push(strokeObj);
      this._undoStack = [];
    }

    continueInkStroke(pt) {
      if (!this.currentStroke) return;
      const x = Number(pt.x.toFixed(1));
      const y = Number(pt.y.toFixed(1));
      const midX = (this.currentStroke.lastX + pt.x) / 2;
      const midY = (this.currentStroke.lastY + pt.y) / 2;
      this.currentStroke.d += `Q ${this.currentStroke.lastX.toFixed(1)} ${this.currentStroke.lastY.toFixed(1)}, ${midX.toFixed(1)} ${midY.toFixed(1)} `;
      this.currentStroke.element.setAttribute('d', this.currentStroke.d);
      this.currentStroke.points.push({ x, y });
      this.currentStroke.lastX = pt.x;
      this.currentStroke.lastY = pt.y;
    }

    endInkStroke() {
      if (!this.currentStroke) return;
      this.currentStroke = null;
      this.persistInkToSession();
    }

    eraseStrokeAt(pt) {
      if (!this.inkRoot || this.strokes.length === 0) return;
      const eraseRadius = Math.max(16, this.currentInkWidth * 2.5);
      const eraseRadiusSq = eraseRadius * eraseRadius;

      let erasedAny = false;
      for (let i = this.strokes.length - 1; i >= 0; i--) {
        const s = this.strokes[i];
        if (!s || !s.points) continue;

        let hit = false;
        for (let j = 0; j < s.points.length; j++) {
          const p = s.points[j];
          const dx = p.x - pt.x;
          const dy = p.y - pt.y;
          if (dx * dx + dy * dy <= eraseRadiusSq) {
            hit = true;
            break;
          }
        }

        if (hit) {
          const removed = this.strokes.splice(i, 1)[0];
          if (removed && removed.element && removed.element.parentNode) {
            removed.element.parentNode.removeChild(removed.element);
          }
          if (!this._undoStack) this._undoStack = [];
          this._undoStack.push(removed);
          erasedAny = true;
        }
      }

      if (erasedAny) {
        this.persistInkToSession();
        this.playAudioTone(220, 'sine', 0.04);
      }
    }

    undoLastStroke() {
      if (!this.inkRoot || this.strokes.length === 0) return;
      const last = this.strokes.pop();
      if (last) {
        const el = last.element || (last instanceof Element ? last : null);
        if (el && el.parentNode) {
          el.parentNode.removeChild(el);
        }
        if (!this._undoStack) this._undoStack = [];
        this._undoStack.push(last);
      }
      this.persistInkToSession();
      this.playAudioTone(330, 'sine', 0.05);
    }

    redoLastStroke() {
      if (!this.inkRoot || !this._undoStack || this._undoStack.length === 0) return;
      const restored = this._undoStack.pop();
      if (restored) {
        if (restored.element) {
          this.inkRoot.appendChild(restored.element);
        }
        this.strokes.push(restored);
        this.persistInkToSession();
        this.playAudioTone(523, 'sine', 0.05);
      }
    }

    clearWhiteboardInk() {
      if (!this.inkRoot) return;
      if (this.strokes.length > 0) {
        if (!this._undoStack) this._undoStack = [];
        this._undoStack.push(...this.strokes);
      }
      if (typeof this.inkRoot.replaceChildren === 'function') this.inkRoot.replaceChildren();
      else this.inkRoot.textContent = '';
      this.strokes = [];
      this.persistInkToSession();
      this.playAudioTone(440, 'triangle', 0.1);
    }

    exportInkToAST(options = {}) {
      const sceneId = (this.engine && this.engine.activePresetId) || 'whiteboard-session';
      const timestamp = Date.now();
      const strokeLines = [];

      for (let i = 0; i < this.strokes.length; i++) {
        const s = this.strokes[i];
        const color = s.color || (s.element && s.element.getAttribute('stroke')) || this.currentInkColor;
        const width = s.width || (s.element && parseFloat(s.element.getAttribute('stroke-width'))) || this.currentInkWidth;
        const d = (s.d || (s.element && s.element.getAttribute('d')) || '').trim();
        const pts = s.points || [];
        const ptsStr = pts.map(p => `(${p.x.toFixed(1)} ${p.y.toFixed(1)})`).join(' ');

        strokeLines.push(`    (:ink-stroke :color "${color}" :width ${width} :d "${d}" :points (${ptsStr}))`);
      }

      if (options.bareStrokes) {
        return strokeLines.join('\n');
      }

      return `(:ink-session
  :scene-id "${sceneId}"
  :timestamp ${timestamp}
  :stroke-count ${this.strokes.length}
  (:strokes (
${strokeLines.join('\n')}
  ))
)`;
    }

    importInkFromAST(astString, options = {}) {
      if (!astString || typeof astString !== 'string') return 0;
      if (!this.inkRoot) this.setupDomLayers();
      if (!this.inkRoot) return 0;

      if (options.clearExisting !== false) {
        if (typeof this.inkRoot.replaceChildren === 'function') this.inkRoot.replaceChildren();
        else this.inkRoot.textContent = '';
        this.strokes = [];
      }

      let importedCount = 0;
      const strokeBlocks = [];
      let pos = 0;
      while ((pos = astString.indexOf('(:ink-stroke', pos)) !== -1) {
        let depth = 0;
        let inQuote = false;
        let escape = false;
        let end = pos;
        for (let i = pos; i < astString.length; i++) {
          const ch = astString[i];
          if (escape) { escape = false; continue; }
          if (ch === '\\') { escape = true; continue; }
          if (ch === '"') { inQuote = !inQuote; continue; }
          if (!inQuote) {
            if (ch === '(') depth++;
            else if (ch === ')') {
              depth--;
              if (depth === 0) {
                end = i + 1;
                break;
              }
            }
          }
        }
        if (end > pos) {
          strokeBlocks.push(astString.slice(pos, end));
          pos = end;
        } else {
          pos += 12;
        }
      }

      for (let b = 0; b < strokeBlocks.length; b++) {
        const body = strokeBlocks[b];

        const colorMatch = body.match(/:color\s+"([^"]+)"/);
        const color = colorMatch ? colorMatch[1] : '#facc15';

        const widthMatch = body.match(/:width\s+([0-9.]+)/);
        const width = widthMatch ? parseFloat(widthMatch[1]) : 3.5;

        const dMatch = body.match(/:d\s+"([^"]+)"/);
        let d = dMatch ? dMatch[1] : '';

        const pointsIdx = body.indexOf(':points');
        const points = [];
        if (pointsIdx !== -1) {
          const afterPoints = body.slice(pointsIdx + 7).trim();
          if (afterPoints.startsWith('(')) {
            let depth = 0;
            let pointsContent = '';
            for (let i = 0; i < afterPoints.length; i++) {
              if (afterPoints[i] === '(') depth++;
              else if (afterPoints[i] === ')') depth--;
              pointsContent += afterPoints[i];
              if (depth === 0) break;
            }
            const ptRegex = /\(\s*([0-9.-]+)\s+([0-9.-]+)\s*\)/g;
            let ptMatch;
            while ((ptMatch = ptRegex.exec(pointsContent)) !== null) {
              points.push({ x: parseFloat(ptMatch[1]), y: parseFloat(ptMatch[2]) });
            }
          }
        }

        if (!d && points.length > 0) {
          d = `M ${points[0].x.toFixed(1)} ${points[0].y.toFixed(1)} `;
          for (let p = 1; p < points.length; p++) {
            const prev = points[p - 1];
            const cur = points[p];
            const midX = (prev.x + cur.x) / 2;
            const midY = (prev.y + cur.y) / 2;
            d += `Q ${prev.x.toFixed(1)} ${prev.y.toFixed(1)}, ${midX.toFixed(1)} ${midY.toFixed(1)} `;
          }
        }

        if (d) {
          const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
          path.setAttribute('fill', 'none');
          path.setAttribute('stroke', color);
          path.setAttribute('stroke-width', width.toString());
          path.setAttribute('stroke-linecap', 'round');
          path.setAttribute('stroke-linejoin', 'round');
          path.setAttribute('d', d);

          this.inkRoot.appendChild(path);

          const strokeObj = {
            id: `stroke_imported_${Date.now()}_${importedCount}`,
            element: path,
            color,
            width,
            d,
            points: points.length > 0 ? points : [],
            lastX: points.length > 0 ? points[points.length - 1].x : 0,
            lastY: points.length > 0 ? points[points.length - 1].y : 0
          };
          this.strokes.push(strokeObj);
          importedCount++;
        }
      }

      this.persistInkToSession();
      if (importedCount > 0) {
        this.playAudioTone(784, 'sine', 0.08);
      }
      return importedCount;
    }

    exportInkToJSON() {
      const sceneId = (this.engine && this.engine.activePresetId) || 'whiteboard-session';
      return {
        type: 'AST_INK_SESSION',
        sceneId,
        timestamp: Date.now(),
        strokeCount: this.strokes.length,
        strokes: this.strokes.map(s => ({
          color: s.color || '#facc15',
          width: s.width || 3.5,
          d: s.d || '',
          points: s.points || []
        }))
      };
    }

    importInkFromJSON(data, options = {}) {
      if (!data || !data.strokes || !Array.isArray(data.strokes)) return 0;
      if (!this.inkRoot) this.setupDomLayers();
      if (!this.inkRoot) return 0;

      if (options.clearExisting !== false) {
        if (typeof this.inkRoot.replaceChildren === 'function') this.inkRoot.replaceChildren();
        else this.inkRoot.textContent = '';
        this.strokes = [];
      }

      let count = 0;
      data.strokes.forEach(s => {
        let d = s.d || '';
        const pts = s.points || [];
        if (!d && pts.length > 0) {
          d = `M ${pts[0].x.toFixed(1)} ${pts[0].y.toFixed(1)} `;
          for (let p = 1; p < pts.length; p++) {
            const prev = pts[p - 1];
            const cur = pts[p];
            const midX = (prev.x + cur.x) / 2;
            const midY = (prev.y + cur.y) / 2;
            d += `Q ${prev.x.toFixed(1)} ${prev.y.toFixed(1)}, ${midX.toFixed(1)} ${midY.toFixed(1)} `;
          }
        }

        if (d) {
          const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
          path.setAttribute('fill', 'none');
          path.setAttribute('stroke', s.color || '#facc15');
          path.setAttribute('stroke-width', (s.width || 3.5).toString());
          path.setAttribute('stroke-linecap', 'round');
          path.setAttribute('stroke-linejoin', 'round');
          path.setAttribute('d', d);

          this.inkRoot.appendChild(path);
          this.strokes.push({
            id: `stroke_json_${Date.now()}_${count}`,
            element: path,
            color: s.color || '#facc15',
            width: s.width || 3.5,
            d,
            points: pts,
            lastX: pts.length > 0 ? pts[pts.length - 1].x : 0,
            lastY: pts.length > 0 ? pts[pts.length - 1].y : 0
          });
          count++;
        }
      });

      this.persistInkToSession();
      if (count > 0) {
        this.playAudioTone(784, 'sine', 0.08);
      }
      return count;
    }

    broadcastInkSession() {
      const ast = this.exportInkToAST();
      const json = this.exportInkToJSON();
      const sceneId = (this.engine && this.engine.activePresetId) || 'whiteboard-session';

      const payload = {
        type: 'AST_WHITEBOARD_INK_BROADCAST',
        sceneId,
        inkAst: ast,
        inkJson: json,
        timestamp: Date.now()
      };

      try {
        if (window.parent && window.parent !== window) {
          window.parent.postMessage(payload, '*');
        }
      } catch {}

      window.dispatchEvent(new CustomEvent('ast-ink-broadcast', { detail: payload }));
      this.showFloatingNotice(`📡 Broadcasted ${this.strokes.length} strokes to Class Mesh!`);
      this.playAudioTone(880, 'sine', 0.1);
    }

    persistInkToSession() {
      const store = typeof globalThis !== 'undefined' ? globalThis.ASTLocalStore : null;
      if (!store) return;
      try {
        const sceneId = (this.engine && this.engine.activePresetId) || 'whiteboard';
        const key = `stj_whiteboard_ink_${sceneId}`;
        if (this.strokes.length === 0) {
          store.removeItem(key);
        } else {
          store.setItem(key, JSON.stringify(this.exportInkToJSON()));
        }
      } catch {}
    }

    restoreInkFromSession() {
      const store = typeof globalThis !== 'undefined' ? globalThis.ASTLocalStore : null;
      if (!store) return;
      const applyRestore = () => {
        try {
          const sceneId = (this.engine && this.engine.activePresetId) || 'whiteboard';
          const key = `stj_whiteboard_ink_${sceneId}`;
          const stored = store.getItem(key);
          if (stored) {
            const parsed = JSON.parse(stored);
            this.importInkFromJSON(parsed, { clearExisting: true });
          }
        } catch {}
      };
      if (store.ready && typeof store.isReady === 'function' && !store.isReady()) {
        store.ready.then(applyRestore);
      } else {
        applyRestore();
      }
    }

    showFloatingNotice(message) {
      const container = (this.stageSvg && this.stageSvg.parentNode) || document.body;
      let toast = container.querySelector('#stage-ink-notice');
      if (!toast) {
        toast = document.createElement('div');
        toast.id = 'stage-ink-notice';
        toast.style.cssText = `
          position: absolute;
          top: 18px;
          left: 50%;
          transform: translateX(-50%);
          background: rgba(15, 23, 42, 0.92);
          backdrop-filter: blur(8px);
          border: 1px solid rgba(56, 189, 248, 0.4);
          color: #f8fafc;
          padding: 6px 16px;
          border-radius: 9999px;
          font-size: 12px;
          font-weight: 700;
          box-shadow: 0 4px 16px rgba(0,0,0,0.4);
          z-index: 50;
          pointer-events: none;
          transition: opacity 0.25s ease, transform 0.25s ease;
        `;
        container.appendChild(toast);
      }
      toast.textContent = message;
      toast.style.opacity = '1';
      toast.style.transform = 'translateX(-50%) translateY(0)';

      clearTimeout(this._inkNoticeTimer);
      this._inkNoticeTimer = setTimeout(() => {
        if (toast) {
          toast.style.opacity = '0';
          toast.style.transform = 'translateX(-50%) translateY(-8px)';
        }
      }, 2500);
    }

    togglePen(forceState) {
      this.isPenActive = (forceState !== undefined) ? Boolean(forceState) : !this.isPenActive;
      const penBtn = document.getElementById('stage-hud-pen-btn');
      if (penBtn) {
        penBtn.style.background = this.isPenActive ? '#eab308' : 'rgba(255, 255, 255, 0.08)';
        penBtn.style.color = this.isPenActive ? '#090d16' : '#ffffff';
      }
      const headerPen = document.getElementById('btn-pen');
      if (headerPen) {
        headerPen.classList.toggle('active', this.isPenActive);
      }
      this.stageSvg.style.cursor = this.isPenActive ? (this.currentTool === 'eraser' ? 'cell' : 'crosshair') : 'default';

      const penTools = document.getElementById('stage-hud-pen-tools');
      const penPalette = document.getElementById('stage-hud-pen-palette');
      const penWidths = document.getElementById('stage-hud-pen-widths');
      const inkExtraActions = document.getElementById('stage-hud-ink-actions');
      const clearBtn = document.getElementById('stage-hud-clear-btn');

      const displayVal = this.isPenActive ? 'flex' : 'none';
      if (penTools) penTools.style.display = displayVal;
      if (penPalette) penPalette.style.display = displayVal;
      if (penWidths) penWidths.style.display = displayVal;
      if (inkExtraActions) inkExtraActions.style.display = displayVal;
      if (clearBtn) clearBtn.style.display = displayVal;

      this.playAudioTone(this.isPenActive ? 660 : 440, 'sine', 0.06);
      this.showFloatingNotice(this.isPenActive ? '🖊️ Whiteboard Marker Active' : 'Whiteboard Inactive');
    }

    // =========================================================================
    // Stage-Embedded Glass HUD Floating Bar
    // =========================================================================
    setupGlassHud() {
      const container = this.stageSvg.parentNode;
      if (!container || container.querySelector('#stage-glass-hud-ui')) return;

      const hud = document.createElement('div');
      hud.id = 'stage-glass-hud-ui';
      hud.style.cssText = `
        position: absolute;
        bottom: 58px;
        right: 14px;
        display: flex;
        align-items: center;
        gap: 5px;
        background: rgba(15, 23, 42, 0.92);
        backdrop-filter: blur(12px);
        padding: 5px 8px;
        border-radius: 9999px;
        border: 1px solid rgba(255, 255, 255, 0.18);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.45);
        z-index: 30;
        user-select: none;
      `;

      // 1. Tool Selection Pills
      const penTools = document.createElement('div');
      penTools.id = 'stage-hud-pen-tools';
      penTools.style.cssText = 'display:none; align-items:center; gap:3px; margin-right:3px;';
      const tools = [
        { id: 'pen', icon: '✏️', title: 'Precision Pen (Smooth 2px-4px)', width: 3.5 },
        { id: 'marker', icon: '🖍️', title: 'Whiteboard Marker (Rich 6px)', width: 6.0 },
        { id: 'highlighter', icon: '✨', title: 'Pedagogical Highlighter (Soft Glow 12px)', width: 12.0 },
        { id: 'eraser', icon: '🧽', title: 'Smart Stroke Eraser', width: 24.0 },
      ];
      const toolBtns = [];
      tools.forEach(t => {
        const btn = this.createHudButton(t.icon, t.title, () => {
          this.currentTool = t.id;
          this.currentInkWidth = t.width;
          this.stageSvg.style.cursor = (t.id === 'eraser') ? 'cell' : 'crosshair';
          toolBtns.forEach(b => {
            b.el.style.background = (b.id === t.id) ? 'rgba(56, 189, 248, 0.3)' : 'rgba(255, 255, 255, 0.08)';
            b.el.style.borderColor = (b.id === t.id) ? '#38bdf8' : 'rgba(255, 255, 255, 0.12)';
          });
          this.playAudioTone(t.id === 'eraser' ? 330 : 600, 'sine', 0.04);
        });
        if (t.id === this.currentTool) {
          btn.style.background = 'rgba(56, 189, 248, 0.3)';
          btn.style.borderColor = '#38bdf8';
        }
        toolBtns.push({ id: t.id, el: btn });
        penTools.appendChild(btn);
      });

      // 2. Stroke Thickness Pills
      const penWidths = document.createElement('div');
      penWidths.id = 'stage-hud-pen-widths';
      penWidths.style.cssText = 'display:none; align-items:center; gap:3px; margin-right:3px;';
      const widths = [
        { label: '•', width: 2.5, title: 'Fine Stroke' },
        { label: '●', width: 5.5, title: 'Medium Stroke' },
        { label: '■', width: 11.0, title: 'Broad Stroke' },
      ];
      const widthBtns = [];
      widths.forEach(w => {
        const btn = this.createHudButton(w.label, w.title, () => {
          this.currentInkWidth = w.width;
          widthBtns.forEach(wb => {
            wb.el.style.borderColor = (wb.w === w.width) ? '#facc15' : 'rgba(255, 255, 255, 0.12)';
            wb.el.style.color = (wb.w === w.width) ? '#facc15' : '#f8fafc';
          });
          this.playAudioTone(700, 'triangle', 0.03);
        });
        btn.style.fontSize = w.width > 8 ? '16px' : (w.width > 4 ? '13px' : '10px');
        widthBtns.push({ w: w.width, el: btn });
        penWidths.appendChild(btn);
      });

      // 3. Smartboard 7-Color Palette Pills
      const penPalette = document.createElement('div');
      penPalette.id = 'stage-hud-pen-palette';
      penPalette.style.cssText = 'display:none; align-items:center; gap:4px; margin-right:4px;';
      const colors = [
        { hex: '#facc15', name: 'Gold' },
        { hex: '#38bdf8', name: 'Cyan' },
        { hex: '#4ade80', name: 'Green' },
        { hex: '#f43f5e', name: 'Red' },
        { hex: '#c084fc', name: 'Purple' },
        { hex: '#ffffff', name: 'White' },
        { hex: '#0f172a', name: 'Charcoal' }
      ];
      colors.forEach(col => {
        const dot = document.createElement('button');
        dot.type = 'button';
        dot.title = col.name;
        dot.style.cssText = `width:18px; height:18px; border-radius:50%; background:${col.hex}; border:1.5px solid rgba(255,255,255,0.45); cursor:pointer; padding:0; transition: transform 0.12s ease;`;
        dot.onmouseenter = () => dot.style.transform = 'scale(1.25)';
        dot.onmouseleave = () => dot.style.transform = 'scale(1.0)';
        dot.onclick = () => {
          this.currentInkColor = col.hex;
          if (this.currentTool === 'eraser') {
            this.currentTool = 'pen';
            this.stageSvg.style.cursor = 'crosshair';
            toolBtns.forEach(b => {
              b.el.style.background = (b.id === 'pen') ? 'rgba(56, 189, 248, 0.3)' : 'rgba(255, 255, 255, 0.08)';
              b.el.style.borderColor = (b.id === 'pen') ? '#38bdf8' : 'rgba(255, 255, 255, 0.12)';
            });
          }
          this.playAudioTone(587, 'sine', 0.03);
        };
        penPalette.appendChild(dot);
      });

      // 4. Whiteboard Utility Actions
      const inkExtraActions = document.createElement('div');
      inkExtraActions.id = 'stage-hud-ink-actions';
      inkExtraActions.style.cssText = 'display:none; align-items:center; gap:3px; margin-right:4px;';

      const undoBtn = this.createHudButton('↩️', 'Undo Last Stroke (Ctrl+Z)', () => this.undoLastStroke());
      const redoBtn = this.createHudButton('↪️', 'Redo Stroke (Ctrl+Y)', () => this.redoLastStroke());

      const palmBtn = this.createHudButton('🖐️', 'Stylus-Only Palm Rejection (Ignore Touch Gestures While Writing)', () => {
        this.stylusOnlyMode = !this.stylusOnlyMode;
        palmBtn.style.background = this.stylusOnlyMode ? '#38bdf8' : 'rgba(255, 255, 255, 0.08)';
        palmBtn.style.color = this.stylusOnlyMode ? '#090d16' : '#ffffff';
        this.showFloatingNotice(this.stylusOnlyMode ? '🖐️ Stylus-Only Active (Finger Touch Ignored)' : '🖐️ Finger & Stylus Drawing Active');
        this.playAudioTone(this.stylusOnlyMode ? 784 : 440, 'sine', 0.05);
      });

      const exportBtn = this.createHudButton('📋', 'Export Ink to AST S-Expression', () => {
        const ast = this.exportInkToAST();
        if (navigator.clipboard) {
          navigator.clipboard.writeText(ast);
          this.showFloatingNotice('📋 Copied Ink AST S-Expression to Clipboard!');
          this.playAudioTone(659, 'sine', 0.06);
        }
      });
      const broadcastBtn = this.createHudButton('📡', 'Broadcast Whiteboard Ink to Pupils (WebRTC)', () => {
        this.broadcastInkSession();
      });

      inkExtraActions.appendChild(undoBtn);
      inkExtraActions.appendChild(redoBtn);
      inkExtraActions.appendChild(palmBtn);
      inkExtraActions.appendChild(exportBtn);
      inkExtraActions.appendChild(broadcastBtn);

      // 5. Clear Ink Button
      const clearBtn = this.createHudButton('🗑️', 'Clear All Whiteboard Ink', () => this.clearWhiteboardInk());
      clearBtn.id = 'stage-hud-clear-btn';
      clearBtn.style.display = 'none';

      // 6. Pen Toggle Primary Pill
      const penBtn = this.createHudButton('🖊️', 'Whiteboard Ink Mode (Draw, Annotate & Highlight) • [W]', () => {
        this.togglePen();
      });
      penBtn.id = 'stage-hud-pen-btn';

      // 7. X-Ray Discovery Button
      const xrayBtn = this.createHudButton('🔬', 'Pedagogical X-Ray Inspection', () => {
        this.isXRayActive = !this.isXRayActive;
        xrayBtn.style.background = this.isXRayActive ? '#38bdf8' : 'rgba(255, 255, 255, 0.08)';
        xrayBtn.style.color = this.isXRayActive ? '#090d16' : '#ffffff';
        if (!this.isXRayActive) this.hideXRayPopup();
        this.playAudioTone(this.isXRayActive ? 784 : 392, 'sine', 0.08);
      });

      // 8. Audio Sonification Button
      const soundBtn = this.createHudButton('🔊', 'Multi-sensory Procedural Audio', () => {
        this.sonificationEnabled = !this.sonificationEnabled;
        soundBtn.textContent = this.sonificationEnabled ? '🔊' : '🔇';
        soundBtn.style.opacity = this.sonificationEnabled ? '1.0' : '0.5';
        if (this.sonificationEnabled) this.playAudioTone(523, 'sine', 0.05);
      });

      hud.appendChild(penTools);
      hud.appendChild(penWidths);
      hud.appendChild(penPalette);
      hud.appendChild(inkExtraActions);
      hud.appendChild(clearBtn);
      hud.appendChild(penBtn);
      hud.appendChild(xrayBtn);
      hud.appendChild(soundBtn);
      container.appendChild(hud);
    }

    createHudButton(icon, title, onClick) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.title = title;
      btn.textContent = icon;
      btn.style.cssText = `
        background: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        color: #f8fafc;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        cursor: pointer;
        transition: all 0.15s ease;
      `;
      btn.onmouseenter = () => btn.style.transform = 'scale(1.1)';
      btn.onmouseleave = () => btn.style.transform = 'scale(1.0)';
      btn.onclick = onClick;
      return btn;
    }

    // =========================================================================
    // X-Ray Pedagogical Knowledge Tooltip (Cartridge Attribute-Driven)
    // =========================================================================
    setupXRayTooltip() {
      const container = this.stageSvg.parentNode;
      if (!container || container.querySelector('#stage-xray-tooltip')) return;

      const tip = document.createElement('div');
      tip.id = 'stage-xray-tooltip';
      tip.style.cssText = `
        position: absolute;
        display: none;
        background: rgba(15, 23, 42, 0.95);
        backdrop-filter: blur(12px);
        border: 1px solid #38bdf8;
        border-radius: 8px;
        padding: 8px 12px;
        color: #f8fafc;
        font-size: 11px;
        font-family: system-ui, sans-serif;
        box-shadow: 0 6px 20px rgba(0,0,0,0.5);
        pointer-events: none;
        z-index: 35;
        max-width: 240px;
        line-height: 1.4;
      `;
      container.appendChild(tip);
      this.xrayTooltip = tip;
    }

    showXRayPopup(pedId, svgX, svgY, pedNode = null) {
      if (!this.xrayTooltip) return;
      let info = null;

      if (pedNode) {
        const attrTitle = pedNode.getAttribute('data-pedagogical-title') || pedNode.getAttribute('data-pedagogical-label');
        const attrEq = pedNode.getAttribute('data-pedagogical-eq') || '';
        const attrDesc = pedNode.getAttribute('data-pedagogical-desc') || '';
        if (attrTitle || attrDesc) {
          info = {
            title: attrTitle || pedId || 'Apparatus Component',
            eq: attrEq || 'Lumina Vector X-Ray',
            desc: attrDesc || attrTitle || ''
          };
        }
      }

      if (!info && typeof pedId === 'string' && pedId.includes(':')) {
        const colonIdx = pedId.indexOf(':');
        info = {
          title: pedId.slice(0, colonIdx).trim(),
          eq: 'Interactive Vector Apparatus',
          desc: pedId.slice(colonIdx + 1).trim()
        };
      }

      if (!info) return;

      this.xrayTooltip.textContent = '';
      const titleEl = document.createElement('div');
      titleEl.style.color = '#38bdf8';
      titleEl.style.fontWeight = '800';
      titleEl.style.fontSize = '11px';
      titleEl.style.marginBottom = '2px';
      titleEl.textContent = info.title;

      const eqEl = document.createElement('div');
      eqEl.style.color = '#fde047';
      eqEl.style.fontFamily = 'monospace';
      eqEl.style.fontWeight = '800';
      eqEl.style.marginBottom = '3px';
      eqEl.textContent = info.eq;

      const descEl = document.createElement('div');
      descEl.style.color = '#cbd5e1';
      descEl.style.fontSize = '10px';
      descEl.textContent = info.desc;

      this.xrayTooltip.appendChild(titleEl);
      this.xrayTooltip.appendChild(eqEl);
      this.xrayTooltip.appendChild(descEl);

      const rect = this.stageSvg.getBoundingClientRect();
      const clientX = rect.left + (svgX / 800) * rect.width;
      const clientY = rect.top + (svgY / 480) * rect.height;

      this.xrayTooltip.style.left = `${Math.min(window.innerWidth - 250, clientX + 15)}px`;
      this.xrayTooltip.style.top = `${Math.max(10, clientY - 40)}px`;
      this.xrayTooltip.style.display = 'block';
    }

    hideXRayPopup() {
      if (this.xrayTooltip) {
        this.xrayTooltip.style.display = 'none';
      }
    }

    // =========================================================================
    // Touch Feedback Ripple
    // =========================================================================
    createTouchRipple(x, y) {
      if (!this.hudRoot) return;
      const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      circle.setAttribute('cx', x.toFixed(1));
      circle.setAttribute('cy', y.toFixed(1));
      circle.setAttribute('r', '8');
      circle.setAttribute('fill', 'none');
      circle.setAttribute('stroke', '#38bdf8');
      circle.setAttribute('stroke-width', '2');
      circle.style.transition = 'all 0.4s ease-out';
      this.hudRoot.appendChild(circle);

      requestAnimationFrame(() => {
        circle.setAttribute('r', '32');
        circle.setAttribute('opacity', '0');
        setTimeout(() => circle.remove(), 420);
      });
    }

    // =========================================================================
    // Procedural WebAudio Sonification
    // =========================================================================
    playAudioTone(frequency = 440, type = 'sine', duration = 0.1, gainVal = 0.15) {
      if (!this.sonificationEnabled || (this.engine && (this.engine.muted || this.engine.volume === 0))) return;
      try {
        if (!this.audioCtx) {
          const AudioContextClass = window.AudioContext || window.webkitAudioContext;
          if (AudioContextClass) this.audioCtx = new AudioContextClass();
        }
        if (this.audioCtx && this.audioCtx.state === 'suspended') {
          this.audioCtx.resume();
        }
        if (!this.audioCtx) return;

        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(frequency, this.audioCtx.currentTime);
        gain.gain.setValueAtTime(gainVal, this.audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.audioCtx.currentTime + duration);

        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start();
        osc.stop(this.audioCtx.currentTime + duration);
      } catch {}
    }

    // =========================================================================
    // Live Simulation Parameters & Controls HUD Dock (Generic Fallback)
    // =========================================================================
    setupSimParametersHud() {
      const container = this.stageSvg && this.stageSvg.parentNode;
      if (!container || !this.engine) return;

      let hud = container.querySelector('#stage-sim-parameters');
      const scene = this.engine.scene;
      if (!scene || (scene.uiControls && scene.uiControls.length > 0) || container.querySelector('#cartridge-controls-overlay')) {
        if (hud) hud.style.display = 'none';
        return;
      }

      let inputs = Array.isArray(scene.inputs) && scene.inputs.length > 0 ? [...scene.inputs] : [];
      if (inputs.length === 0 && scene.vars && typeof scene.vars === 'object') {
        Object.entries(scene.vars).forEach(([k, v]) => {
          if (v && typeof v === 'object' && typeof v.min === 'number' && typeof v.max === 'number') {
            inputs.push({
              type: 'slider',
              var: k,
              label: v.label || k,
              min: v.min,
              max: v.max,
              step: v.step || 1,
              unit: v.unit || ''
            });
          }
        });
      }

      if (inputs.length === 0) {
        if (hud) hud.style.display = 'none';
        return;
      }

      if (!hud) {
        hud = document.createElement('div');
        hud.id = 'stage-sim-parameters';
        hud.style.cssText = `
          position: absolute;
          top: 14px;
          right: 14px;
          min-width: 230px;
          max-width: 280px;
          background: rgba(15, 23, 42, 0.92);
          backdrop-filter: blur(12px);
          border: 1px solid rgba(255, 255, 255, 0.16);
          border-radius: 12px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.55);
          padding: 10px 14px;
          color: #f8fafc;
          z-index: 35;
          user-select: none;
          font-family: ui-sans-serif, system-ui, sans-serif;
          font-size: 12px;
          transition: opacity 0.2s ease;
        `;
        container.appendChild(hud);
      } else {
        hud.style.display = 'block';
      }

      const currentVars = this.engine.vars || {};

      const headerRow = document.createElement('div');
      headerRow.style.cssText = 'display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:6px;';
      const titleSpan = document.createElement('span');
      titleSpan.style.cssText = 'font-weight:800; font-size:12px; color:#38bdf8; display:flex; align-items:center; gap:5px;';
      const titleIcon = document.createElement('span');
      titleIcon.textContent = '🎛️';
      titleSpan.append(titleIcon, document.createTextNode(' Parameters'));

      const btnGroup = document.createElement('div');
      btnGroup.style.cssText = 'display:flex; gap:6px; align-items:center;';
      const resetVarsBtn = document.createElement('button');
      resetVarsBtn.id = 'sim-btn-reset-vars';
      resetVarsBtn.type = 'button';
      resetVarsBtn.style.cssText = 'background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.16); border-radius:6px; color:#94a3b8; font-size:10px; font-weight:700; padding:2px 7px; cursor:pointer;';
      resetVarsBtn.title = 'Reset variables to defaults';
      resetVarsBtn.textContent = '↺ Reset';

      const collapseBtn = document.createElement('button');
      collapseBtn.id = 'sim-btn-collapse';
      collapseBtn.type = 'button';
      collapseBtn.style.cssText = 'background:none; border:none; color:#94a3b8; font-size:12px; cursor:pointer; padding:0 3px;';
      collapseBtn.textContent = '▲';

      btnGroup.append(resetVarsBtn, collapseBtn);
      headerRow.append(titleSpan, btnGroup);

      const paramBody = document.createElement('div');
      paramBody.id = 'sim-param-body';
      paramBody.style.cssText = 'display:flex; flex-direction:column; gap:8px;';

      inputs.forEach(inp => {
        const vName = inp.var;
        const curVal = currentVars[vName] !== undefined ? currentVars[vName] : (inp.min + (inp.max - inp.min) / 2);
        const unit = inp.unit || '';

        const rowWrap = document.createElement('div');
        const labelRow = document.createElement('div');
        labelRow.style.cssText = 'display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;';

        const lblSpan = document.createElement('span');
        lblSpan.style.cssText = 'font-size:11px; font-weight:600; color:#cbd5e1;';
        lblSpan.textContent = inp.label || vName;

        const valBox = document.createElement('div');
        valBox.style.cssText = 'display:flex; align-items:center; gap:4px;';

        const numInput = document.createElement('input');
        numInput.type = 'number';
        numInput.min = String(inp.min);
        numInput.max = String(inp.max);
        numInput.step = String(inp.step || 1);
        numInput.value = String(curVal);
        numInput.setAttribute('data-var', vName);
        numInput.setAttribute('data-unit', unit);
        numInput.className = 'sim-param-num-input';
        numInput.style.cssText = 'width:48px; background:rgba(0,0,0,0.5); border:1px solid rgba(56,189,248,0.4); border-radius:4px; color:#38bdf8; font-family:ui-monospace, monospace; font-size:11px; font-weight:700; text-align:center; padding:1px 2px;';
        numInput.title = 'Type custom figure';
        valBox.appendChild(numInput);

        if (unit) {
          const unitSpan = document.createElement('span');
          unitSpan.style.cssText = 'font-size:10px; color:#94a3b8;';
          unitSpan.textContent = unit;
          valBox.appendChild(unitSpan);
        }

        labelRow.append(lblSpan, valBox);

        const slider = document.createElement('input');
        slider.type = 'range';
        slider.min = String(inp.min);
        slider.max = String(inp.max);
        if (inp.step !== undefined) slider.step = String(inp.step);
        slider.value = String(curVal);
        slider.setAttribute('data-var', vName);
        slider.setAttribute('data-unit', unit);
        slider.className = 'sim-param-slider';
        slider.style.cssText = 'width:100%; accent-color:#38bdf8; cursor:pointer; height:6px; margin:0; display:block;';

        rowWrap.append(labelRow, slider);
        paramBody.appendChild(rowWrap);
      });

      hud.replaceChildren(headerRow, paramBody);

      const applyVal = (vName, val) => {
        if (this.engine && typeof this.engine.setVar === 'function') {
          this.engine.setVar(vName, val);
        }
        const s = hud.querySelector(`.sim-param-slider[data-var="${vName}"]`);
        const num = hud.querySelector(`.sim-param-num-input[data-var="${vName}"]`);
        if (s && Number(s.value) !== val) s.value = val;
        if (num && Number(num.value) !== val) num.value = val;
      };

      const sliders = hud.querySelectorAll('.sim-param-slider');
      sliders.forEach(slider => {
        slider.addEventListener('input', (e) => {
          const vName = e.target.getAttribute('data-var');
          const val = parseFloat(e.target.value);
          applyVal(vName, val);
          this.playAudioTone(400 + val * 10, 'sine', 0.02, 0.05);
        });
      });

      const numInputs = hud.querySelectorAll('.sim-param-num-input');
      numInputs.forEach(input => {
        input.addEventListener('input', (e) => {
          const vName = e.target.getAttribute('data-var');
          const val = parseFloat(e.target.value);
          if (!isNaN(val)) {
            applyVal(vName, val);
            this.playAudioTone(440 + val * 12, 'triangle', 0.03, 0.08);
          }
        });
      });

      const btnReset = hud.querySelector('#sim-btn-reset-vars');
      if (btnReset) {
        btnReset.addEventListener('click', () => {
          if (this.engine) this.engine.resetVars();
          this.setupSimParametersHud();
          this.playAudioTone(523, 'triangle', 0.08, 0.15);
        });
      }

      const btnCollapse = hud.querySelector('#sim-btn-collapse');
      const body = hud.querySelector('#sim-param-body');
      if (btnCollapse && body) {
        btnCollapse.addEventListener('click', () => {
          const isCollapsed = body.style.display === 'none';
          body.style.display = isCollapsed ? 'flex' : 'none';
          btnCollapse.textContent = isCollapsed ? '▲' : '▼';
        });
      }

      if (!this._varChangeBound && this.engine && typeof this.engine.on === 'function') {
        this._varChangeBound = true;
        this.engine.on('varchange', (data) => {
          const curHud = document.getElementById('stage-sim-parameters') || (container && container.querySelector('#stage-sim-parameters'));
          if (curHud && curHud.style.display !== 'none') {
            const sList = curHud.querySelectorAll('.sim-param-slider');
            sList.forEach(s => {
              const vName = s.getAttribute('data-var');
              if (data.name === '*' || data.name === vName) {
                const val = (data.vars && data.vars[vName] !== undefined) ? data.vars[vName] : data.value;
                if (val !== undefined) {
                  if (Number(s.value) !== Number(val)) s.value = val;
                  const numInput = curHud.querySelector(`.sim-param-num-input[data-var="${vName}"]`);
                  if (numInput && Number(numInput.value) !== Number(val)) numInput.value = val;
                }
              }
            });
          }
        });
      }
    }
  }

  // Expose globally
  global.ASTDirectGestureSubsystem = ASTDirectGestureSubsystem;

})(typeof window !== 'undefined' ? window : globalThis);
