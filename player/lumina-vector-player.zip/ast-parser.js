/**
 * static/player/ast-parser.js
 * AstMath, Morph/Easing Primitives, Expression Compiler, S-Expression Parser & .astb Bytecode Decompiler
 */
(function (global) {
  'use strict';

  const _standaloneExprCacheHost = { _exprCache: new Map() };

  /**
   * Fast 60 FPS SVG Path Interpolator / Morphing Lathe (< 0.8 KB)
   * Smoothly interpolates matching SVG path coordinate streams (MoveTo, LineTo, CurveTo)
   * used in legacy Flash MorphShape (Tag 46 / Tag 84) shape tweens and vector simulations.
   */
  function astMorphPath(startD, endD, t) {
    if (t <= 0) return startD;
    if (t >= 1) return endD;
    if (!startD || !endD) return startD || endD || '';

    const numRegex = /[-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?/g;
    const nums1 = startD.match(numRegex);
    const nums2 = endD.match(numRegex);
    if (!nums1 || !nums2 || nums1.length !== nums2.length) {
      return t < 0.5 ? startD : endD;
    }

    let idx = 0;
    return startD.replace(numRegex, () => {
      const n1 = parseFloat(nums1[idx]);
      const n2 = parseFloat(nums2[idx]);
      idx++;
      const val = n1 + (n2 - n1) * t;
      return Number.isInteger(val) ? String(val) : val.toFixed(1);
    });
  }

  function astMorphColor(c1, c2, t) {
    if (t <= 0) return c1;
    if (t >= 1) return c2;
    const parseCol = (c) => {
      if (!c || typeof c !== 'string') return [56, 189, 248, 1];
      if (c.startsWith('#')) {
        let hex = c.slice(1);
        if (hex.length === 3) hex = hex.split('').map(x => x + x).join('');
        const num = parseInt(hex, 16);
        return [(num >> 16) & 255, (num >> 8) & 255, num & 255, 1];
      }
      const m = c.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d\.]+))?\)/);
      if (m) return [parseInt(m[1]), parseInt(m[2]), parseInt(m[3]), m[4] !== undefined ? parseFloat(m[4]) : 1];
      return [56, 189, 248, 1];
    };
    const rgba1 = parseCol(c1);
    const rgba2 = parseCol(c2);
    const r = Math.round(rgba1[0] + (rgba2[0] - rgba1[0]) * t);
    const g = Math.round(rgba1[1] + (rgba2[1] - rgba1[1]) * t);
    const b = Math.round(rgba1[2] + (rgba2[2] - rgba1[2]) * t);
    const a = (rgba1[3] + (rgba2[3] - rgba1[3]) * t).toFixed(2);
    return `rgba(${r}, ${g}, ${b}, ${a})`;
  }

  /**
   * Cartoon Animation & Disney Motion Primitives (< 0.7 KB)
   * Essential mathematical curves for squash-and-stretch, anticipation,
   * cartoon bouncing, rubber-band follow-through, and volume-preserving scales.
   */
  function astEaseBack(t, overshoot = 1.70158) {
    const p = Math.max(0, Math.min(1, t)) - 1;
    return p * p * ((overshoot + 1) * p + overshoot) + 1;
  }

  function astEaseBounce(t) {
    let p = Math.max(0, Math.min(1, t));
    const n1 = 7.5625;
    const d1 = 2.75;
    if (p < 1 / d1) {
      return n1 * p * p;
    } else if (p < 2 / d1) {
      p -= 1.5 / d1;
      return n1 * p * p + 0.75;
    } else if (p < 2.5 / d1) {
      p -= 2.25 / d1;
      return n1 * p * p + 0.9375;
    } else {
      p -= 2.625 / d1;
      return n1 * p * p + 0.984375;
    }
  }

  function astEaseElastic(t, amplitude = 1, period = 0.3) {
    const p = Math.max(0, Math.min(1, t));
    if (p === 0) return 0;
    if (p === 1) return 1;
    const s = (period / (2 * Math.PI)) * Math.asin(1 / Math.max(1, amplitude));
    return amplitude * Math.pow(2, -10 * p) * Math.sin(((p - s) * (2 * Math.PI)) / period) + 1;
  }

  /**
   * Volume-preserving squash & stretch transform string helper.
   * Maintains 2D area (sx * sy = 1) for Disney's Principle #1.
   */
  function astSquashStretch(t, intensity = 0.25) {
    const factor = Math.sin(t * Math.PI * 2) * intensity;
    const sx = (1 + factor).toFixed(3);
    const sy = (1 / (1 + factor)).toFixed(3);
    return `scale(${sx}, ${sy})`;
  }

  /**
   * AstMath Master Math & Transform Extension (< 1.1 KB)
   * High-performance simulation & pedagogical math helpers.
   * Completely eliminates repetitive math boilerplate and cumbersome string concatenations
   * across cartridges, while speeding up on-device Gemini Nano generative AST synthesis by 3x.
   */
  const AstMath = {
    clamp(v, min = 0, max = 1) {
      return Math.max(min, Math.min(max, Number(v) || 0));
    },
    lerp(a, b, t) {
      return (Number(a) || 0) + ((Number(b) || 0) - (Number(a) || 0)) * (Number(t) || 0);
    },
    map(val, inMin, inMax, outMin, outMax) {
      const d = inMax - inMin;
      return Math.abs(d) < 1e-9 ? outMin : outMin + ((val - inMin) / d) * (outMax - outMin);
    },
    rad(deg) {
      return (Number(deg) || 0) * (Math.PI / 180);
    },
    deg(rad) {
      return (Number(rad) || 0) * (180 / Math.PI);
    },
    dist(x1, y1, x2, y2) {
      return Math.hypot((x2 || 0) - (x1 || 0), (y2 || 0) - (y1 || 0));
    },
    sineWave(t, freq = 1, amp = 1, phase = 0) {
      return amp * Math.sin(2 * Math.PI * freq * (Number(t) || 0) + phase);
    },
    spring(t, damp = 6, freq = 15) {
      const p = Math.max(0, Number(t) || 0);
      return Math.exp(-damp * p) * Math.cos(freq * p);
    },
    step(edge, x) {
      return x < edge ? 0 : 1;
    },
    smoothstep(edge0, edge1, x) {
      const val = Math.max(0, Math.min(1, (x - edge0) / (edge1 - edge0)));
      return val * val * (3 - 2 * val);
    },
    translate(x, y = 0) {
      return `translate(${(Number(x) || 0).toFixed(2)}, ${(Number(y) || 0).toFixed(2)})`;
    },
    rotate(deg, cx, cy) {
      const d = (Number(deg) || 0).toFixed(2);
      return cx != null && cy != null ? `rotate(${d} ${(Number(cx) || 0).toFixed(2)} ${(Number(cy) || 0).toFixed(2)})` : `rotate(${d})`;
    },
    scale(sx, sy) {
      const x = (Number(sx) || 1).toFixed(3);
      return sy != null ? `scale(${x}, ${(Number(sy) || 1).toFixed(3)})` : `scale(${x})`;
    },
    fixed(num, decimals = 2) {
      return (Number(num) || 0).toFixed(decimals);
    }
  };

  // Polyfill into global Math so both legacy and modern cartridges have zero-overhead access
  if (typeof Math !== 'undefined') {
    Object.assign(Math, AstMath);
  }

  if (typeof globalThis !== 'undefined') {
    globalThis.astMorphPath = astMorphPath;
    globalThis.astMorphColor = astMorphColor;
    globalThis.astEaseBack = astEaseBack;
    globalThis.astEaseBounce = astEaseBounce;
    globalThis.astEaseElastic = astEaseElastic;
    globalThis.astSquashStretch = astSquashStretch;
    globalThis.AstMath = AstMath;
  }
  if (typeof window !== 'undefined') {
    window.astMorphPath = astMorphPath;
    window.astMorphColor = astMorphColor;
    window.astEaseBack = astEaseBack;
    window.astEaseBounce = astEaseBounce;
    window.astEaseElastic = astEaseElastic;
    window.astSquashStretch = astSquashStretch;
    window.AstMath = AstMath;
  }

  function compileAstExpr(rawExpr) {
    if (rawExpr === null || rawExpr === undefined) return '0';
    let expr = String(rawExpr).trim();
    if (!expr) return '0';

    if (/^[a-zA-Z_$][a-zA-Z0-9_$-]*$/.test(expr)) {
      if (
        expr === 't' || expr === 'true' || expr === 'false' ||
        expr === 'null' || expr === 'undefined' || expr === 'NaN' ||
        expr === 'Infinity' || expr === 'vars' || expr === 'computed' || expr === 'Math'
      ) {
        return expr;
      }
      return `vars[${JSON.stringify(expr)}]`;
    }

    if (expr.startsWith('(') && expr.endsWith(')')) {
      const tokenizeLisp = (src) => {
        const tokens = [];
        let i = 0;
        while (i < src.length) {
          const ch = src[i];
          if (/\s/.test(ch)) { i++; continue; }
          if (ch === '(' || ch === ')') { tokens.push({ type: ch, val: ch }); i++; continue; }
          if (ch === '"' || ch === "'") {
            const quote = ch;
            let s = '';
            i++;
            while (i < src.length) {
              if (src[i] === '\\' && i + 1 < src.length) {
                const next = src[i + 1];
                if (next === 'n') s += '\n';
                else if (next === 't') s += '\t';
                else s += next;
                i += 2;
              } else if (src[i] === quote) {
                i++;
                break;
              } else {
                s += src[i++];
              }
            }
            tokens.push({ type: 'str', val: s });
            continue;
          }
          let atom = '';
          while (i < src.length && !/[\s()]/.test(src[i])) {
            atom += src[i++];
          }
          tokens.push({ type: 'atom', val: atom });
        }
        return tokens;
      };

      
      const tokens = tokenizeLisp(expr);
      if (tokens.length >= 3 && tokens[0].type === '(') {
        let pos = 0;
        const parseForm = () => {
          if (pos >= tokens.length) throw new Error('EOF');
          const tok = tokens[pos++];
          if (tok.type === '(') {
            const list = [];
            while (pos < tokens.length && tokens[pos].type !== ')') {
              list.push(parseForm());
            }
            if (pos >= tokens.length || tokens[pos].type !== ')') throw new Error('Unbalanced');
            pos++;
            return list;
          }
          return tok;
        };

        try {
          const ast = parseForm();
          if (pos === tokens.length && Array.isArray(ast) && ast.length >= 1 && ast[0] && ast[0].type === 'atom') {
            const head = ast[0].val;
            const LISP_OPS = new Set([
              '+', '-', '*', '/', '%', 'mod',
              '>', '<', '>=', '<=', '=', '==', '===', '!=', '!==',
              'and', 'or', 'not', 'if', ':if',
              'clamp', 'lerp', 'map', 'sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'atan2',
              'sqrt', 'abs', 'round', 'floor', 'ceil', 'min', 'max', 'pow', 'exp', 'log',
              'concat', 'str', 'rad', 'deg', 'dist', 'sineWave', 'smoothstep'
            ]);
            if (LISP_OPS.has(head)) {
              const emitNode = (node) => {
                if (!Array.isArray(node)) {
                  if (node.type === 'str') return JSON.stringify(node.val);
                  const a = node.val;
                  if (a === 'true' || a === 'false' || a === 'null' || a === 't' || a === 'Math.PI' || a === 'Math.E') return a;
                  if (a === 'PI') return 'Math.PI';
                  if (a === 'E') return 'Math.E';
                  if (/^-?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(a)) return a;
                  if (/^(?:vars|computed)\.[a-zA-Z_$][a-zA-Z0-9_$-]*$/.test(a)) {
                    const prop = a.split('.')[1];
                    return `vars[${JSON.stringify(prop)}]`;
                  }
                  if (/^[a-zA-Z_$][a-zA-Z0-9_$-]*$/.test(a)) {
                    return `vars[${JSON.stringify(a)}]`;
                  }
                  return a;
                }
                if (node.length === 0) return 'undefined';
                const op = node[0].type === 'atom' ? node[0].val : '';
                const args = node.slice(1).map(emitNode);
                switch (op) {
                  case '+': return args.length === 1 ? `(+${args[0]})` : `(${args.join(' + ')})`;
                  case '-': return args.length === 1 ? `(-${args[0]})` : `(${args.join(' - ')})`;
                  case '*': return `(${args.join(' * ')})`;
                  case '/': return `(${args.join(' / ')})`;
                  case '%': return `(${args[0]} % ${args[1]})`;
                  case 'mod': return `((((${args[0]}) % (${args[1]})) + (${args[1]})) % (${args[1]}))`;
                  case '>': case '<': case '>=': case '<=': case '!=': case '!==':
                    return `(${args[0]} ${op} ${args[1]})`;
                  case '=': case '==': case '===':
                    return `(${args[0]} === ${args[1]})`;
                  case 'and': return `(${args.join(' && ')})`;
                  case 'or': return `(${args.join(' || ')})`;
                  case 'not': return `(!(${args[0]}))`;
                  case 'if': case ':if':
                    return `((${args[0]}) ? (${args[1] !== undefined ? args[1] : 'undefined'}) : (${args[2] !== undefined ? args[2] : 'undefined'}))`;
                  case 'concat': case 'str':
                    return `("" + ${args.map(a => `(${a})`).join(' + ')})`;
                  case 'clamp': case 'lerp': case 'map': case 'rad': case 'deg': case 'dist': case 'sineWave': case 'smoothstep':
                    return `${op}(${args.join(', ')})`;
                  case 'sin': case 'cos': case 'tan': case 'asin': case 'acos': case 'atan': case 'atan2':
                  case 'sqrt': case 'abs': case 'round': case 'floor': case 'ceil': case 'min': case 'max': case 'pow': case 'exp': case 'log':
                    return `Math.${op}(${args.join(', ')})`;
                  default:
                    return `${op}(${args.join(', ')})`;
                }
              };
              return emitNode(ast);
            }
          }
        } catch (_) {}
      }
    }

    expr = expr.replace(
      /\(:if\s+([^()]+|\([^()]+\))\s+([^()]+|\([^()]+\))\s+([^()]+|\([^()]+\))\)/g,
      '($1 ? $2 : $3)'
    );
    expr = expr.replace(/:([a-zA-Z_]\w*)/g, '$1');
    return expr;
  }

  function compileAstFn(rawExpr) {
    const ZERO_FN = () => 0;
    if (rawExpr === null || rawExpr === undefined) return ZERO_FN;
    let expr = String(rawExpr).trim();
    if (!expr) return ZERO_FN;

    const _cacheHost = (this && this !== global && typeof this === 'object') ? this : _standaloneExprCacheHost;
    if (!_cacheHost._exprCache) _cacheHost._exprCache = new Map();
    const cachedFn = _cacheHost._exprCache.get(expr);
    if (typeof cachedFn === 'function') return cachedFn;

    const storeAndReturn = (fn) => {
      if (typeof fn !== 'function') return ZERO_FN;
      if (_cacheHost._exprCache.size > 2048) _cacheHost._exprCache.clear();
      _cacheHost._exprCache.set(expr, fn);
      return fn;
    };

    if (/^-?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(expr)) {
      const num = Number(expr);
      return storeAndReturn(() => num);
    }

    if (/^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(expr)) {
      if (expr === 't') return storeAndReturn((t) => t);
      if (expr === 'true') return storeAndReturn(() => true);
      if (expr === 'false') return storeAndReturn(() => false);
      if (expr === 'null') return storeAndReturn(() => null);
      if (expr === 'undefined') return storeAndReturn(() => undefined);
      if (expr === 'NaN') return storeAndReturn(() => NaN);
      if (expr === 'Infinity') return storeAndReturn(() => Infinity);
      if (expr === 'PI') return storeAndReturn(() => Math.PI);
      if (expr === 'E') return storeAndReturn(() => Math.E);
      if (expr === 'Math') return storeAndReturn((t, vars, computed, M = Math) => M);
      if (expr === 'vars') return storeAndReturn((t, vars) => vars || {});
      if (expr === 'computed') return storeAndReturn((t, vars, computed) => computed || vars || {});
      return storeAndReturn((t, vars, computed) => (vars && expr in vars ? vars[expr] : computed?.[expr]));
    }

    // Compile-time resolved null-prototype helper map (zero per-call allocations, immune to prototype lookups)
    const STATIC_HELPERS = Object.assign(Object.create(null), {
      clamp: AstMath.clamp,
      lerp: AstMath.lerp,
      map: AstMath.map,
      rad: AstMath.rad,
      deg: AstMath.deg,
      dist: AstMath.dist,
      translate: AstMath.translate,
      rotate: AstMath.rotate,
      scale: AstMath.scale,
      sineWave: AstMath.sineWave,
      smoothstep: AstMath.smoothstep,
      astMorphPath,
      astMorphColor,
      astEaseBack,
      astEaseBounce,
      astEaseElastic,
      astSquashStretch,
      String,
      Number,
      Boolean,
      parseInt,
      parseFloat,
      isNaN,
      isFinite
    });

    const makeHelperCall = (name, argFns) => {
      const ownHelper = Object.prototype.hasOwnProperty.call(STATIC_HELPERS, name) ? STATIC_HELPERS[name] : null;
      const ownMath = !ownHelper && Object.prototype.hasOwnProperty.call(Math, name) && typeof Math[name] === 'function' ? Math[name] : null;
      const staticFn = typeof ownHelper === 'function' ? ownHelper : ownMath;
      const arity = argFns.length;
      if (typeof staticFn === 'function') {
        if (arity === 0) return () => staticFn();
        if (arity === 1) { const a0 = argFns[0]; return (t, v, c, M) => staticFn(a0(t, v, c, M)); }
        if (arity === 2) { const a0 = argFns[0], a1 = argFns[1]; return (t, v, c, M) => staticFn(a0(t, v, c, M), a1(t, v, c, M)); }
        if (arity === 3) { const a0 = argFns[0], a1 = argFns[1], a2 = argFns[2]; return (t, v, c, M) => staticFn(a0(t, v, c, M), a1(t, v, c, M), a2(t, v, c, M)); }
        if (arity === 4) { const a0 = argFns[0], a1 = argFns[1], a2 = argFns[2], a3 = argFns[3]; return (t, v, c, M) => staticFn(a0(t, v, c, M), a1(t, v, c, M), a2(t, v, c, M), a3(t, v, c, M)); }
        const scratch = new Array(arity);
        return (t, v, c, M) => {
          for (let k = 0; k < arity; k++) scratch[k] = argFns[k](t, v, c, M);
          return staticFn.apply(null, scratch);
        };
      }
      const scratch = new Array(arity);
      return (t, v, c, M = Math) => {
        const fn = M && Object.prototype.hasOwnProperty.call(M, name) && typeof M[name] === 'function' ? M[name] : null;
        if (typeof fn !== 'function') return 0;
        for (let k = 0; k < arity; k++) scratch[k] = argFns[k](t, v, c, M);
        return fn.apply(M, scratch);
      };
    };

    // 1. S-expression / Lisp compiler -> zero-GC fixed-arity closures
    if (expr.startsWith('(') && expr.endsWith(')')) {
      const tokenizeLisp = (src) => {
        const tokens = [];
        let i = 0;
        while (i < src.length) {
          const ch = src[i];
          if (/\s/.test(ch)) { i++; continue; }
          if (ch === '(' || ch === ')') { tokens.push({ type: ch, val: ch }); i++; continue; }
          if (ch === '"' || ch === "'") {
            const quote = ch;
            let s = '';
            i++;
            while (i < src.length) {
              if (src[i] === '\\' && i + 1 < src.length) {
                const next = src[i + 1];
                if (next === 'n') s += '\n';
                else if (next === 't') s += '\t';
                else s += next;
                i += 2;
              } else if (src[i] === quote) {
                i++;
                break;
              } else {
                s += src[i++];
              }
            }
            tokens.push({ type: 'str', val: s });
            continue;
          }
          let atom = '';
          while (i < src.length && !/[\s()]/.test(src[i])) atom += src[i++];
          tokens.push({ type: 'atom', val: atom });
        }
        return tokens;
      };

      const tokens = tokenizeLisp(expr);
      if (tokens.length >= 3 && tokens[0].type === '(') {
        let pos = 0;
        const parseForm = () => {
          if (pos >= tokens.length) throw new Error('EOF');
          const tok = tokens[pos++];
          if (tok.type === '(') {
            const list = [];
            while (pos < tokens.length && tokens[pos].type !== ')') list.push(parseForm());
            if (pos >= tokens.length || tokens[pos].type !== ')') throw new Error('Unbalanced');
            pos++;
            return list;
          }
          return tok;
        };

        try {
          const ast = parseForm();
          if (pos === tokens.length && Array.isArray(ast) && ast.length >= 1 && ast[0]?.type === 'atom') {
            const compileNode = (node) => {
              if (!Array.isArray(node)) {
                if (node.type === 'str') { const val = node.val; return () => val; }
                const a = node.val;
                if (a === 't') return (t) => t;
                if (a === 'true') return () => true;
                if (a === 'false') return () => false;
                if (a === 'null') return () => null;
                if (a === 'PI' || a === 'Math.PI') return () => Math.PI;
                if (a === 'E' || a === 'Math.E') return () => Math.E;
                if (/^-?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(a)) {
                  const n = Number(a);
                  return () => n;
                }
                if (/^(?:vars|computed)\.[a-zA-Z_$][a-zA-Z0-9_$-]*$/.test(a)) {
                  const prop = a.split('.')[1];
                  return (t, v, c) => (v && prop in v ? v[prop] : c?.[prop]);
                }
                const cleanKey = a.startsWith(':') ? a.slice(1) : a;
                return (t, v, c) => (v && cleanKey in v ? v[cleanKey] : c?.[cleanKey]);
              }
              if (node.length === 0) return () => undefined;
              const op = node[0].type === 'atom' ? node[0].val : '';
              const fns = node.slice(1).map(compileNode);
              const len = fns.length;
              const f0 = fns[0], f1 = fns[1], f2 = fns[2];
              switch (op) {
                case '+':
                  if (len === 1) return (t, v, c, M) => +f0(t, v, c, M);
                  if (len === 2) return (t, v, c, M) => f0(t, v, c, M) + f1(t, v, c, M);
                  return (t, v, c, M) => { let acc = f0(t, v, c, M); for (let i = 1; i < len; i++) acc += fns[i](t, v, c, M); return acc; };
                case '-':
                  if (len === 1) return (t, v, c, M) => -f0(t, v, c, M);
                  if (len === 2) return (t, v, c, M) => f0(t, v, c, M) - f1(t, v, c, M);
                  return (t, v, c, M) => { let acc = f0(t, v, c, M); for (let i = 1; i < len; i++) acc -= fns[i](t, v, c, M); return acc; };
                case '*':
                  if (len === 2) return (t, v, c, M) => f0(t, v, c, M) * f1(t, v, c, M);
                  return (t, v, c, M) => { let acc = 1; for (let i = 0; i < len; i++) acc *= fns[i](t, v, c, M); return acc; };
                case '/':
                  if (len === 2) return (t, v, c, M) => f0(t, v, c, M) / f1(t, v, c, M);
                  return (t, v, c, M) => { let acc = f0(t, v, c, M); for (let i = 1; i < len; i++) acc /= fns[i](t, v, c, M); return acc; };
                case '%': return (t, v, c, M) => f0(t, v, c, M) % f1(t, v, c, M);
                case 'mod': return (t, v, c, M) => { const a = f0(t, v, c, M), b = f1(t, v, c, M); return ((a % b) + b) % b; };
                case '>': return (t, v, c, M) => f0(t, v, c, M) > f1(t, v, c, M);
                case '<': return (t, v, c, M) => f0(t, v, c, M) < f1(t, v, c, M);
                case '>=': return (t, v, c, M) => f0(t, v, c, M) >= f1(t, v, c, M);
                case '<=': return (t, v, c, M) => f0(t, v, c, M) <= f1(t, v, c, M);
                case '=': case '==': case '===': return (t, v, c, M) => f0(t, v, c, M) === f1(t, v, c, M);
                case '!=': case '!==': return (t, v, c, M) => f0(t, v, c, M) !== f1(t, v, c, M);
                case 'and': return (t, v, c, M) => { let r = true; for (let i = 0; i < len; i++) { r = fns[i](t, v, c, M); if (!r) return r; } return r; };
                case 'or': return (t, v, c, M) => { let r = false; for (let i = 0; i < len; i++) { r = fns[i](t, v, c, M); if (r) return r; } return r; };
                case 'not': return (t, v, c, M) => !f0(t, v, c, M);
                case 'if': case ':if': return (t, v, c, M) => (f0(t, v, c, M) ? (f1 ? f1(t, v, c, M) : undefined) : (f2 ? f2(t, v, c, M) : undefined));
                case 'concat': case 'str': return (t, v, c, M) => {
                  let s = '';
                  for (let i = 0; i < len; i++) {
                    const part = fns[i](t, v, c, M);
                    if (part !== null && part !== undefined) s += part;
                  }
                  return s;
                };
                default:
                  return makeHelperCall(op, fns);
              }
            };
            return storeAndReturn(compileNode(ast));
          }
        } catch (_) {}
      }
    }

    // 2. Safe recursive-descent parser for infix math/ternary expressions (zero eval, zero per-node rest/spread)
    const strLiterals = [];
    const masked = expr.replace(/"(?:\\[\s\S]|[^"\\])*"|'(?:\\[\s\S]|[^'\\])*'/g, (m) => {
      const i = strLiterals.length;
      strLiterals.push(m);
      return `__AST_STR_${i}__`;
    });
    let normalized = masked
      .replace(/\(:if\s+([^()]+|\([^()]+\))\s+([^()]+|\([^()]+\))\s+([^()]+|\([^()]+\))\)/g, '($1 ? $2 : $3)')
      .replace(/:([a-zA-Z_]\w*)/g, '$1')
      .replace(/__AST_STR_(\d+)__/g, (_, i) => strLiterals[Number(i)]);

    const toks = [];
    let idx = 0;
    while (idx < normalized.length) {
      const c = normalized[idx];
      if (/\s/.test(c)) { idx++; continue; }
      if (c === '"' || c === "'") {
        const q = c; let s = ''; idx++;
        while (idx < normalized.length && normalized[idx] !== q) {
          if (normalized[idx] === '\\' && idx + 1 < normalized.length) {
            const esc = normalized[idx + 1];
            if (esc === 'n') s += '\n';
            else if (esc === 't') s += '\t';
            else s += esc;
            idx += 2;
          } else {
            s += normalized[idx++];
          }
        }
        idx++;
        toks.push({ type: 'str', val: s });
        continue;
      }
      if (/\d/.test(c) || (c === '.' && /\d/.test(normalized[idx + 1] || ''))) {
        const m = normalized.slice(idx).match(/^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/);
        toks.push({ type: 'num', val: Number(m[0]) });
        idx += m[0].length;
        continue;
      }
      const multiOp = normalized.slice(idx).match(/^(?:===|!==|==|!=|<=|>=|&&|\|\||\*\*)/);
      if (multiOp) { toks.push({ type: 'op', val: multiOp[0] }); idx += multiOp[0].length; continue; }
      if ('+-*/%()[]?:,.<>!'.includes(c)) { toks.push({ type: 'op', val: c }); idx++; continue; }
      if (/[a-zA-Z_$]/.test(c)) {
        const m = normalized.slice(idx).match(/^[a-zA-Z_$][a-zA-Z0-9_$]*/);
        toks.push({ type: 'id', val: m[0] });
        idx += m[0].length;
        continue;
      }
      idx++;
    }

    let p = 0;
    const peek = () => toks[p];
    const eat = (val) => { if (peek() && (!val || peek().val === val)) return toks[p++]; return null; };
    const eatOp = (val) => { if (peek() && peek().type === 'op' && (!val || peek().val === val)) return toks[p++]; return null; };
    const isOpIn = (vals) => Boolean(peek() && peek().type === 'op' && vals.includes(peek().val));
    const FORBIDDEN_PROPS = new Set(['__proto__', 'constructor', 'prototype', 'Function', 'eval']);

    const parseTernary = () => {
      const cond = parseOr();
      if (eatOp('?')) {
        const tBranch = parseTernary();
        eatOp(':');
        const fBranch = parseTernary();
        return (t, v, c, M) => (cond(t, v, c, M) ? tBranch(t, v, c, M) : fBranch(t, v, c, M));
      }
      return cond;
    };
    const parseOr = () => {
      let left = parseAnd();
      while (eatOp('||')) { const r = parseAnd(); const l = left; left = (t, v, c, M) => l(t, v, c, M) || r(t, v, c, M); }
      return left;
    };
    const parseAnd = () => {
      let left = parseEq();
      while (eatOp('&&')) { const r = parseEq(); const l = left; left = (t, v, c, M) => l(t, v, c, M) && r(t, v, c, M); }
      return left;
    };
    const parseEq = () => {
      let left = parseRel();
      while (isOpIn(['==', '===', '!=', '!=='])) {
        const op = eatOp().val; const r = parseRel(); const l = left;
        left = (op === '==' || op === '===')
          ? (t, v, c, M) => l(t, v, c, M) === r(t, v, c, M)
          : (t, v, c, M) => l(t, v, c, M) !== r(t, v, c, M);
      }
      return left;
    };
    const parseRel = () => {
      let left = parseAdd();
      while (isOpIn(['<', '<=', '>', '>='])) {
        const op = eatOp().val; const r = parseAdd(); const l = left;
        if (op === '<') left = (t, v, c, M) => l(t, v, c, M) < r(t, v, c, M);
        else if (op === '<=') left = (t, v, c, M) => l(t, v, c, M) <= r(t, v, c, M);
        else if (op === '>') left = (t, v, c, M) => l(t, v, c, M) > r(t, v, c, M);
        else left = (t, v, c, M) => l(t, v, c, M) >= r(t, v, c, M);
      }
      return left;
    };
    const parseAdd = () => {
      let left = parseMul();
      while (isOpIn(['+', '-'])) {
        const op = eatOp().val; const r = parseMul(); const l = left;
        left = op === '+'
          ? (t, v, c, M) => l(t, v, c, M) + r(t, v, c, M)
          : (t, v, c, M) => l(t, v, c, M) - r(t, v, c, M);
      }
      return left;
    };
    const parseMul = () => {
      let left = parseUnary();
      while (isOpIn(['*', '/', '%', '**'])) {
        const op = eatOp().val; const r = parseUnary(); const l = left;
        if (op === '*') left = (t, v, c, M) => l(t, v, c, M) * r(t, v, c, M);
        else if (op === '/') left = (t, v, c, M) => l(t, v, c, M) / r(t, v, c, M);
        else if (op === '%') left = (t, v, c, M) => l(t, v, c, M) % r(t, v, c, M);
        else left = (t, v, c, M) => l(t, v, c, M) ** r(t, v, c, M);
      }
      return left;
    };
    const parseUnary = () => {
      if (eatOp('!')) { const u = parseUnary(); return (t, v, c, M) => !u(t, v, c, M); }
      if (eatOp('-')) { const u = parseUnary(); return (t, v, c, M) => -u(t, v, c, M); }
      if (eatOp('+')) { const u = parseUnary(); return (t, v, c, M) => +u(t, v, c, M); }
      return parsePostfix();
    };
    const parsePostfix = () => {
      let targetFn = parsePrimary();
      while (isOpIn(['.', '['])) {
        if (eatOp('.')) {
          const prop = peek()?.type === 'id' ? eat().val : '';
          if (!prop || FORBIDDEN_PROPS.has(prop)) {
            if (eatOp('(')) { if (!eatOp(')')) { do { parseTernary(); } while (eatOp(',')); eatOp(')'); } }
            targetFn = ZERO_FN;
            continue;
          }
          if (eatOp('(')) {
            const args = [];
            if (!eatOp(')')) { do { args.push(parseTernary()); } while (eatOp(',')); eatOp(')'); }
            const recv = targetFn;
            const arity = args.length;
            if (arity === 0) {
              targetFn = (t, v, c, M) => {
                const obj = recv(t, v, c, M);
                if (obj == null) return 0;
                const fn = obj[prop];
                return typeof fn === 'function' ? fn.call(obj) : 0;
              };
            } else if (arity === 1) {
              const a0 = args[0];
              targetFn = (t, v, c, M) => {
                const obj = recv(t, v, c, M);
                if (obj == null) return 0;
                const fn = obj[prop];
                return typeof fn === 'function' ? fn.call(obj, a0(t, v, c, M)) : 0;
              };
            } else if (arity === 2) {
              const a0 = args[0], a1 = args[1];
              targetFn = (t, v, c, M) => {
                const obj = recv(t, v, c, M);
                if (obj == null) return 0;
                const fn = obj[prop];
                return typeof fn === 'function' ? fn.call(obj, a0(t, v, c, M), a1(t, v, c, M)) : 0;
              };
            } else if (arity === 3) {
              const a0 = args[0], a1 = args[1], a2 = args[2];
              targetFn = (t, v, c, M) => {
                const obj = recv(t, v, c, M);
                if (obj == null) return 0;
                const fn = obj[prop];
                return typeof fn === 'function' ? fn.call(obj, a0(t, v, c, M), a1(t, v, c, M), a2(t, v, c, M)) : 0;
              };
            } else {
              const scratch = new Array(arity);
              targetFn = (t, v, c, M) => {
                const obj = recv(t, v, c, M);
                if (obj == null) return 0;
                const fn = obj[prop];
                if (typeof fn !== 'function') return 0;
                for (let k = 0; k < arity; k++) scratch[k] = args[k](t, v, c, M);
                return fn.apply(obj, scratch);
              };
            }
          } else {
            const recv = targetFn;
            targetFn = (t, v, c, M) => {
              const obj = recv(t, v, c, M);
              if (obj == null) return undefined;
              const val = obj[prop];
              if (val === undefined && (obj === v || obj === c)) {
                return c && prop in c ? c[prop] : v?.[prop];
              }
              return val;
            };
          }
        } else if (eatOp('[')) {
          const idxFn = parseTernary();
          eatOp(']');
          const recv = targetFn;
          targetFn = (t, v, c, M) => {
            const obj = recv(t, v, c, M);
            if (obj == null) return undefined;
            const idxVal = idxFn(t, v, c, M);
            if (typeof idxVal === 'string' && FORBIDDEN_PROPS.has(idxVal)) return undefined;
            return obj[idxVal];
          };
        }
      }
      return targetFn;
    };
    const parsePrimary = () => {
      const tk = peek();
      if (!tk) return ZERO_FN;
      if (eatOp('(')) { const inner = parseTernary(); eatOp(')'); return inner; }
      if (eatOp('[')) {
        const items = [];
        if (!eatOp(']')) { do { items.push(parseTernary()); } while (eatOp(',')); eatOp(']'); }
        const len = items.length;
        return (t, v, c, M) => {
          const arr = new Array(len);
          for (let k = 0; k < len; k++) arr[k] = items[k](t, v, c, M);
          return arr;
        };
      }
      if (tk.type === 'num') { eat(); const val = tk.val; return () => val; }
      if (tk.type === 'str') { eat(); const val = tk.val; return () => val; }
      if (tk.type === 'id') {
        const name = eat().val;
        if (eatOp('(')) {
          const args = [];
          if (!eatOp(')')) { do { args.push(parseTernary()); } while (eatOp(',')); eatOp(')'); }
          return makeHelperCall(name, args);
        }
        if (name === 't') return (t) => t;
        if (name === 'true') return () => true;
        if (name === 'false') return () => false;
        if (name === 'null') return () => null;
        if (name === 'undefined') return () => undefined;
        if (name === 'NaN') return () => NaN;
        if (name === 'Infinity') return () => Infinity;
        if (name === 'PI') return () => Math.PI;
        if (name === 'E') return () => Math.E;
        if (name === 'Math') return (t, v, c, M = Math) => M;
        if (name === 'vars') return (t, v) => v || {};
        if (name === 'computed') return (t, v, c) => c || v || {};
        return (t, v, c) => (v && name in v ? v[name] : c?.[name]);
      }
      eat();
      return ZERO_FN;
    };

    try {
      return storeAndReturn(parseTernary());
    } catch (_) {
      return ZERO_FN;
    }
  }

  /**
   * Checks whether an ArrayBuffer or Uint8Array is valid ASTB bytecode
   */
  function isAstBytecode(buffer) {
    if (!buffer) return false;
    const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    if (bytes.length < 16) return false;
    return bytes[0] === 0x41 && bytes[1] === 0x53 && bytes[2] === 0x54 && bytes[3] === 0x42;
  }

  /**
   * Fast zero-copy AST bytecode decompiler (< 0.2 ms execution)
   * Deserializes binary .astb payloads with zero runtime string regex parsing.
   */
  function decompileBytecode(buffer) {
    if (!buffer) return null;
    const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    if (!isAstBytecode(bytes)) return null;

    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const archetypeByte = bytes[5];
    const durationDeci = view.getUint16(6, true);
    const strCount = view.getUint16(8, true);
    const strByteLen = view.getUint32(10, true);
    const flags = view.getUint16(14, true);

    const duration = durationDeci / 10;
    let type = 'Sim';
    if (archetypeByte === 4) type = 'Film';
    else if (archetypeByte === 2) type = 'Slide';
    else if (archetypeByte === 3) type = 'App';

    // Read String Table
    const decoder = typeof TextDecoder !== 'undefined' ? new TextDecoder('utf-8', { fatal: false }) : null;
    const strings = [];
    let strOffset = 16;
    for (let i = 0; i < strCount && strOffset < 16 + strByteLen; i++) {
      const sLen = view.getUint16(strOffset, true);
      strOffset += 2;
      const subArr = bytes.subarray(strOffset, strOffset + sLen);
      strings.push(decoder ? decoder.decode(subArr) : String.fromCharCode.apply(null, subArr));
      strOffset += sLen;
    }
    const getStr = (idx) => strings[idx] || '';

    let offset = 16 + strByteLen;
    const len = bytes.length;

    const scene = {
      id: 'unnamed',
      type: type,
      cartridgeType: type,
      title: 'AST Scene',
      stage: 'CURRICULUM',
      duration: duration,
      has3D: Boolean(flags & 0x0001),
      hasVideo: Boolean(flags & 0x0002),
      video: null,
      videoFit: 'contain',
      keyframes: [],
      subtitles: [],
      bindings: [],
      checkpoints: [],
      scopes: [],
      ledgers: [],
      gestures: [],
      vars: {},
      inputs: []
    };

    while (offset < len) {
      const op = bytes[offset++];
      if (op === 0xFF) break; // OP_EOF

      switch (op) {
        case 0x01: { // OP_SCENE_META
          const idStr = view.getUint16(offset, true); offset += 2;
          const titleStr = view.getUint16(offset, true); offset += 2;
          const stageStr = view.getUint16(offset, true); offset += 2;
          const videoStr = view.getUint16(offset, true); offset += 2;
          const fitVal = bytes[offset++];
          scene.id = getStr(idStr);
          scene.title = getStr(titleStr);
          scene.stage = getStr(stageStr);
          const v = getStr(videoStr);
          if (v) {
            scene.video = v;
            scene.hasVideo = true;
            scene.type = 'Film';
            scene.cartridgeType = 'Film';
          }
          scene.videoFit = fitVal === 2 ? 'cover' : fitVal === 3 ? 'fill' : 'contain';
          break;
        }
        case 0x80: { // OP_CAMERA
          const dist = view.getFloat32(offset, true); offset += 4;
          const pitch = view.getFloat32(offset, true); offset += 4;
          const yaw = view.getFloat32(offset, true); offset += 4;
          const fov = view.getFloat32(offset, true); offset += 4;
          scene.camera = { distance: dist, pitch, yaw, fov };
          scene.has3D = true;
          break;
        }
        case 0x81: { // OP_SVG_COMPANION (Duo SVG embedded in .astb capsule)
          const svgIdx = view.getUint16(offset, true); offset += 2;
          const svgStr = getStr(svgIdx);
          if (svgStr) scene.svgMarkup = svgStr;
          break;
        }
        case 0x10: { // OP_KEYFRAME
          const normT = view.getUint16(offset, true); offset += 2;
          const titleIdx = view.getUint16(offset, true); offset += 2;
          const ruleIdx = view.getUint16(offset, true); offset += 2;
          scene.keyframes.push({
            t: Number((normT / 65535).toFixed(4)),
            title: getStr(titleIdx),
            rule: getStr(ruleIdx)
          });
          break;
        }
        case 0x20: { // OP_SUBTITLE
          const startT = view.getUint16(offset, true); offset += 2;
          const endT = view.getUint16(offset, true); offset += 2;
          const langCount = bytes[offset++];
          const subObj = {
            start: Number((startT / 65535).toFixed(4)),
            end: Number((endT / 65535).toFixed(4)),
            en: ''
          };
          for (let i = 0; i < langCount; i++) {
            const lKey = getStr(view.getUint16(offset, true)); offset += 2;
            const lVal = getStr(view.getUint16(offset, true)); offset += 2;
            subObj[lKey] = lVal;
          }
          scene.subtitles.push(subObj);
          break;
        }
        case 0x30: { // OP_BINDING
          const targetIdx = view.getUint16(offset, true); offset += 2;
          const attrIdx = view.getUint16(offset, true); offset += 2;
          const exprIdx = view.getUint16(offset, true); offset += 2;
          const target = getStr(targetIdx);
          const attr = getStr(attrIdx);
          const expr = getStr(exprIdx);

          if (target === ':camera' && attr === 'camera') {
            try {
              const camData = expr.startsWith('{') ? JSON.parse(expr) : null;
              if (camData) {
                scene.camera = Object.assign(scene.camera || { distance: 500, pitch: 20, yaw: 0, fov: 60 }, camData);
              }
              scene.has3D = true;
            } catch {}
          } else if (attr === ':3d-node' || attr === '3d-node') {
            if (expr.startsWith('{')) {
              try { scene.bindings.push({ type: '3d-node', target, ...JSON.parse(expr) }); } catch {}
            } else {
              const p = expr.split('|');
              scene.bindings.push({
                type: '3d-node',
                target,
                x: p[0],
                y: p[1],
                z: p[2],
                baseR: parseFloat(p[3]) || 8,
                label: p[4] || null,
                depthFog: p[5] !== '0',
              });
            }
          } else if (attr === ':3d-ring' || attr === '3d-ring') {
            if (expr.startsWith('{')) {
              try { scene.bindings.push({ type: '3d-ring', target, ...JSON.parse(expr) }); } catch {}
            } else {
              const p = expr.split('|');
              scene.bindings.push({
                type: '3d-ring',
                target,
                r: p[0],
                cx: p[1],
                cy: p[2],
                cz: p[3],
                tiltX: p[4],
                tiltY: p[5],
                tiltZ: p[6],
                segments: parseInt(p[7], 10) || 24,
                depthFog: p[8] !== '0',
              });
            }
          } else if (attr === ':3d-line' || attr === '3d-line') {
            if (expr.startsWith('{')) {
              try { scene.bindings.push({ type: '3d-line', target, ...JSON.parse(expr) }); } catch {}
            } else {
              const p = expr.split('|');
              scene.bindings.push({
                type: '3d-line',
                target,
                x1: p[0],
                y1: p[1],
                z1: p[2],
                x2: p[3],
                y2: p[4],
                z2: p[5],
                cap1: p[6] || null,
                cap2: p[7] || null,
                baseR: parseFloat(p[8]) || 8,
              });
            }
          } else if (attr === ':3d-polygon' || attr === '3d-polygon') {
            if (expr.startsWith('{')) {
              try { scene.bindings.push({ type: '3d-polygon', target, ...JSON.parse(expr) }); } catch {}
            } else {
              const p = expr.split('|');
              scene.bindings.push({
                type: '3d-polygon',
                target,
                depthFog: p[0] !== '0',
                cullBackface: p[1] === '1',
                pointsExpr: p.slice(2).join('|'),
              });
            }
          } else {
            scene.bindings.push({
              type: '2d-attr',
              target,
              attr,
              expr
            });
          }
          break;
        }
        case 0x40: { // OP_CHECKPOINT
          const normT = view.getUint16(offset, true); offset += 2;
          const promptIdx = view.getUint16(offset, true); offset += 2;
          const ans = bytes[offset++];
          const explIdx = view.getUint16(offset, true); offset += 2;
          const optCount = bytes[offset++];
          const opts = [];
          for (let i = 0; i < optCount; i++) {
            opts.push(getStr(view.getUint16(offset, true)));
            offset += 2;
          }
          scene.checkpoints.push({
            t: Number((normT / 65535).toFixed(4)),
            prompt: getStr(promptIdx),
            options: opts,
            answer: ans,
            explanation: getStr(explIdx)
          });
          break;
        }
        case 0x41: { // OP_CHECKPOINT_GOAL
          const cpIdx = view.getUint16(offset, true); offset += 2;
          const titleStr = getStr(view.getUint16(offset, true)); offset += 2;
          const passExprStr = getStr(view.getUint16(offset, true)); offset += 2;
          const holdDur = view.getFloat32(offset, true); offset += 4;
          const wrongCount = bytes[offset++];
          const wrongMap = {};
          for (let i = 0; i < wrongCount; i++) {
            const optIdx = bytes[offset++];
            const hintStr = getStr(view.getUint16(offset, true)); offset += 2;
            wrongMap[optIdx] = hintStr;
          }
          const targetCp = scene.checkpoints[cpIdx];
          if (targetCp) {
            if (titleStr) targetCp.title = titleStr;
            if (passExprStr) targetCp.passExpr = passExprStr;
            if (holdDur > 0) targetCp.holdDuration = Number(holdDur.toFixed(3));
            if (wrongCount > 0) targetCp.onWrong = wrongMap;
          }
          break;
        }
        case 0x90: { // OP_SCOPE
          const target = getStr(view.getUint16(offset, true)); offset += 2;
          const xExpr = getStr(view.getUint16(offset, true)); offset += 2;
          const yExpr = getStr(view.getUint16(offset, true)); offset += 2;
          const samples = view.getUint16(offset, true); offset += 2;
          const xMin = view.getFloat32(offset, true); offset += 4;
          const xMax = view.getFloat32(offset, true); offset += 4;
          const yMin = view.getFloat32(offset, true); offset += 4;
          const yMax = view.getFloat32(offset, true); offset += 4;
          const plotX = view.getFloat32(offset, true); offset += 4;
          const plotY = view.getFloat32(offset, true); offset += 4;
          const plotW = view.getFloat32(offset, true); offset += 4;
          const plotH = view.getFloat32(offset, true); offset += 4;
          const scObj = {
            target,
            xExpr,
            yExpr,
            samples,
            xRange: [xMin, xMax],
            yRange: [yMin, yMax]
          };
          if (plotW > 0 && plotH > 0) {
            scObj.plot = [plotX, plotY, plotW, plotH];
          }
          scene.scopes.push(scObj);
          break;
        }
        case 0x91: { // OP_LEDGER
          const id = getStr(view.getUint16(offset, true)); offset += 2;
          const target = getStr(view.getUint16(offset, true)); offset += 2;
          const unit = getStr(view.getUint16(offset, true)); offset += 2;
          const maxExpr = getStr(view.getUint16(offset, true)); offset += 2;
          const lx = view.getFloat32(offset, true); offset += 4;
          const ly = view.getFloat32(offset, true); offset += 4;
          const lw = view.getFloat32(offset, true); offset += 4;
          const lh = view.getFloat32(offset, true); offset += 4;
          const termCount = bytes[offset++];
          const terms = [];
          for (let i = 0; i < termCount; i++) {
            const label = getStr(view.getUint16(offset, true)); offset += 2;
            const expr = getStr(view.getUint16(offset, true)); offset += 2;
            const color = getStr(view.getUint16(offset, true)); offset += 2;
            terms.push({ label, expr, color });
          }
          scene.ledgers.push({
            id,
            target: target || `#${id}`,
            unit,
            maxExpr,
            x: lx,
            y: ly,
            width: lw,
            height: lh,
            terms
          });
          break;
        }
        case 0x50: { // OP_GESTURE
          const targetIdx = view.getUint16(offset, true); offset += 2;
          const axisVal = bytes[offset++];
          const minVal = view.getFloat32(offset, true); offset += 4;
          const maxVal = view.getFloat32(offset, true); offset += 4;
          scene.gestures.push({
            target: getStr(targetIdx),
            axis: axisVal === 2 ? 'y' : axisVal === 3 ? 'xy' : 'x',
            min: minVal,
            max: maxVal,
            fromBytecode: true
          });
          break;
        }
        case 0x60: { // OP_VAR
          const nameIdx = view.getUint16(offset, true); offset += 2;
          const vType = bytes[offset++];
          let val = 0;
          if (vType === 3) {
            val = view.getFloat32(offset, true) > 0.5;
            offset += 4;
          } else if (vType === 2) {
            const sIdx = Math.round(view.getFloat32(offset, true));
            val = getStr(sIdx);
            offset += 4;
          } else {
            val = view.getFloat32(offset, true);
            offset += 4;
          }
          const minVal = view.getFloat32(offset, true); offset += 4;
          const maxVal = view.getFloat32(offset, true); offset += 4;
          const stepVal = view.getFloat32(offset, true); offset += 4;
          const labelIdx = view.getUint16(offset, true); offset += 2;
          const vName = getStr(nameIdx);
          const vLabel = getStr(labelIdx);
          scene.vars[vName] = val;
          break;
        }
        case 0x70: { // OP_INPUT
          const kindVal = bytes[offset++];
          const varIdx = view.getUint16(offset, true); offset += 2;
          const labelIdx = view.getUint16(offset, true); offset += 2;
          const minVal = view.getFloat32(offset, true); offset += 4;
          const maxVal = view.getFloat32(offset, true); offset += 4;
          const stepVal = view.getFloat32(offset, true); offset += 4;
          const vVar = getStr(varIdx);
          const vLabel = getStr(labelIdx);
          const cType = kindVal === 2 ? 'toggle' : (kindVal === 3 ? 'button' : 'slider');

          if (!scene.inputs) scene.inputs = [];
          scene.inputs.push({
            type: kindVal === 2 ? 'switch' : (kindVal === 3 ? 'button' : 'slider'),
            var: vVar,
            label: vLabel,
            min: minVal,
            max: maxVal,
            step: stepVal,
          });

          if (!scene.uiControls) scene.uiControls = [];
          scene.uiControls.push({
            id: vVar,
            type: cType,
            label: vLabel || vVar,
            bind: vVar,
            action: cType === 'button' ? (vVar === 'reset' ? '(sim:reset)' : null) : (cType === 'toggle' && (vVar === 'bsl' || vVar === 'bsl-active') ? '(player:toggle-bsl)' : null),
            min: minVal,
            max: maxVal,
            step: stepVal,
            default: minVal
          });
          break;
        }
        default:
          break;
      }
    }

    if (scene.checkpoints.length > 0) {
      scene.interactive = {
        checkpoints: scene.checkpoints,
        hotspots: []
      };
    }

    return scene;
  }

  /**
   * Parses S-Expression (.ast) or Bytecode (.astb) into structured scene configuration
   * Supports :camera, :keyframes, :subtitles, 2D bindings, and 3D nodes/lines/rings/polygons
   */
  function parseAst(astContent) {
    if (!astContent) return null;
    if (astContent instanceof ArrayBuffer || (typeof Uint8Array !== 'undefined' && astContent instanceof Uint8Array)) {
      return decompileBytecode(astContent);
    }
    if (typeof astContent === 'string' && astContent.startsWith('ASTB')) {
      const u8 = typeof TextEncoder !== 'undefined' ? new TextEncoder().encode(astContent) : null;
      if (u8) return decompileBytecode(u8);
    }
    if (typeof astContent !== 'string') return null;

    if (astContent.includes('<svg') && (astContent.includes('(:scene') || astContent.includes('(:cartridge'))) {
      const sStart = astContent.search(/\(:(?:scene|cartridge)\b/i);
      if (sStart !== -1) {
        let depth = 0;
        let inStr = false;
        let sEnd = -1;
        for (let i = sStart; i < astContent.length; i++) {
          const ch = astContent[i];
          if (ch === '"' && (i === 0 || astContent[i - 1] !== '\\')) {
            inStr = !inStr;
          } else if (!inStr) {
            if (ch === '(') depth++;
            else if (ch === ')') {
              depth--;
              if (depth === 0) {
                sEnd = i + 1;
                break;
              }
            }
          }
        }
        if (sEnd !== -1) {
          astContent = astContent.slice(sStart, sEnd);
        }
      }
    }

    const extractSlot = (a, b) => {
      const text = b ? a : astContent;
      const reg = b ? b : a;
      if (!text || typeof text !== 'string') return null;
      const match = text.match(reg);
      return match ? match[1].trim().replace(/^"|"$/g, '') : null;
    };

    const extractQuoted = (text, key) => {
      if (!text || typeof text !== 'string') return null;
      const reg = new RegExp(`:${key}\\s+"((?:[^"\\\\]|\\\\.)*)"`, 'i');
      const m = text.match(reg);
      if (m) return m[1].replace(/\\"/g, '"');
      const fallbackReg = new RegExp(`:${key}\\s+([^\\s\\)]+)`, 'i');
      const fb = text.match(fallbackReg);
      return fb ? fb[1].replace(/^"|"$/g, '') : null;
    };

    const id = extractSlot(/:id\s+("[^"]+"|[^\s\)]+)/i);
    const rawType = extractSlot(/:type\s+("Sim"|"Slide"|"App"|"Film"|"[^"]+"|[^\s\)]+)/i);
    const video = extractSlot(/:video\s+("((?:[^"\\]|\\.)*)"|[^\s\)]+)/i) || extractQuoted(astContent, 'video') || extractSlot(/:film\s+("((?:[^"\\]|\\.)*)"|[^\s\)]+)/i) || extractQuoted(astContent, 'film');
    const videoFit = extractSlot(/:video-?fit\s+("((?:[^"\\]|\\.)*)"|[^\s\)]+)/i) || extractQuoted(astContent, 'video-fit') || extractQuoted(astContent, 'videoFit') || 'contain';
    let type = 'Sim';
    if (rawType) {
      const norm = rawType.toLowerCase();
      if (norm === 'film' || norm === 'video' || norm === 'movie') type = 'Film';
      else if (norm === 'slide') type = 'Slide';
      else if (norm === 'app') type = 'App';
      else if (norm === 'data') type = 'Data';
      else type = 'Sim';
    } else if (video) {
      type = 'Film';
    } else {
      const hasSubtitles = /:subtitles\s*\(/i.test(astContent);
      const hasGestures = /:gestures\s*\(/i.test(astContent) || /:draggable\s+/i.test(astContent);
      const hasCheckpoints = /:interactive\s*\(/i.test(astContent) || /:checkpoint\s+/i.test(astContent) || /:questions\s*\(/i.test(astContent);
      const hasPhysics = /:physics\s*\(/i.test(astContent) || /:emitter\s+/i.test(astContent);
      if (hasSubtitles && !hasGestures && !hasPhysics) {
        type = 'Slide';
      } else if (hasGestures || hasPhysics || hasCheckpoints) {
        type = 'Sim';
      } else {
        type = 'App';
      }
    }
    const title = extractSlot(/:title\s+"([^"]+)"/i);
    const stage = extractSlot(/:stage\s+"([^"]+)"/i) || 'CURRICULUM';
    const durationStr = extractSlot(/:duration\s+([\d\.]+)/i);
    const duration = durationStr ? parseFloat(durationStr) : 10.0;
    const bootSound = extractQuoted(astContent, 'boot-sound') || extractQuoted(astContent, 'bootSound') || null;

    // Helper to extract S-expression blocks with balanced parentheses and string quote protection
    const extractSexprBlocks = (text, tag) => {
      const blocks = [];
      const safeTag = tag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const startRegex = new RegExp('\\(' + safeTag + '[\\s)]', 'gi');
      let m;
      while ((m = startRegex.exec(text)) !== null) {
        const startIdx = m.index;
        let depth = 0;
        let inString = false;
        let endIdx = -1;
        for (let i = startIdx; i < text.length; i++) {
          const char = text[i];
          if (char === '"' && (i === 0 || text[i - 1] !== '\\')) {
            inString = !inString;
          } else if (!inString) {
            if (char === '(') depth++;
            else if (char === ')') {
              depth--;
              if (depth === 0) {
                endIdx = i + 1;
                break;
              }
            }
          }
        }
        if (endIdx !== -1) {
          blocks.push(text.slice(startIdx, endIdx));
        }
      }
      return blocks;
    };

    // Extract either (:tag ( ... )) or plist-style :tag ( ... )
    const extractKeywordBlocks = (text, tag) => {
      const direct = extractSexprBlocks(text, tag);
      if (direct.length > 0) return direct;
      const blocks = [];
      const safeTag = tag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const kwRegex = new RegExp(`(?:^|[\\s(])${safeTag}\\s+\\(`, 'gi');
      let m;
      while ((m = kwRegex.exec(text)) !== null) {
        const openIdx = text.indexOf('(', m.index + m[0].length - 1);
        if (openIdx === -1) continue;
        let depth = 0;
        let inString = false;
        let endIdx = -1;
        for (let i = openIdx; i < text.length; i++) {
          const char = text[i];
          if (char === '"' && (i === 0 || text[i - 1] !== '\\')) {
            inString = !inString;
          } else if (!inString) {
            if (char === '(') depth++;
            else if (char === ')') {
              depth--;
              if (depth === 0) {
                endIdx = i + 1;
                break;
              }
            }
          }
        }
        if (endIdx !== -1) {
          blocks.push(text.slice(openIdx, endIdx));
        }
      }
      return blocks;
    };

    // Extract direct child S-expressions from an enclosing list block
    const extractChildForms = (blockText) => {
      const forms = [];
      if (!blockText) return forms;
      let searchStart = blockText.indexOf('(');
      if (searchStart === -1) return forms;
      // If wrapped as (:tag (...)), unwrap outer form to inner list
      const trimmed = blockText.slice(searchStart).trim();
      let innerStart = 1;
      if (/^\(:[a-zA-Z0-9_-]+\s+\(/.test(trimmed)) {
        innerStart = trimmed.indexOf('(', 1) + 1;
      }
      let i = innerStart;
      while (i < trimmed.length) {
        const ch = trimmed[i];
        if (ch === ';') {
          while (i < trimmed.length && trimmed[i] !== '\n') i++;
          continue;
        }
        if (ch === '"') {
          i++;
          while (i < trimmed.length) {
            if (trimmed[i] === '\\') { i += 2; continue; }
            if (trimmed[i] === '"') { i++; break; }
            i++;
          }
          continue;
        }
        if (ch === '(') {
          let depth = 0;
          let inStr = false;
          const fStart = i;
          let fEnd = -1;
          for (; i < trimmed.length; i++) {
            const c = trimmed[i];
            if (c === '"' && (i === 0 || trimmed[i - 1] !== '\\')) {
              inStr = !inStr;
            } else if (!inStr) {
              if (c === '(') depth++;
              else if (c === ')') {
                depth--;
                if (depth === 0) {
                  fEnd = i + 1;
                  i++;
                  break;
                }
              }
            }
          }
          if (fEnd !== -1) {
            forms.push(trimmed.slice(fStart, fEnd));
            continue;
          }
        }
        if (ch === ')' && i === trimmed.length - 1) break;
        i++;
      }
      return forms;
    };

    const parseLiteralVal = (raw) => {
      if (raw === null || raw === undefined) return undefined;
      const clean = String(raw).replace(/^"|"$/g, '').replace(/\\"/g, '"');
      if (clean === 'true') return true;
      if (clean === 'false') return false;
      if (clean !== '' && !isNaN(Number(clean))) return Number(clean);
      return clean;
    };

    const extractSlotValue = (text, key) => {
      if (!text || typeof text !== 'string') return undefined;
      const safeK = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const qReg = new RegExp(`:${safeK}\\s+"((?:[^"\\\\]|\\\\.)*)"`, 'i');
      const qm = text.match(qReg);
      if (qm) return qm[1].replace(/\\"/g, '"');
      const aReg = new RegExp(`:${safeK}\\s+([^\\s\\)]+)`, 'i');
      const am = text.match(aReg);
      if (!am) return undefined;
      return parseLiteralVal(am[1]);
    };

    // Camera definition with balanced parenthesis S-expression extraction
    const camBlocks = extractSexprBlocks(astContent, ':camera');
    let camera = { distance: 500, pitch: 20, yaw: 0, fov: 60 };
    if (camBlocks.length > 0) {
      const cBody = camBlocks[0];
      const getCamVal = (key) => {
        const m = cBody.match(new RegExp(`:${key}\\s+("[^"]+"|[\\d\\.-]+)`, 'i'));
        return m ? m[1].replace(/^"|"$/g, '') : null;
      };
      if (getCamVal('distance')) camera.distance = parseFloat(getCamVal('distance'));
      if (getCamVal('pitch')) camera.pitch = parseFloat(getCamVal('pitch')) || getCamVal('pitch');
      if (getCamVal('yaw')) camera.yaw = parseFloat(getCamVal('yaw')) || getCamVal('yaw');
      if (getCamVal('fov')) camera.fov = parseFloat(getCamVal('fov'));
    }

    // Keyframes
    const keyframes = [];
    const kfRegex = /\(:t\s+([\d\.]+)\s+:title\s+"([^"]+)"\s+:rule\s+"([^"]+)"\)/gi;
    let match;
    while ((match = kfRegex.exec(astContent)) !== null) {
      keyframes.push({
        t: parseFloat(match[1]),
        title: match[2],
        rule: match[3]
      });
    }

    // Subtitles
    const subtitles = [];
    const subRegex = /\(:start\s+([\d\.]+)\s+:end\s+([\d\.]+)\s+:en\s+"([^"]+)"(?:\s+:es\s+"([^"]+)")?(?:\s+:la\s+"([^"]+)")?\)/gi;
    while ((match = subRegex.exec(astContent)) !== null) {
      const subObj = {
        start: parseFloat(match[1]),
        end: parseFloat(match[2]),
        en: match[3]
      };
      if (match[4]) subObj.es = match[4];
      if (match[5]) subObj.la = match[5];
      subtitles.push(subObj);
    }

    // Bindings (2D, Text, Var integration, 3D nodes, 3D lines, 3D rings, 3D polygons)
    const bindings = [];
    const bindBlocks = extractSexprBlocks(astContent, ':target');

    bindBlocks.forEach(block => {
      const target = extractQuoted(block, 'target') || extractSlot.call(null, block, /:target\s+"([^"]+)"/i);
      const type = extractSlot.call(null, block, /:type\s+"([^"]+)"/i);
      const attr = extractQuoted(block, 'attr') || extractSlot.call(null, block, /:attr\s+"([^"]+)"/i);
      const expr = extractQuoted(block, 'expr') || extractSlot.call(null, block, /:expr\s+"([^"]+)"/i);

      const zLayerStr = extractSlot.call(null, block, /:z-layer\s+([\d\.\-]+)/i);
      const zLayer = zLayerStr !== null ? parseFloat(zLayerStr) : undefined;
      const zBiasStr = extractSlot.call(null, block, /:z-bias\s+([\d\.\-]+)/i);
      const zBias = zBiasStr !== null ? parseFloat(zBiasStr) : undefined;
      const sortAfter = extractQuoted(block, 'sort-after') || extractQuoted(block, 'sortAfter') || undefined;

      if (type === '3d-node') {
        const x = extractSlot.call(null, block, /:x\s+"([^"]+)"/i) || '0';
        const y = extractSlot.call(null, block, /:y\s+"([^"]+)"/i) || '0';
        const z = extractSlot.call(null, block, /:z\s+"([^"]+)"/i) || '0';
        const baseRStr = extractSlot.call(null, block, /:base-r\s+([\d\.]+)/i);
        const baseR = baseRStr ? parseFloat(baseRStr) : 8;
        const label = extractSlot.call(null, block, /:label\s+"([^"]+)"/i);
        const depthFogStr = extractSlot.call(null, block, /:depth-fog\s+([^\s\)]+)/i);
        const depthFog = depthFogStr !== 'false';

        const entry = {
          type: '3d-node',
          target,
          x,
          y,
          z,
          baseR,
          label,
          depthFog
        };
        if (zLayer !== undefined) entry.zLayer = zLayer;
        if (zBias !== undefined) entry.zBias = zBias;
        if (sortAfter) entry.sortAfter = sortAfter;
        bindings.push(entry);
      } else if (type === '3d-line') {
        const splitExpr = extractQuoted(block, 'split-expr') || extractQuoted(block, 'splitExpr') || undefined;
        const splineA = extractQuoted(block, 'spline-a') || extractQuoted(block, 'splineA') || undefined;
        const splineB = extractQuoted(block, 'spline-b') || extractQuoted(block, 'splineB') || undefined;
        const splineIndexStr = extractSlot.call(null, block, /:spline-index\s+(\d+)/i);
        const splineIndex = splineIndexStr !== null ? parseInt(splineIndexStr, 10) : undefined;
        const entry = {
          type: '3d-line',
          target,
          x1: extractSlot.call(null, block, /:x1\s+"([^"]+)"/i) || '0',
          y1: extractSlot.call(null, block, /:y1\s+"([^"]+)"/i) || '0',
          z1: extractSlot.call(null, block, /:z1\s+"([^"]+)"/i) || '0',
          x2: extractSlot.call(null, block, /:x2\s+"([^"]+)"/i) || '0',
          y2: extractSlot.call(null, block, /:y2\s+"([^"]+)"/i) || '0',
          z2: extractSlot.call(null, block, /:z2\s+"([^"]+)"/i) || '0',
          cap1: extractSlot.call(null, block, /:cap1\s+"([^"]+)"/i),
          cap2: extractSlot.call(null, block, /:cap2\s+"([^"]+)"/i),
          baseR: parseFloat(extractSlot.call(null, block, /:base-r\s+([\d\.]+)/i) || '8')
        };
        if (zLayer !== undefined) entry.zLayer = zLayer;
        if (zBias !== undefined) entry.zBias = zBias;
        if (sortAfter) entry.sortAfter = sortAfter;
        if (splitExpr) entry.splitExpr = splitExpr;
        if (splineA) entry.splineA = splineA;
        if (splineB) entry.splineB = splineB;
        if (splineIndex !== undefined) entry.splineIndex = splineIndex;
        bindings.push(entry);
      } else if (type === '3d-ring') {
        const rStr = extractSlot.call(null, block, /:r\s+("[^"]+"|[\d\.]+)/i) || '100';
        const cx = extractSlot.call(null, block, /:cx\s+"([^"]+)"/i) || '0';
        const cy = extractSlot.call(null, block, /:cy\s+"([^"]+)"/i) || '0';
        const cz = extractSlot.call(null, block, /:cz\s+"([^"]+)"/i) || '0';
        const tiltX = extractSlot.call(null, block, /:tilt-x\s+("[^"]+"|[\d\.-]+)/i) || '0';
        const tiltY = extractSlot.call(null, block, /:tilt-y\s+("[^"]+"|[\d\.-]+)/i) || '0';
        const tiltZ = extractSlot.call(null, block, /:tilt-z\s+("[^"]+"|[\d\.-]+)/i) || '0';
        const segsStr = extractSlot.call(null, block, /:segments\s+([\d]+)/i);
        const segments = segsStr ? parseInt(segsStr, 10) : 24;
        const depthFogStr = extractSlot.call(null, block, /:depth-fog\s+([^\s\)]+)/i);
        const depthFog = depthFogStr !== 'false';

        const entry = {
          type: '3d-ring',
          target,
          r: rStr,
          cx, cy, cz,
          tiltX, tiltY, tiltZ,
          segments,
          depthFog
        };
        if (zLayer !== undefined) entry.zLayer = zLayer;
        if (zBias !== undefined) entry.zBias = zBias;
        if (sortAfter) entry.sortAfter = sortAfter;
        bindings.push(entry);
      } else if (type === '3d-polygon') {
        const ptsStr = extractSlot.call(null, block, /:points\s+"([^"]+)"/i) || extractSlot.call(null, block, /:pts\s+"([^"]+)"/i);
        const depthFogStr = extractSlot.call(null, block, /:depth-fog\s+([^\s\)]+)/i);
        const depthFog = depthFogStr !== 'false';
        const cullBackfaceStr = extractSlot.call(null, block, /:cull-backface\s+([^\s\)]+)/i);
        const cullBackface = cullBackfaceStr === 'true';

        const entry = {
          type: '3d-polygon',
          target,
          pointsExpr: ptsStr,
          depthFog,
          cullBackface
        };
        if (zLayer !== undefined) entry.zLayer = zLayer;
        if (zBias !== undefined) entry.zBias = zBias;
        if (sortAfter) entry.sortAfter = sortAfter;
        bindings.push(entry);
      } else if (target && attr && expr) {
        bindings.push({
          type: '2d-attr',
          target,
          attr,
          expr
        });
      }
    });

    // Also parse (:attr ...), (:text ...), and (:var ...) forms inside :bindings (...)
    const bindListBlocks = extractKeywordBlocks(astContent, ':bindings');
    if (bindListBlocks.length > 0) {
      const bindForms = extractChildForms(bindListBlocks[0]);
      bindForms.forEach(form => {
        if (/^\(\s*:attr\b/i.test(form)) {
          const target = extractQuoted(form, 'target');
          const attrName = extractQuoted(form, 'name') || extractQuoted(form, 'attr');
          const expr = extractQuoted(form, 'expr');
          if (target && attrName && expr) {
            bindings.push({ type: '2d-attr', target, attr: attrName, expr });
          }
        } else if (/^\(\s*:text\b/i.test(form)) {
          const target = extractQuoted(form, 'target');
          const expr = extractQuoted(form, 'expr');
          if (target && expr) {
            bindings.push({ type: '2d-attr', target, attr: 'textContent', expr });
          }
        } else if (/^\(\s*:var\b/i.test(form)) {
          const vMatch = form.match(/^\(\s*:var\s+(?::name\s+)?"((?:[^"\\]|\\.)*)"/i)
            || form.match(/^\(\s*:var\s+([^\s\)]+)/i);
          const varName = vMatch ? vMatch[1].replace(/\\"/g, '"') : null;
          const expr = extractQuoted(form, 'expr');
          if (varName && expr) {
            bindings.push({ type: 'var-update', varName, expr });
          }
        }
      });
    }

    // Checkpoints (Interactive Formative Assessment)
    const checkpoints = [];
    const isInteractiveExplicitlyDisabled = /:interactive\s+(false|nil|none)\b/i.test(astContent) ||
      /:questions\s+(false|nil|none)\b/i.test(astContent) ||
      /:type\s+"App"/i.test(astContent) ||
      extractSexprBlocks(astContent, ':interactive').some(b => /:(?:enabled|active|questions)\s+(false|nil)\b/i.test(b));

    if (!isInteractiveExplicitlyDisabled) {
      const cpEntryBlocks = extractSexprBlocks(astContent, ':checkpoint');
      cpEntryBlocks.forEach(cpText => {
      const tMatch = cpText.match(/:t\s+([\d\.]+)/i);
      const cpTitle = extractQuoted(cpText, 'title') || extractSlot.call(null, cpText, /:title\s+"([^"]+)"/i) || 'Checkpoint';
      const prompt = extractQuoted(cpText, 'prompt') || extractSlot.call(null, cpText, /:prompt\s+"([^"]+)"/i) || '';
      const ansMatch = cpText.match(/:answer\s+(\d+)/i);
      const explanation = extractQuoted(cpText, 'explanation') || extractSlot.call(null, cpText, /:explanation\s+"([^"]+)"/i) || '';
      const passExpr = extractQuoted(cpText, 'pass-expr') || extractQuoted(cpText, 'passExpr') || null;
      const holdDurStr = extractSlot.call(null, cpText, /:hold-?duration\s+([\d\.]+)/i);
      const holdDuration = holdDurStr !== null ? parseFloat(holdDurStr) : undefined;

      const options = [];
      const optTagIdx = cpText.indexOf(':options');
      if (optTagIdx !== -1) {
        const startParen = cpText.indexOf('(', optTagIdx);
        if (startParen !== -1) {
          let depth = 0;
          let inString = false;
          let endParen = -1;
          for (let i = startParen; i < cpText.length; i++) {
            const ch = cpText[i];
            if (ch === '"' && (i === 0 || cpText[i - 1] !== '\\')) {
              inString = !inString;
            } else if (!inString) {
              if (ch === '(') depth++;
              else if (ch === ')') {
                depth--;
                if (depth === 0) {
                  endParen = i;
                  break;
                }
              }
            }
          }
          if (endParen !== -1) {
            const inside = cpText.slice(startParen + 1, endParen);
            const optRegex = /"((?:[^"\\]|\\.)*)"/g;
            let om;
            while ((om = optRegex.exec(inside)) !== null) {
              options.push(om[1].replace(/\\"/g, '"'));
            }
          }
        }
      }

      const onWrong = {};
      let owSearch = 0;
      while (true) {
        const relIdx = cpText.slice(owSearch).search(/:on-?wrong\s*\(/i);
        if (relIdx === -1) break;
        const pStart = cpText.indexOf('(', owSearch + relIdx);
        if (pStart === -1) break;
        let depth = 0;
        let inStr = false;
        let pEnd = -1;
        for (let i = pStart; i < cpText.length; i++) {
          const ch = cpText[i];
          if (ch === '"' && (i === 0 || cpText[i - 1] !== '\\')) {
            inStr = !inStr;
          } else if (!inStr) {
            if (ch === '(') depth++;
            else if (ch === ')') {
              depth--;
              if (depth === 0) {
                pEnd = i;
                break;
              }
            }
          }
        }
        if (pEnd === -1) break;
        const owInside = cpText.slice(pStart + 1, pEnd);
        const pairRe = /(\d+)\s+"((?:[^"\\]|\\.)*)"/g;
        let pm;
        while ((pm = pairRe.exec(owInside)) !== null) {
          onWrong[parseInt(pm[1], 10)] = pm[2].replace(/\\"/g, '"');
        }
        owSearch = pEnd + 1;
      }

      if (tMatch && prompt) {
        const cpEntry = {
          t: parseFloat(tMatch[1]),
          title: cpTitle,
          prompt: prompt,
          options: passExpr ? options : (options.length > 0 ? options : ['Correct', 'Incorrect']),
          answer: ansMatch ? parseInt(ansMatch[1], 10) : 0,
          explanation: explanation
        };
        if (passExpr) cpEntry.passExpr = passExpr;
        if (holdDuration !== undefined) cpEntry.holdDuration = holdDuration;
        if (Object.keys(onWrong).length > 0) cpEntry.onWrong = onWrong;
        checkpoints.push(cpEntry);
      }
    });

      // Also extract questions from (:questions ((:q ...))) if no explicit :checkpoint entries were defined
      if (checkpoints.length === 0) {
        const nonQuestAst = extractSexprBlocks(astContent, ':quests').reduce((acc, qb) => acc.replace(qb, ''), astContent);
        const qEntryBlocks = extractSexprBlocks(nonQuestAst, ':q').concat(extractSexprBlocks(nonQuestAst, ':question'));
        if (qEntryBlocks.length > 0) {
          const count = qEntryBlocks.length;
          const dur = Math.max(12.0, count * 3.0);
          qEntryBlocks.forEach((qText, qIdx) => {
            const prompt = extractSlot.call(null, qText, /:prompt\s+"([^"]+)"/i) || extractSlot.call(null, qText, /:q\s+"([^"]+)"/i) || '';
            const ansMatch = qText.match(/:answer\s+(\d+)/i) || qText.match(/:ans\s+(\d+)/i);
            const explanation = extractSlot.call(null, qText, /:explanation\s+"([^"]+)"/i) || '';
            const hint = extractSlot.call(null, qText, /:hint\s+"([^"]+)"/i) || '';
            const optTagIdx = qText.indexOf(':options');
            const options = [];
            if (optTagIdx !== -1) {
              const startParen = qText.indexOf('(', optTagIdx);
              if (startParen !== -1) {
                let depth = 0;
                let inString = false;
                let endParen = -1;
                for (let i = startParen; i < qText.length; i++) {
                  const ch = qText[i];
                  if (ch === '"' && (i === 0 || qText[i - 1] !== '\\')) {
                    inString = !inString;
                  } else if (!inString) {
                    if (ch === '(') depth++;
                    else if (ch === ')') {
                      depth--;
                      if (depth === 0) {
                        endParen = i;
                        break;
                      }
                    }
                  }
                }
                if (endParen !== -1) {
                  const inside = qText.slice(startParen + 1, endParen);
                  const optRegex = /"((?:[^"\\]|\\.)*)"/g;
                  let om;
                  while ((om = optRegex.exec(inside)) !== null) {
                    options.push(om[1]);
                  }
                }
              }
            }
            if (prompt) {
              checkpoints.push({
                t: parseFloat(((qIdx + 1) / (count + 1) * dur).toFixed(2)),
                title: `Question ${qIdx + 1} of ${count}`,
                prompt: prompt,
                options: options.length > 0 ? options : ['Correct', 'Incorrect'],
                answer: ansMatch ? parseInt(ansMatch[1], 10) : 0,
                explanation: explanation || hint || ''
              });
            }
          });
        }
      }
    }

    // Micro-physics block parsing (:physics (:gravity 980 :restitution 0.7 :friction 0.25 :stiffness 120 :damping 4 :substeps 4) (:body ...) (:spring ...))
    const physicsBlocks = extractSexprBlocks(astContent, ':physics');
    let physics = null;
    if (physicsBlocks.length > 0) {
      const pb = physicsBlocks[0];
      const gMatch = pb.match(/:gravity\s+([\d\.\-]+)/i);
      const fMatch = pb.match(/:friction\s+([\d\.]+)/i);
      const rMatch = pb.match(/:(?:restitution|bounce)\s+([\d\.]+)/i);
      const stMatch = pb.match(/:stiffness\s+([\d\.]+)/i);
      const dmpMatch = pb.match(/:damping\s+([\d\.]+)/i);
      const subMatch = pb.match(/:substeps\s+(\d+)/i);
      const drgMatch = pb.match(/:drag\s+([\d\.]+)/i);
      const grMatch = pb.match(/:ground(?:Y)?\s+([\d\.]+)/i);

      const defRestitution = rMatch ? parseFloat(rMatch[1]) : 0.45;
      const defFriction = fMatch ? parseFloat(fMatch[1]) : 0.25;
      const defStiffness = stMatch ? parseFloat(stMatch[1]) : 120;
      const defDamping = dmpMatch ? parseFloat(dmpMatch[1]) : 4.0;

      const bodyBlocks = extractSexprBlocks(pb, ':body');
      const bodies = bodyBlocks.map(bText => {
        const bId = extractSlot(bText, /:id\s+"([^"]+)"/i) || extractSlot(bText, /:id\s+([^\s\)]+)/i);
        const target = extractSlot(bText, /:target\s+"([^"]+)"/i) || extractSlot(bText, /:target\s+([^\s\)]+)/i);
        const x = parseFloat(extractSlot(bText, /:x\s+([\d\.\-]+)/i) || 0);
        const y = parseFloat(extractSlot(bText, /:y\s+([\d\.\-]+)/i) || 0);
        const vx = parseFloat(extractSlot(bText, /:vx\s+([\d\.\-]+)/i) || 0);
        const vy = parseFloat(extractSlot(bText, /:vy\s+([\d\.\-]+)/i) || 0);
        const mass = parseFloat(extractSlot(bText, /:mass\s+([\d\.]+)/i) || 1.0);
        const rStr = extractSlot(bText, /:(?:restitution|bounce)\s+([\d\.]+)/i);
        const bounce = rStr !== null ? parseFloat(rStr) : defRestitution;
        const bfStr = extractSlot(bText, /:friction\s+([\d\.]+)/i);
        const bFriction = bfStr !== null ? parseFloat(bfStr) : defFriction;
        const radius = parseFloat(extractSlot(bText, /:radius\s+([\d\.]+)/i) || 16);
        const groundYStr = extractSlot(bText, /:ground(?:Y)?\s+([\d\.]+)/i);
        const groundY = groundYStr ? parseFloat(groundYStr) : undefined;
        const staticMatch = bText.match(/:(?:isStatic|static)\s+(true|false)/i);
        const isStatic = staticMatch ? staticMatch[1] === 'true' : false;
        const stStr = extractSlot(bText, /:stiffness\s+([\d\.]+)/i);
        const dmStr = extractSlot(bText, /:damping\s+([\d\.]+)/i);
        const lenStr = extractSlot(bText, /:length\s+([\d\.]+)/i);
        const axStr = extractSlot(bText, /:anchor-?x\s+([\d\.\-]+)/i);
        const ayStr = extractSlot(bText, /:anchor-?y\s+([\d\.\-]+)/i);
        const entry = {
          id: bId,
          target: target || `#${bId}`,
          x, y, vx, vy, mass,
          bounce,
          restitution: bounce,
          friction: bFriction,
          radius,
          groundY,
          isStatic
        };
        if (stStr !== null) entry.stiffness = parseFloat(stStr);
        if (dmStr !== null) entry.damping = parseFloat(dmStr);
        if (lenStr !== null) entry.length = parseFloat(lenStr);
        if (axStr !== null) entry.anchorX = parseFloat(axStr);
        if (ayStr !== null) entry.anchorY = parseFloat(ayStr);
        return entry;
      });

      const springBlocks = extractSexprBlocks(pb, ':spring');
      const springs = springBlocks.map((sText, sIdx) => {
        const sId = extractSlot(sText, /:id\s+"([^"]+)"/i) || extractSlot(sText, /:id\s+([^\s\)]+)/i) || `spring_${sIdx + 1}`;
        const a = extractSlot(sText, /:a\s+"([^"]+)"/i) || extractSlot(sText, /:a\s+([^\s\)]+)/i);
        const b = extractSlot(sText, /:b\s+"([^"]+)"/i) || extractSlot(sText, /:b\s+([^\s\)]+)/i)
          || extractSlot(sText, /:target\s+"([^"]+)"/i) || extractSlot(sText, /:target\s+([^\s\)]+)/i);
        const lineTarget = extractSlot(sText, /:line\s+"([^"]+)"/i) || extractSlot(sText, /:line\s+([^\s\)]+)/i);
        const axStr = extractSlot(sText, /:anchor-?x\s+([\d\.\-]+)/i);
        const ayStr = extractSlot(sText, /:anchor-?y\s+([\d\.\-]+)/i);
        const lenStr = extractSlot(sText, /:(?:rest-)?length\s+([\d\.]+)/i);
        const kStr = extractSlot(sText, /:(?:stiffness|k)\s+([\d\.]+)/i);
        const cStr = extractSlot(sText, /:(?:damping|c)\s+([\d\.]+)/i);
        return {
          id: sId,
          a: a || null,
          b: b || null,
          lineTarget: lineTarget || null,
          anchorX: axStr !== null ? parseFloat(axStr) : 0,
          anchorY: ayStr !== null ? parseFloat(ayStr) : 0,
          length: lenStr !== null ? parseFloat(lenStr) : undefined,
          stiffness: kStr !== null ? parseFloat(kStr) : defStiffness,
          damping: cStr !== null ? parseFloat(cStr) : defDamping
        };
      });

      physics = {
        gravity: gMatch ? parseFloat(gMatch[1]) : 980,
        restitution: defRestitution,
        friction: defFriction,
        stiffness: defStiffness,
        damping: defDamping,
        substeps: subMatch ? parseInt(subMatch[1], 10) : 4,
        drag: drgMatch ? parseFloat(drgMatch[1]) : 0,
        groundY: grMatch ? parseFloat(grMatch[1]) : 420,
        bodies,
        springs
      };
    }

    // Reactive State Variables
    // Supports (:vars ((:var :name "volume" :val 1.0 ...))) AND :vars ((posX :default 400.0 :min 90.0 :max 710.0) ...)
    const vars = {};
    const varBlocks = extractKeywordBlocks(astContent, ':vars');
    if (varBlocks.length > 0) {
      const vEntries = extractSexprBlocks(varBlocks[0], ':var');
      vEntries.forEach(vText => {
        const name = extractSlot.call(null, vText, /:name\s+"([^"]+)"/i) || extractSlot.call(null, vText, /:name\s+([^\s\)]+)/i);
        const valRaw = extractSlotValue(vText, 'val') !== undefined ? extractSlotValue(vText, 'val') : extractSlotValue(vText, 'default');
        const minMatch = vText.match(/:min\s+([\d\.\-]+)/i);
        const maxMatch = vText.match(/:max\s+([\d\.\-]+)/i);
        const stepMatch = vText.match(/:step\s+([\d\.]+)/i);
        const unit = extractSlot.call(null, vText, /:unit\s+"([^"]+)"/i) || '';
        const label = extractSlot.call(null, vText, /:label\s+"([^"]+)"/i) || name;
        if (name && valRaw !== undefined) {
          const isNumeric = typeof valRaw === 'number' && Number.isFinite(valRaw);
          const hasMin = Boolean(minMatch);
          const hasMax = Boolean(maxMatch);
          const hasStep = Boolean(stepMatch);
          vars[name] = {
            name,
            value: valRaw,
            defaultValue: valRaw,
            min: hasMin ? parseFloat(minMatch[1]) : (isNumeric ? 0 : undefined),
            max: hasMax ? parseFloat(maxMatch[1]) : (isNumeric ? 100 : undefined),
            step: hasStep ? parseFloat(stepMatch[1]) : (isNumeric ? 1 : undefined),
            hasMin,
            hasMax,
            hasStep,
            hasExplicitBounds: hasMin && hasMax,
            unit,
            label
          };
        }
      });

      const directVarForms = extractChildForms(varBlocks[0]);
      directVarForms.forEach(vText => {
        if (/^\(\s*:var\b/i.test(vText)) return;
        const headMatch = vText.match(/^\(\s*([a-zA-Z_$][a-zA-Z0-9_$-]*)\b/);
        if (!headMatch) return;
        const name = headMatch[1];
        const valRaw = extractSlotValue(vText, 'default') !== undefined ? extractSlotValue(vText, 'default') : extractSlotValue(vText, 'val');
        const minMatch = vText.match(/:min\s+([\d\.\-]+)/i);
        const maxMatch = vText.match(/:max\s+([\d\.\-]+)/i);
        const stepMatch = vText.match(/:step\s+([\d\.]+)/i);
        const unit = extractSlot.call(null, vText, /:unit\s+"([^"]+)"/i) || '';
        const label = extractSlot.call(null, vText, /:label\s+"([^"]+)"/i) || name;
        if (name && valRaw !== undefined) {
          const isNumeric = typeof valRaw === 'number' && Number.isFinite(valRaw);
          const hasMin = Boolean(minMatch);
          const hasMax = Boolean(maxMatch);
          const hasStep = Boolean(stepMatch);
          vars[name] = {
            name,
            value: valRaw,
            defaultValue: valRaw,
            min: hasMin ? parseFloat(minMatch[1]) : (isNumeric ? 0 : undefined),
            max: hasMax ? parseFloat(maxMatch[1]) : (isNumeric ? 100 : undefined),
            step: hasStep ? parseFloat(stepMatch[1]) : (isNumeric ? 1 : undefined),
            hasMin,
            hasMax,
            hasStep,
            hasExplicitBounds: hasMin && hasMax,
            unit,
            label
          };
        }
      });
    }

    // UI Controls Projection Subsystem: Fantasy Console / Lisp Machine Architecture
    // Canonical: (ui:controls (control:button ...) (control:toggle ...) (control:slider ...) (control:select ...))
    // Keyword/Legacy: (:ui-controls (...)) or (:inputs (...))
    const uiControls = [];
    const uiBlocks = extractSexprBlocks(astContent, 'ui:controls')
      .concat(extractSexprBlocks(astContent, ':ui-controls'))
      .concat(extractSexprBlocks(astContent, ':inputs'));

    if (uiBlocks.length > 0) {
      const controlTags = [
        'control:button', 'control:toggle', 'control:slider', 'control:select',
        ':button', ':toggle', ':switch', ':slider', ':number', ':stepper', ':select'
      ];
      uiBlocks.forEach(blockText => {
        const positionedEntries = [];
        controlTags.forEach(tag => {
          const found = extractSexprBlocks(blockText, tag);
          let searchFrom = 0;
          found.forEach(entryText => {
            const pos = blockText.indexOf(entryText, searchFrom);
            searchFrom = pos >= 0 ? pos + entryText.length : searchFrom;
            positionedEntries.push({ entryText, pos });
          });
        });
        positionedEntries.sort((a, b) => a.pos - b.pos);
        const entries = positionedEntries.map(item => item.entryText);

        entries.forEach(entryText => {
          let ctrlType = 'button';
          if (entryText.includes('control:toggle') || entryText.includes(':toggle') || entryText.includes(':switch')) {
            ctrlType = 'toggle';
          } else if (entryText.includes('control:slider') || entryText.includes(':slider') || entryText.includes(':number') || entryText.includes(':stepper')) {
            ctrlType = 'slider';
          } else if (entryText.includes('control:select') || entryText.includes(':select')) {
            ctrlType = 'select';
          } else if (entryText.includes('control:button') || entryText.includes(':button')) {
            ctrlType = 'button';
          }

          const id = extractSlot.call(null, entryText, /:id\s+"([^"]+)"/i) 
            || extractSlot.call(null, entryText, /:id\s+([^\s\)]+)/i)
            || extractSlot.call(null, entryText, /:var\s+"([^"]+)"/i)
            || extractSlot.call(null, entryText, /:var\s+([^\s\)]+)/i)
            || `ctrl_${uiControls.length + 1}`;

          const label = extractSlot.call(null, entryText, /:label\s+"([^"]+)"/i)
            || extractSlot.call(null, entryText, /:label\s+([^\s\)]+)/i)
            || id;

          let bind = extractSlot.call(null, entryText, /:bind\s+"([^"]+)"/i)
            || extractSlot.call(null, entryText, /:bind\s+([^\s\)]+)/i)
            || extractSlot.call(null, entryText, /:var\s+"([^"]+)"/i)
            || extractSlot.call(null, entryText, /:var\s+([^\s\)]+)/i)
            || null;

          let cleanBind = bind ? bind.replace(/^\*|\*$/g, '') : null;

          let action = null;
          const actionMatch = entryText.match(/:action\s+(\([^\)]+\)|"[^"]+"|([^\s\)]+))/i);
          if (actionMatch) {
            action = actionMatch[1].trim().replace(/^"|"$/g, '');
          } else if (ctrlType === 'button' && (id === 'reset' || id === 'sim:reset')) {
            action = '(sim:reset)';
          } else if (ctrlType === 'toggle' && (cleanBind === 'bsl-active' || cleanBind === 'bslActive' || id === 'bsl')) {
            action = '(player:toggle-bsl)';
          }

          const rawMinStr = extractSlot.call(null, entryText, /:min\s+([\d\.\-]+)/i);
          const rawMaxStr = extractSlot.call(null, entryText, /:max\s+([\d\.\-]+)/i);
          const rawStepStr = extractSlot.call(null, entryText, /:step\s+([\d\.]+)/i);
          const unit = extractSlot.call(null, entryText, /:unit\s+"([^"]+)"/i) || '';
          const hasMin = rawMinStr !== null && rawMinStr !== undefined;
          const hasMax = rawMaxStr !== null && rawMaxStr !== undefined;
          const hasStep = rawStepStr !== null && rawStepStr !== undefined;
          const min = parseFloat(rawMinStr || '0');
          const max = parseFloat(rawMaxStr || '100');
          const step = parseFloat(rawStepStr || '1');
          const defaultStr = extractSlot.call(null, entryText, /:default\s+"?([^"\s\)]+)"?/i)
            || extractSlot.call(null, entryText, /:val\s+"?([^"\s\)]+)"?/i);
          let defaultVal = defaultStr !== null ? (isNaN(Number(defaultStr)) ? defaultStr : parseFloat(defaultStr)) : undefined;

          let options = [];
          const optMatch = entryText.match(/:options\s*\(([^)]+)\)/i);
          if (optMatch) {
            const optStr = optMatch[1];
            const matches = optStr.match(/"([^"]+)"|([^\s"]+)/g);
            if (matches) {
              options = matches.map(s => s.replace(/^"|"$/g, ''));
            }
          }

          uiControls.push({
            id,
            type: ctrlType,
            label,
            bind: cleanBind,
            rawBind: bind,
            var: cleanBind,
            action,
            min,
            max,
            step,
            hasMin,
            hasMax,
            hasStep,
            unit,
            default: defaultVal,
            val: defaultVal,
            options
          });
        });
      });
    }
    const inputs = uiControls;

    // Derived & Computed Output Variables
    // Supports (:computed ((:name "pressure" :expr "..."))) AND :computed ((mult "...") ...)
    const computed = [];
    const compBlocks = extractKeywordBlocks(astContent, ':computed');
    if (compBlocks.length > 0) {
      const compEntries = extractSexprBlocks(compBlocks[0], ':name');
      compEntries.forEach(cText => {
        const name = extractSlot.call(null, cText, /:name\s+"([^"]+)"/i) || extractSlot.call(null, cText, /:name\s+([^\s\)]+)/i);
        const expr = extractQuoted(cText, 'expr') || extractSlot.call(null, cText, /:expr\s+"([^"]+)"/i);
        if (name && expr) {
          computed.push({ name, expr });
        }
      });

      const compForms = extractChildForms(compBlocks[0]);
      compForms.forEach(cText => {
        if (/^\(\s*:name\b/i.test(cText)) return;
        const pairMatch = cText.match(/^\(\s*([a-zA-Z_$][a-zA-Z0-9_$-]*)\s+"((?:[^"\\]|\\.)*)"\s*\)$/);
        if (pairMatch) {
          computed.push({
            name: pairMatch[1],
            expr: pairMatch[2].replace(/\\"/g, '"')
          });
        } else {
          const headMatch = cText.match(/^\(\s*([a-zA-Z_$][a-zA-Z0-9_$-]*)\b/);
          const expr = extractQuoted(cText, 'expr');
          if (headMatch && expr) {
            computed.push({ name: headMatch[1], expr });
          }
        }
      });
    }

    // Direct Manipulation & Keyboard Gestures (100% Declarative S-Expression VM)
    // Supports :draggable, :interactive, :clickable, :holdable, :trackball, :rotatable, :key
    const gestures = [];
    const gestureBlocks = extractKeywordBlocks(astContent, ':gestures');
    if (gestureBlocks.length > 0) {
      const gBlock = gestureBlocks[0];
      const gEntries = extractChildForms(gBlock);

      gEntries.forEach(gText => {
        if (gText.startsWith('(:interactive (') || gText.startsWith('(:interactive\n')) return;
        const isDraggable = /^\(\s*:draggable\b/i.test(gText);
        const isRotatable = /^\(\s*:rotatable\b/i.test(gText);
        const isTrackball = /^\(\s*:trackball\b/i.test(gText);
        const isClickable = /^\(\s*:clickable\b/i.test(gText);
        const isHoldable = /^\(\s*:holdable\b/i.test(gText);
        const isKey = /^\(\s*:key\b/i.test(gText);
        const isInteractive = /^\(\s*:interactive\b/i.test(gText);
        if (!isDraggable && !isRotatable && !isTrackball && !isClickable && !isHoldable && !isKey && !isInteractive) return;

        const bodyText = gText.replace(/^\(\s*:[a-zA-Z0-9_-]+/, '(');
        const target = extractSlot.call(null, bodyText, /:target\s+"([^"]+)"/i) || extractSlot.call(null, bodyText, /:target\s+([^\s\)]+)/i);
        const code = extractSlot.call(null, bodyText, /:code\s+"([^"]+)"/i) || extractSlot.call(null, bodyText, /:code\s+([^\s\)]+)/i);
        const key = extractSlot.call(null, bodyText, /:key\s+"([^"]+)"/i) || extractSlot.call(null, bodyText, /:key\s+([^\s\)]+)/i);
        const axis = extractSlot.call(null, bodyText, /:axis\s+"([^"]+)"/i) || (isTrackball ? 'trackball' : 'xy');
        const action = extractSlot.call(null, bodyText, /:action\s+"([^"]+)"/i);

        const minStr = extractSlot.call(null, bodyText, /:min\s+([\d\.\-]+)/i);
        const maxStr = extractSlot.call(null, bodyText, /:max\s+([\d\.\-]+)/i);
        const useDragDefaults = isDraggable || isRotatable || isInteractive;
        const min = minStr !== null ? parseFloat(minStr) : (useDragDefaults ? 0 : undefined);
        const max = maxStr !== null ? parseFloat(maxStr) : (useDragDefaults ? 800 : undefined);

        const minXStr = extractSlot.call(null, bodyText, /:min-x\s+([\d\.\-]+)/i);
        const maxXStr = extractSlot.call(null, bodyText, /:max-x\s+([\d\.\-]+)/i);
        const minYStr = extractSlot.call(null, bodyText, /:min-y\s+([\d\.\-]+)/i);
        const maxYStr = extractSlot.call(null, bodyText, /:max-y\s+([\d\.\-]+)/i);
        const minX = minXStr !== null ? parseFloat(minXStr) : min;
        const maxX = maxXStr !== null ? parseFloat(maxXStr) : max;
        const minY = minYStr !== null ? parseFloat(minYStr) : min;
        const maxY = maxYStr !== null ? parseFloat(maxYStr) : max;

        const cxStr = extractSlot.call(null, bodyText, /:cx\s+([\d\.\-]+)/i);
        const cyStr = extractSlot.call(null, bodyText, /:cy\s+([\d\.\-]+)/i);
        const cx = cxStr !== null ? parseFloat(cxStr) : undefined;
        const cy = cyStr !== null ? parseFloat(cyStr) : undefined;

        const varName = extractQuoted(bodyText, 'var') || extractQuoted(bodyText, 'bind-var');
        const varX = extractQuoted(bodyText, 'var-x') || extractQuoted(bodyText, 'varX');
        const varY = extractQuoted(bodyText, 'var-y') || extractQuoted(bodyText, 'varY');
        const yawVar = extractSlot.call(null, bodyText, /:yaw-var\s+"([^"]+)"/i) || null;
        const pitchVar = extractSlot.call(null, bodyText, /:pitch-var\s+"([^"]+)"/i) || null;
        const pitchMin = parseFloat(extractSlot.call(null, bodyText, /:pitch-min\s+([\d\.\-]+)/i) || '-65');
        const pitchMax = parseFloat(extractSlot.call(null, bodyText, /:pitch-max\s+([\d\.\-]+)/i) || '65');

        const toggleVar = extractSlot.call(null, bodyText, /:toggle-var\s+"([^"]+)"/i)
          || extractSlot.call(null, bodyText, /:toggle-var\s+([^\s\)]+)/i)
          || extractSlot.call(null, bodyText, /:toggle\s+"([^"]+)"/i)
          || extractSlot.call(null, bodyText, /:toggle\s+([^\s\)]+)/i);
        const setVar = extractSlot.call(null, bodyText, /:set-var\s+"([^"]+)"/i)
          || extractSlot.call(null, bodyText, /:set-var\s+([^\s\)]+)/i)
          || extractSlot.call(null, bodyText, /:set\s+"([^"]+)"/i)
          || extractSlot.call(null, bodyText, /:set\s+([^\s\)]+)/i);
        const rawStepAttr = extractSlotValue(bodyText, 'step');
        const stepVar = extractQuoted(bodyText, 'step-var')
          || (typeof rawStepAttr === 'string' ? rawStepAttr : null);
        const step = typeof rawStepAttr === 'number' ? rawStepAttr : undefined;
        const holdVar = extractSlot.call(null, bodyText, /:hold-var\s+"([^"]+)"/i)
          || extractSlot.call(null, bodyText, /:hold-var\s+([^\s\)]+)/i);

        const expr = extractQuoted(bodyText, 'expr');
        const condExpr = extractQuoted(bodyText, 'if');
        const valExpr = extractQuoted(bodyText, 'val-expr') || extractQuoted(bodyText, 'valExpr');
        const toneRaw = extractSlotValue(bodyText, 'tone');
        const tone = toneRaw !== undefined && toneRaw !== null ? String(toneRaw) : null;
        const toneExpr = extractQuoted(bodyText, 'tone-expr') || extractQuoted(bodyText, 'toneExpr');
        const speak = extractQuoted(bodyText, 'speak');
        const speakExpr = extractQuoted(bodyText, 'speak-expr') || extractQuoted(bodyText, 'speakExpr');
        const speakRateVar = extractQuoted(bodyText, 'speak-rate-var') || extractQuoted(bodyText, 'speakRateVar');
        const speakPitchRaw = extractSlotValue(bodyText, 'speak-pitch');
        const speakPitchAlt = speakPitchRaw === undefined ? extractSlotValue(bodyText, 'speakPitch') : speakPitchRaw;
        const speakPitch = typeof speakPitchAlt === 'number' ? speakPitchAlt : undefined;

        const val = extractSlotValue(bodyText, 'val');
        const releaseVal = extractSlotValue(bodyText, 'release-val');
        const holdRaw = extractSlotValue(bodyText, 'hold');
        const hold = (isHoldable || holdRaw === true || Boolean(holdVar))
          ? true
          : (holdRaw === false ? false : undefined);
        const invert = extractSlotValue(bodyText, 'invert') === true;
        const relative = extractSlotValue(bodyText, 'relative') === true;
        const seek = extractSlotValue(bodyText, 'seek') === true;
        const deltaStr = extractSlot.call(null, bodyText, /:delta\s+([\d\.\-]+)/i);
        const delta = deltaStr !== null ? parseFloat(deltaStr) : 1;
        const rateStr = extractSlot.call(null, bodyText, /:rate\s+([\d\.\-]+)/i);
        const rate = rateStr !== null ? parseFloat(rateStr) : undefined;
        const attr = extractSlot.call(null, bodyText, /:attr\s+"([^"]+)"/i);

        if ((isKey && (code || key)) || target) {
          let gestureType = 'draggable';
          if (isKey) gestureType = 'key';
          else if (isHoldable) gestureType = 'holdable';
          else if (isClickable) gestureType = 'clickable';
          else if (isTrackball) gestureType = 'trackball';
          else if (isRotatable) gestureType = 'rotatable';
          else if (!isDraggable) gestureType = 'interactive';

          gestures.push({
            type: gestureType,
            target,
            code,
            key,
            axis,
            action,
            min,
            max,
            minX,
            maxX,
            minY,
            maxY,
            cx,
            cy,
            var: varName,
            varX,
            varY,
            yawVar,
            pitchVar,
            pitchMin,
            pitchMax,
            toggleVar,
            setVar,
            stepVar,
            step,
            holdVar,
            expr,
            ifExpr: condExpr,
            valExpr,
            tone,
            toneExpr,
            speak,
            speakExpr,
            speakRateVar,
            speakPitch,
            val,
            releaseVal,
            hold,
            invert,
            relative,
            seek,
            delta,
            rate,
            attr
          });
        }
      });
    }

    // Static Layer Primitives (:static ((:element :target "#bg" :cache true) ...))
    const staticElements = [];
    const staticBlocks = extractSexprBlocks(astContent, ':static');
    if (staticBlocks.length > 0) {
      const sEntries = extractSexprBlocks(staticBlocks[0], ':element');
      sEntries.forEach(sText => {
        const target = extractSlot.call(null, sText, /:target\s+"([^"]+)"/i) || extractSlot.call(null, sText, /:target\s+([^\s\)]+)/i);
        const layer = extractSlot.call(null, sText, /:layer\s+"([^"]+)"/i) || 'bg';
        const cacheMatch = sText.match(/:cache\s+(true|false)/i);
        if (target) {
          staticElements.push({
            target,
            layer,
            cache: cacheMatch ? cacheMatch[1] === 'true' : true
          });
        }
      });
    }

    // Dynamic Kinematic Actors (:actors ((:actor :target "#piston" :kinematic true) ...))
    const actors = [];
    const actorBlocks = extractSexprBlocks(astContent, ':actors');
    if (actorBlocks.length > 0) {
      const aEntries = extractSexprBlocks(actorBlocks[0], ':actor');
      aEntries.forEach(aText => {
        const target = extractSlot.call(null, aText, /:target\s+"([^"]+)"/i) || extractSlot.call(null, aText, /:target\s+([^\s\)]+)/i);
        const kinematicMatch = aText.match(/:kinematic\s+(true|false)/i);
        const willChangeMatch = aText.match(/:will-change\s+(true|false)/i);
        if (target) {
          actors.push({
            target,
            kinematic: kinematicMatch ? kinematicMatch[1] === 'true' : true,
            willChange: willChangeMatch ? willChangeMatch[1] === 'true' : true
          });
        }
      });
    }

    // Multi-Entity Particle Emitters, Pools & Obstacle Collision Pipelines
    const emitters = [];
    const emitterContainerBlocks = extractSexprBlocks(astContent, ':emitters');
    const emitterBlocks = emitterContainerBlocks.length > 0
      ? extractSexprBlocks(emitterContainerBlocks[0], ':emitter').concat(extractSexprBlocks(emitterContainerBlocks[0], ':particle-pool'))
      : extractSexprBlocks(astContent, ':emitter').concat(extractSexprBlocks(astContent, ':particle-pool'));

    emitterBlocks.forEach(emText => {
      const emId = extractSlot.call(null, emText, /:id\s+"([^"]+)"/i) || extractSlot.call(null, emText, /:id\s+([^\s\)]+)/i) || `emitter_${emitters.length + 1}`;
      const count = parseInt(extractSlot.call(null, emText, /:count\s+(\d+)/i) || '80', 10);
      const speed = parseFloat(extractSlot.call(null, emText, /:speed\s+([\d\.\-]+)/i) || '120');
      const radius = parseFloat(extractSlot.call(null, emText, /:radius\s+([\d\.]+)/i) || '4');
      const gravity = parseFloat(extractSlot.call(null, emText, /:gravity\s+([\d\.\-]+)/i) || '0');
      const fill = extractSlot.call(null, emText, /:fill\s+"([^"]+)"/i) || '#38bdf8';
      const wrapMode = extractSlot.call(null, emText, /:wrapMode\s+"([^"]+)"/i) || 'bounce';
      const boundsEl = extractSlot.call(null, emText, /:boundsElement\s+"([^"]+)"/i) || extractSlot.call(null, emText, /:boundsElement\s+([^\s\)]+)/i);
      const emRestStr = extractSlot.call(null, emText, /:(?:restitution|bounce)\s+([\d\.]+)/i);
      const emFricStr = extractSlot.call(null, emText, /:friction\s+([\d\.]+)/i);
      const emSubStr = extractSlot.call(null, emText, /:substeps\s+(\d+)/i);
      const speedExpr = extractQuoted(emText, 'speed-expr') || extractQuoted(emText, 'speedExpr') || null;
      const countExpr = extractQuoted(emText, 'count-expr') || extractQuoted(emText, 'countExpr') || null;
      const phaseExpr = extractQuoted(emText, 'phase-expr') || extractQuoted(emText, 'phaseExpr') || null;
      const clampXExpr = extractQuoted(emText, 'clamp-x-expr') || extractQuoted(emText, 'clampXExpr') || null;
      const placeholderSelector = extractQuoted(emText, 'placeholder-selector') || extractQuoted(emText, 'placeholderSelector') || null;
      const liquidMinYStr = extractSlot.call(null, emText, /:liquid-min-y\s+([\d\.\-]+)/i);
      const liquidMinY = liquidMinYStr !== null ? parseFloat(liquidMinYStr) : undefined;
      const phaseSyncMatch = emText.match(/:phase-?sync\s+(true|false)/i);
      const phaseSync = phaseSyncMatch ? phaseSyncMatch[1] === 'true' : false;

      // Explicit Bounds
      const minX = parseFloat(extractSlot.call(null, emText, /:minX\s+([\d\.\-]+)/i) || '40');
      const maxX = parseFloat(extractSlot.call(null, emText, /:maxX\s+([\d\.\-]+)/i) || '760');
      const minY = parseFloat(extractSlot.call(null, emText, /:minY\s+([\d\.\-]+)/i) || '40');
      const maxY = parseFloat(extractSlot.call(null, emText, /:maxY\s+([\d\.\-]+)/i) || '440');

      // Obstacles (:obstacles ((:obstacle :target "#piston-assembly" :restitution 1.0 :friction 0.1) ...))
      const obstacles = [];
      const obsContainerBlocks = extractSexprBlocks(emText, ':obstacles');
      if (obsContainerBlocks.length > 0) {
        const obsEntries = extractSexprBlocks(obsContainerBlocks[0], ':obstacle');
        obsEntries.forEach(obText => {
          const target = extractSlot.call(null, obText, /:target\s+"([^"]+)"/i) || extractSlot.call(null, obText, /:target\s+([^\s\)]+)/i);
          const bounce = parseFloat(extractSlot.call(null, obText, /:(?:restitution|bounce)\s+([\d\.]+)/i) || '1.0');
          const refract = parseFloat(extractSlot.call(null, obText, /:refract\s+([\d\.]+)/i) || '0');
          const friction = parseFloat(extractSlot.call(null, obText, /:friction\s+([\d\.]+)/i) || '0');
          if (target) {
            obstacles.push({ target, bounce, refract, friction });
          }
        });
      }

      emitters.push({
        id: emId,
        count,
        speed,
        speedExpr,
        countExpr,
        phaseExpr,
        clampXExpr,
        placeholderSelector,
        liquidMinY,
        phaseSync,
        radius,
        gravity,
        fill,
        wrapMode,
        restitution: emRestStr !== null ? parseFloat(emRestStr) : 1.0,
        friction: emFricStr !== null ? parseFloat(emFricStr) : 0.0,
        substeps: emSubStr !== null ? parseInt(emSubStr, 10) : 4,
        bounds: { minX, maxX, minY, maxY },
        boundsElement: boundsEl,
        obstacles
      });
    });

    // Declarative State Transition Machines (:state-machines)
    const stateMachines = [];
    const smContainerBlocks = extractSexprBlocks(astContent, ':state-machines');
    const smBlocks = smContainerBlocks.length > 0
      ? extractSexprBlocks(smContainerBlocks[0], ':state-machine')
      : extractSexprBlocks(astContent, ':state-machine');

    smBlocks.forEach(smText => {
      const smId = extractSlot.call(null, smText, /:id\s+"([^"]+)"/i) || extractSlot.call(null, smText, /:id\s+([^\s\)]+)/i) || `sm_${stateMachines.length + 1}`;
      const initial = extractSlot.call(null, smText, /:initial\s+"([^"]+)"/i) || extractSlot.call(null, smText, /:initial\s+([^\s\)]+)/i) || 'default';
      const dwell = parseFloat(extractSlot.call(null, smText, /:dwell\s+([\d\.]+)/i) || '0.25');

      // States
      const states = [];
      const stateContainer = extractSexprBlocks(smText, ':states');
      const stateBlocks = stateContainer.length > 0
        ? extractSexprBlocks(stateContainer[0], ':state')
        : extractSexprBlocks(smText, ':state');

      stateBlocks.forEach(stText => {
        const stName = extractSlot.call(null, stText, /:name\s+"([^"]+)"/i) || extractSlot.call(null, stText, /:name\s+([^\s\)]+)/i) || 'state';
        const attrs = Object.create(null);
        const attrBlocks = extractSexprBlocks(stText, ':attr');
        attrBlocks.forEach(atText => {
          const target = extractSlot.call(null, atText, /:target\s+"([^"]+)"/i) || extractSlot.call(null, atText, /:target\s+([^\s\)]+)/i);
          const attr = extractSlot.call(null, atText, /:attr\s+"([^"]+)"/i) || extractSlot.call(null, atText, /:attr\s+([^\s\)]+)/i) || 'fill';
          const val = extractSlot.call(null, atText, /:val\s+"([^"]+)"/i) || extractSlot.call(null, atText, /:val\s+([^\s\)]+)/i);
          if (target && attr) {
            if (!attrs[target]) attrs[target] = Object.create(null);
            attrs[target][attr] = val !== null ? val : '#38bdf8';
          }
        });

        // Emitter sets
        const emitterSets = [];
        const esBlocks = extractSexprBlocks(stText, ':emitter-set');
        esBlocks.forEach(esText => {
          const target = extractSlot.call(null, esText, /:target\s+"([^"]+)"/i) || extractSlot.call(null, esText, /:target\s+([^\s\)]+)/i);
          const speed = parseFloat(extractSlot.call(null, esText, /:speed\s+([\d\.\-]+)/i) || '120');
          const count = parseInt(extractSlot.call(null, esText, /:count\s+(\d+)/i) || '80', 10);
          const gravity = parseFloat(extractSlot.call(null, esText, /:gravity\s+([\d\.\-]+)/i) || '0');
          if (target) {
            emitterSets.push({ target, speed, count, gravity });
          }
        });

        states.push({ name: stName, attrs, emitterSets });
      });

      // Transitions
      const transitions = [];
      const transContainer = extractSexprBlocks(smText, ':transitions');
      const transBlocks = transContainer.length > 0
        ? extractSexprBlocks(transContainer[0], ':transition')
        : extractSexprBlocks(smText, ':transition');

      transBlocks.forEach(trText => {
        const from = extractSlot.call(null, trText, /:from\s+"([^"]+)"/i) || extractSlot.call(null, trText, /:from\s+([^\s\)]+)/i) || '*';
        const to = extractSlot.call(null, trText, /:to\s+"([^"]+)"/i) || extractSlot.call(null, trText, /:to\s+([^\s\)]+)/i);
        const trigger = extractSlot.call(null, trText, /:trigger\s+"([^"]+)"/i) || extractSlot.call(null, trText, /:trigger\s+([^\s\)]+)/i) || 'true';
        const duration = parseFloat(extractSlot.call(null, trText, /:duration\s+([\d\.]+)/i) || '0.5');
        const dwellTime = parseFloat(extractSlot.call(null, trText, /:dwell\s+([\d\.]+)/i) || '0.3');
        if (to) {
          transitions.push({ from, to, trigger, duration, dwellTime });
        }
      });

      stateMachines.push({
        id: smId,
        initial,
        dwellTime: dwell,
        states,
        transitions
      });
    });

    // Live Vector Oscilloscopes (:scope)
    const scopes = [];
    const scopeBlocks = extractSexprBlocks(astContent, ':scope');
    scopeBlocks.forEach(sb => {
      const target = extractQuoted(sb, 'target') || extractSlot.call(null, sb, /:target\s+([^\s\)]+)/i);
      const xExpr = extractQuoted(sb, 'x-expr') || extractQuoted(sb, 'xExpr') || 't';
      const yExpr = extractQuoted(sb, 'y-expr') || extractQuoted(sb, 'yExpr') || '0';
      const samplesStr = extractSlot.call(null, sb, /:samples\s+(\d+)/i);
      const samples = samplesStr ? Math.max(8, Math.min(2048, parseInt(samplesStr, 10))) : 96;
      const xrMatch = sb.match(/:x-?range\s*\(\s*([\d\.\-]+)\s+([\d\.\-]+)\s*\)/i);
      const yrMatch = sb.match(/:y-?range\s*\(\s*([\d\.\-]+)\s+([\d\.\-]+)\s*\)/i);
      const plotMatch = sb.match(/:plot\s*\(\s*([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s*\)/i);
      if (target) {
        const sc = {
          target,
          xExpr,
          yExpr,
          samples,
          xRange: xrMatch ? [parseFloat(xrMatch[1]), parseFloat(xrMatch[2])] : [0, 30],
          yRange: yrMatch ? [parseFloat(yrMatch[1]), parseFloat(yrMatch[2])] : [0, 100]
        };
        if (plotMatch) {
          sc.plot = [
            parseFloat(plotMatch[1]),
            parseFloat(plotMatch[2]),
            parseFloat(plotMatch[3]),
            parseFloat(plotMatch[4])
          ];
        }
        scopes.push(sc);
      }
    });

    // Conservation-Law & Energy-Ledger Meters (:ledger)
    const ledgers = [];
    const ledgerBlocks = extractSexprBlocks(astContent, ':ledger');
    ledgerBlocks.forEach(lb => {
      const lid = extractQuoted(lb, 'id') || `ledger_${ledgers.length + 1}`;
      const target = extractQuoted(lb, 'target') || `#${lid}`;
      const unit = extractQuoted(lb, 'unit') || '';
      const maxExpr = extractQuoted(lb, 'max') || '';
      const lx = parseFloat(extractSlot.call(null, lb, /:x\s+([\d\.\-]+)/i) || '40');
      const ly = parseFloat(extractSlot.call(null, lb, /:y\s+([\d\.\-]+)/i) || '400');
      const lw = parseFloat(extractSlot.call(null, lb, /:width\s+([\d\.]+)/i) || '320');
      const lh = parseFloat(extractSlot.call(null, lb, /:height\s+([\d\.]+)/i) || '20');
      const termBlocks = extractSexprBlocks(lb, ':label');
      const terms = [];
      termBlocks.forEach(tb => {
        const label = extractQuoted(tb, 'label') || 'Term';
        const expr = extractQuoted(tb, 'expr') || '0';
        const color = extractQuoted(tb, 'color') || '#38bdf8';
        terms.push({ label, expr, color });
      });
      if (terms.length > 0) {
        ledgers.push({ id: lid, target, unit, maxExpr, x: lx, y: ly, width: lw, height: lh, terms });
      }
    });

    // Cartridge Feature & UI Controls (:controls (:arrow-step :off) ... or plist)
    let controls = null;
    const controlsBlocks = extractSexprBlocks(astContent, ':controls');
    if (controlsBlocks.length > 0) {
      controls = {};
      controlsBlocks.forEach(cb => {
        const pairRe = /\(\s*:([a-zA-Z0-9_-]+)\s+(:on|:off|:true|:false|true|false)\s*\)/gi;
        let pm;
        while ((pm = pairRe.exec(cb)) !== null) {
          const flag = pm[1].toLowerCase();
          const tok = pm[2].toLowerCase();
          controls[flag] = (tok === ':on' || tok === ':true' || tok === 'true');
        }
        const plistBody = cb.replace(/^\(\s*:controls\b/i, '').replace(/\([^\)]*\)/g, ' ');
        const plistRe = /:([a-zA-Z0-9_-]+)\s+(:on|:off|:true|:false|true|false)(?=[\s)]|$)/gi;
        let plm;
        while ((plm = plistRe.exec(plistBody)) !== null) {
          const flag = plm[1].toLowerCase();
          const tok = plm[2].toLowerCase();
          controls[flag] = (tok === ':on' || tok === ':true' || tok === 'true');
        }
      });
      if (Object.keys(controls).length === 0) controls = null;
    }

    // Declarative 3D Camera Viewpoint Stops (:camera-stops ((:stop :id ... :aliases ... :yaw ... :pitch ... :scale ... :t ... :toast ...)))
    let cameraStops = null;
    const camStopBlocks = extractSexprBlocks(astContent, ':camera-stops');
    if (camStopBlocks.length > 0) {
      const stops = [];
      const stopForms = extractSexprBlocks(camStopBlocks[0], ':stop');
      stopForms.forEach(st => {
        const sid = extractQuoted(st, 'id') || extractSlot.call(null, st, /:id\s+([^\s\)]+)/i);
        if (!sid) return;
        const rawAliases = extractQuoted(st, 'aliases') || '';
        const aliases = rawAliases
          ? rawAliases.split(',').map(s => s.trim().toLowerCase()).filter(Boolean)
          : [];
        const yawStr = extractSlot.call(null, st, /:yaw\s+([\d\.\-]+)/i);
        const pitchStr = extractSlot.call(null, st, /:pitch\s+([\d\.\-]+)/i);
        const scaleStr = extractSlot.call(null, st, /:scale\s+([\d\.\-]+)/i);
        const tStr = extractSlot.call(null, st, /:t\s+([\d\.\-]+)/i);
        const toast = extractQuoted(st, 'toast') || '';
        stops.push({
          id: sid.toLowerCase(),
          aliases,
          yaw: yawStr !== null ? parseFloat(yawStr) : 0,
          pitch: pitchStr !== null ? parseFloat(pitchStr) : 0,
          scale: scaleStr !== null ? parseFloat(scaleStr) : 1.0,
          t: tStr !== null ? parseFloat(tStr) : undefined,
          toast
        });
      });
      if (stops.length > 0) cameraStops = stops;
    }

    // Declarative Guided Quest Missions (:quests :title ... (:missions ((:mission ... (:questions ((:q ...)))))))
    let quests = null;
    const questBlocks = extractSexprBlocks(astContent, ':quests');
    if (questBlocks.length > 0) {
      const qb = questBlocks[0];
      const missionsBlocks = extractSexprBlocks(qb, ':missions');
      const headerOnly = missionsBlocks.length > 0 ? qb.replace(missionsBlocks[0], '') : qb;
      const qTitle = extractQuoted(headerOnly, 'title') || '3D Explorer Quest Started!';
      const completionTitle = extractQuoted(headerOnly, 'completion-title') || 'QUEST COMPLETE!';
      const completionDesc = extractQuoted(headerOnly, 'completion-desc') || 'Congratulations! You have completed every mission in this scene.';
      const feedbackWrong = extractQuoted(headerOnly, 'feedback-wrong') || 'Key Insight:';
      const correctToast = extractQuoted(headerOnly, 'correct-toast') || '⭐ Correct! +100 Points';
      const wrongToast = extractQuoted(headerOnly, 'wrong-toast') || 'Notice: Review the explanation below';

      const missionForms = extractSexprBlocks(missionsBlocks.length > 0 ? missionsBlocks[0] : qb, ':mission');
      const missions = [];
      missionForms.forEach((mb, mIdx) => {
        const qSubBlocks = extractSexprBlocks(mb, ':questions');
        const mHeader = qSubBlocks.length > 0 ? mb.replace(qSubBlocks[0], '') : mb;
        const mid = extractQuoted(mHeader, 'id') || `mission_${mIdx + 1}`;
        const mTitle = extractQuoted(mHeader, 'title') || `Mission ${mIdx + 1}`;
        const mDesc = extractQuoted(mHeader, 'desc') || '';
        const tStr = extractSlot.call(null, mHeader, /:t\s+([\d\.\-]+)/i);
        const yawStr = extractSlot.call(null, mHeader, /:yaw\s+([\d\.\-]+)/i);
        const pitchStr = extractSlot.call(null, mHeader, /:pitch\s+([\d\.\-]+)/i);
        const scaleStr = extractSlot.call(null, mHeader, /:scale\s+([\d\.\-]+)/i);
        const hasCam = yawStr !== null || pitchStr !== null || scaleStr !== null;

        const qForms = extractSexprBlocks(qSubBlocks.length > 0 ? qSubBlocks[0] : mb, ':q');
        const questionPool = [];
        qForms.forEach(qf => {
          const prompt = extractQuoted(qf, 'prompt') || '';
          const ansMatch = qf.match(/:answer\s+(\d+)/i);
          const explanation = extractQuoted(qf, 'explanation') || '';
          const options = [];
          const optIdx = qf.indexOf(':options');
          if (optIdx !== -1) {
            const sParen = qf.indexOf('(', optIdx);
            if (sParen !== -1) {
              let depth = 0;
              let inStr = false;
              let eParen = -1;
              for (let i = sParen; i < qf.length; i++) {
                const ch = qf[i];
                if (ch === '"' && (i === 0 || qf[i - 1] !== '\\')) inStr = !inStr;
                else if (!inStr) {
                  if (ch === '(') depth++;
                  else if (ch === ')') {
                    depth--;
                    if (depth === 0) { eParen = i; break; }
                  }
                }
              }
              if (eParen !== -1) {
                const inside = qf.slice(sParen + 1, eParen);
                const optRe = /"((?:[^"\\]|\\.)*)"/g;
                let om;
                while ((om = optRe.exec(inside)) !== null) {
                  options.push(om[1].replace(/\\"/g, '"'));
                }
              }
            }
          }
          if (prompt && options.length > 0) {
            questionPool.push({
              question: prompt,
              options,
              correct: ansMatch ? parseInt(ansMatch[1], 10) : 0,
              explanation
            });
          }
        });

        if (questionPool.length > 0) {
          missions.push({
            id: mid,
            targetT: tStr !== null ? parseFloat(tStr) : 0,
            cam: hasCam ? {
              yaw: yawStr !== null ? parseFloat(yawStr) : 0,
              pitch: pitchStr !== null ? parseFloat(pitchStr) : 0,
              scale: scaleStr !== null ? parseFloat(scaleStr) : 1.0
            } : null,
            title: mTitle,
            desc: mDesc,
            questionPool
          });
        }
      });

      if (missions.length > 0) {
        quests = {
          title: qTitle,
          completionTitle,
          completionDesc,
          feedbackWrong,
          correctToast,
          wrongToast,
          missions
        };
      }
    }

    // Declarative Player AST Skill activations (:use-skill "skill-id" :param val ...)
    const skills = [];
    const useSkillBlocks = extractSexprBlocks(astContent, ':use-skill');
    useSkillBlocks.forEach(sb => {
      const idMatch = sb.match(/^\(\s*:use-skill\s+"([^"]+)"/i) || sb.match(/:id\s+"([^"]+)"/i);
      const skillId = idMatch ? idMatch[1] : null;
      if (!skillId) return;
      const params = {};
      const attrRe = /:([a-zA-Z0-9_-]+)\s+("(?:[^"\\]|\\.)*"|true|false|-?\d+(?:\.\d+)?)/gi;
      let am;
      while ((am = attrRe.exec(sb)) !== null) {
        const k = am[1];
        if (k === 'id' || k === 'use-skill') continue;
        const raw = am[2];
        if (raw.startsWith('"')) params[k] = raw.slice(1, -1).replace(/\\([\\"])/g, '$1');
        else if (raw === 'true') params[k] = true;
        else if (raw === 'false') params[k] = false;
        else params[k] = Number(raw);
      }
      skills.push({ id: skillId, params });
    });

    const has3D = Boolean((camBlocks && camBlocks.length > 0) || bindings.some(b => b.type && b.type.startsWith('3d-')));

    return {
      id: id || 'custom-scene',
      title: title || 'AST Vector Scene',
      stage,
      type,
      cartridgeType: type,
      duration,
      bootSound,
      video: video || null,
      videoFit: videoFit || 'contain',
      hasVideo: Boolean(video),
      camera: (camBlocks && camBlocks.length > 0) ? camera : null,
      cameraStops,
      quests,
      has3D,
      keyframes,
      subtitles,
      bindings,
      checkpoints,
      scopes,
      ledgers,
      physics,
      stateMachines: stateMachines.length > 0 ? stateMachines : null,
      emitters: emitters.length > 0 ? emitters : null,
      vars,
      inputs,
      uiControls,
      computed,
      staticElements,
      actors,
      gestures,
      skills,
      controls,
      interactive: checkpoints.length > 0 ? { checkpoints, hotspots: [] } : null
    };
  }

  global.AstMath = AstMath;
  global.astMorphPath = astMorphPath;
  global.astMorphColor = astMorphColor;
  global.astEaseBack = astEaseBack;
  global.astEaseBounce = astEaseBounce;
  global.astEaseElastic = astEaseElastic;
  global.astSquashStretch = astSquashStretch;
  global.compileAstExpr = compileAstExpr;
  global.compileAstFn = compileAstFn;
  global.isAstBytecode = isAstBytecode;
  global.decompileBytecode = decompileBytecode;
  global.parseAst = parseAst;
  if (typeof window !== 'undefined') {
    window.AstMath = AstMath;
    window.astMorphPath = astMorphPath;
    window.astMorphColor = astMorphColor;
    window.astEaseBack = astEaseBack;
    window.astEaseBounce = astEaseBounce;
    window.astEaseElastic = astEaseElastic;
    window.astSquashStretch = astSquashStretch;
    window.compileAstExpr = compileAstExpr;
    window.compileAstFn = compileAstFn;
    window.isAstBytecode = isAstBytecode;
    window.decompileBytecode = decompileBytecode;
    window.parseAst = parseAst;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
